import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Files uploaded after `next start` are not in Next's static public map.
  // Serve /uploads/* via API that reads from disk.
  async rewrites() {
    return [{ source: "/uploads/:path*", destination: "/api/media/:path*" }];
  },
};

export default nextConfig;
