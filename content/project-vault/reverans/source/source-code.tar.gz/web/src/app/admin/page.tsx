import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { DocumentStatus, PaymentStatus } from "@prisma/client";
import { DOC_LABELS, paymentTypeLabel } from "@/lib/documents";
import { DocumentStatusBadge, PaymentStatusBadge } from "@/components/admin/status-badge";

export default async function AdminDashboardPage() {
  const [childrenCount, groupsCount, debtAgg, pendingDocs, recentPayments, recentDocs] =
    await Promise.all([
      prisma.child.count(),
      prisma.group.count(),
      prisma.payment.aggregate({
        where: { status: PaymentStatus.pending },
        _sum: { amount: true },
        _count: true,
      }),
      prisma.document.count({ where: { status: DocumentStatus.pending } }),
      prisma.payment.findMany({
        take: 5,
        orderBy: { createdAt: "desc" },
        include: { child: true },
      }),
      prisma.document.findMany({
        take: 5,
        orderBy: { createdAt: "desc" },
        include: { child: true },
      }),
    ]);

  const debt = Number(debtAgg._sum.amount || 0);

  return (
    <div>
      <h1>Дэшборд</h1>
      <p className="admin-muted">
        Студия: дети и оплаты ·{" "}
        <Link href="/admin/site">Сайт: тексты, галерея, SEO</Link>
      </p>

      <div className="admin-stats">
        <div className="admin-stat">
          <strong>{childrenCount}</strong>
          <span>Детей</span>
        </div>
        <div className="admin-stat">
          <strong>{groupsCount}</strong>
          <span>Групп</span>
        </div>
        <div className="admin-stat">
          <strong>{debt.toLocaleString("ru-RU")} ₽</strong>
          <span>К оплате ({debtAgg._count})</span>
        </div>
        <div className="admin-stat">
          <strong>{pendingDocs}</strong>
          <span>Документов ждут</span>
        </div>
      </div>

      <h2>Быстрые действия</h2>
      <div className="admin-row-actions">
        <Link className="admin-btn" href="/admin/groups">
          Группы
        </Link>
        <Link className="admin-btn" href="/admin/children">
          Дети
        </Link>
        <Link className="admin-btn" href="/admin/payments">
          Платежи
        </Link>
        <Link className="admin-btn" href="/admin/documents">
          Документы
        </Link>
      </div>

      <h2>Последние платежи</h2>
      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Ребёнок</th>
              <th>Сумма</th>
              <th>Тип</th>
              <th>Статус</th>
              <th>Месяц</th>
            </tr>
          </thead>
          <tbody>
            {recentPayments.length === 0 ? (
              <tr>
                <td colSpan={5}>Пока нет платежей</td>
              </tr>
            ) : (
              recentPayments.map((p) => (
                <tr key={p.id}>
                  <td>{p.child.fullName}</td>
                  <td>{Number(p.amount).toLocaleString("ru-RU")} ₽</td>
                  <td>{paymentTypeLabel(p.type)}</td>
                  <td>
                    <PaymentStatusBadge status={p.status} />
                  </td>
                  <td>{p.month || "—"}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <h2>Последние документы</h2>
      <div className="admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Ребёнок</th>
              <th>Тип</th>
              <th>Статус</th>
            </tr>
          </thead>
          <tbody>
            {recentDocs.length === 0 ? (
              <tr>
                <td colSpan={3}>Пока нет документов</td>
              </tr>
            ) : (
              recentDocs.map((d) => (
                <tr key={d.id}>
                  <td>{d.child.fullName}</td>
                  <td>{DOC_LABELS[d.type] || d.type}</td>
                  <td>
                    <DocumentStatusBadge
                      type={d.type}
                      status={d.status}
                      hasFile={Boolean(d.fileUrl)}
                    />
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
