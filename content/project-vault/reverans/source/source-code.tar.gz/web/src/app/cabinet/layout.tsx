import Link from "next/link";
import { requireParent } from "@/lib/session";
import "@/components/cabinet/cabinet.css";

export default async function CabinetLayout({ children }: { children: React.ReactNode }) {
  const session = await requireParent();

  return (
    <div className="cab-shell">
      <header className="cab-top">
        <div className="cab-top-brand">Реверанс · Кабинет</div>
        <div className="cab-top-actions">
          <span>{session.user.name || session.user.email}</span>
          <Link href="/">Сайт</Link>
          <Link href="/api/auth/signout">Выйти</Link>
        </div>
      </header>
      <main className="cab-main">{children}</main>
    </div>
  );
}
