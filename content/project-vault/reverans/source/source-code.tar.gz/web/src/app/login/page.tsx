import { Suspense } from "react";
import { redirect } from "next/navigation";
import { yandexAuthEnabled } from "@/lib/auth";
import LoginForm from "./login-form";

export const dynamic = "force-dynamic";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; callbackUrl?: string }>;
}) {
  const sp = await searchParams;
  if (sp.error) {
    redirect(`/auth/error?error=${encodeURIComponent(sp.error)}`);
  }

  return (
    <Suspense fallback={<div className="cab-auth">Загрузка…</div>}>
      <LoginForm yandexEnabled={yandexAuthEnabled()} />
    </Suspense>
  );
}
