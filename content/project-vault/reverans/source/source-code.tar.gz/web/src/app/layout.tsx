import type { Metadata } from "next";
import { Montserrat } from "next/font/google";
import { Providers } from "@/components/providers";
import { getPageSeo, getSiteSettings } from "@/lib/cms";
import "./fonts.css";
import "./globals.css";

const montserrat = Montserrat({
  subsets: ["latin", "cyrillic"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-montserrat",
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  const [settings, homeSeo] = await Promise.all([getSiteSettings(), getPageSeo("/")]);
  return {
    title: {
      default: homeSeo?.title || "СКХГ «Реверанс» — Художественная гимнастика для детей",
      template: `%s — ${settings.brandNameRu}`,
    },
    description:
      homeSeo?.description ||
      "Спортивный клуб художественной гимнастики «Реверанс» в Москве. Занятия для детей от 3 лет.",
    metadataBase: new URL("https://reverans.online"),
    icons: {
      icon: [{ url: "/brand/pwa/icon-192.png", sizes: "192x192", type: "image/png" }],
      apple: [{ url: "/brand/pwa/apple-touch-icon.png", sizes: "180x180", type: "image/png" }],
      ...(settings.faviconUrl ? { other: [{ rel: "icon", url: settings.faviconUrl }] } : {}),
    },
    appleWebApp: {
      capable: true,
      title: "Реверанс",
      statusBarStyle: "default",
    },
    openGraph: {
      images: settings.ogImageUrl ? [settings.ogImageUrl] : ["/brand/pwa/promo.webp"],
    },
    verification: settings.yandexVerification
      ? { yandex: settings.yandexVerification }
      : undefined,
  };
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ru">
      <body className={`${montserrat.variable} antialiased`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
