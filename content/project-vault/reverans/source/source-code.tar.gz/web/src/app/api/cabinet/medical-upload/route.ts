import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { DocumentStatus, DocumentType } from "@prisma/client";
import { authOptions } from "@/lib/auth";
import {
  deleteMedicalFiles,
  MEDICAL_MAX_BYTES,
  saveMedicalScan,
} from "@/lib/medical-storage";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id || (session.user.role !== "parent" && session.user.role !== "coach")) {
    return NextResponse.json({ error: "Войдите как родитель" }, { status: 401 });
  }

  const form = await req.formData();
  const documentId = String(form.get("documentId") || "");
  const file = form.get("file");
  if (!documentId || !(file instanceof File)) {
    return NextResponse.json({ error: "Нет файла или документа" }, { status: 400 });
  }
  if (file.size > MEDICAL_MAX_BYTES) {
    return NextResponse.json({ error: "Файл больше 12 МБ — сожмите или выберите другое фото" }, { status: 400 });
  }

  const doc = await prisma.document.findUnique({
    where: { id: documentId },
    include: { child: true },
  });
  if (!doc || doc.child.userId !== session.user.id || doc.type !== DocumentType.medical_clearance) {
    return NextResponse.json({ error: "Документ не найден" }, { status: 404 });
  }
  if (doc.status === DocumentStatus.signed) {
    return NextResponse.json({ error: "Меддопуск уже подтверждён администратором" }, { status: 400 });
  }

  try {
    const buffer = Buffer.from(await file.arrayBuffer());
    const saved = await saveMedicalScan({
      buffer,
      mime: file.type || "application/octet-stream",
      originalName: file.name || "scan",
    });

    await deleteMedicalFiles(doc.fileUrl, doc.fileThumbUrl);

    await prisma.document.update({
      where: { id: doc.id },
      data: {
        fileUrl: saved.fileUrl,
        fileThumbUrl: saved.fileThumbUrl,
        fileName: saved.fileName,
        status: DocumentStatus.pending,
        signedAt: null,
      },
    });

    return NextResponse.json({
      ok: true,
      viewUrl: `/api/documents/${doc.id}/file`,
      thumbUrl: saved.fileThumbUrl ? `/api/documents/${doc.id}/file?thumb=1` : null,
      message: "Скан отправлен на проверку администратору",
      compressedBytes: saved.sizeBytes,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Ошибка загрузки";
    return NextResponse.json({ error: msg }, { status: 400 });
  }
}
