import { ChangePasswordForm } from "@/components/admin/change-password-form";

export default function AdminSettingsPage() {
  return (
    <div>
      <h1>Настройки</h1>
      <p className="admin-muted">Безопасность учётной записи администратора</p>
      <h2>Смена пароля</h2>
      <ChangePasswordForm />
    </div>
  );
}
