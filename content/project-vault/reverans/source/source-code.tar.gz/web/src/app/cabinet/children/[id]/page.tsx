import Link from "next/link";
import { notFound } from "next/navigation";
import { DocStatusBadge, DocTypeIcon } from "@/components/cabinet/doc-ui";
import { IconCreditCard, IconFilePen } from "@/components/icons/doc-icons";
import { requireParent } from "@/lib/session";
import { DOC_LABELS, ensureChildDocuments } from "@/lib/documents";
import { childMonthAmount, formatRub, isBudgetPlace } from "@/lib/pricing";
import { prisma } from "@/lib/prisma";
import { DocumentType } from "@prisma/client";

export const dynamic = "force-dynamic";

const DOC_ORDER: DocumentType[] = [
  DocumentType.contract,
  DocumentType.consent,
  DocumentType.medical_clearance,
];

export default async function ChildPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await requireParent();
  const child = await prisma.child.findFirst({
    where: { id, userId: session.user.id },
    include: { group: true, documents: true },
  });
  if (!child) notFound();
  await ensureChildDocuments(child.id);

  const budget = isBudgetPlace(child);
  const amount = childMonthAmount(child.pricePerMonth, child.discount);
  const docs = [...child.documents].sort(
    (a, b) => DOC_ORDER.indexOf(a.type) - DOC_ORDER.indexOf(b.type),
  );

  return (
    <>
      <p>
        <Link href="/cabinet">← К списку</Link>
      </p>
      <h1>{child.fullName}</h1>
      <p className="cab-lead">
        {child.group ? `Группа: ${child.group.name}` : "Группа пока не назначена"}
        {" · "}
        {budget ? (
          <span className="cab-badge cab-badge-ok">бюджет · оплата не требуется</span>
        ) : (
          <>
            Абонемент: {formatRub(amount)}
            {Number(child.discount) > 0 ? ` (скидка ${formatRub(child.discount)})` : ""}
          </>
        )}
      </p>

      <div className="cab-actions" style={{ marginBottom: 20 }}>
        <Link href={`/cabinet/children/${child.id}/documents`} className="cab-btn cab-btn-secondary">
          <IconFilePen className="cab-btn-svg" />
          Документы
        </Link>
        {budget ? null : (
          <Link href={`/cabinet/children/${child.id}/pay`} className="cab-btn">
            <IconCreditCard className="cab-btn-svg" />
            Оплата
          </Link>
        )}
      </div>

      <h2 style={{ fontSize: 16, marginBottom: 8 }}>Документы</h2>
      <ul className="cab-list">
        {docs.map((d) => (
          <li key={d.id} className={`cab-list-item cab-list-item-doc cab-list-item-${d.type}`}>
            <span className="cab-list-doc-label">
              <span className={`cab-doc-icon cab-doc-icon-sm cab-doc-icon-${d.type}`}>
                <DocTypeIcon type={d.type} className="cab-doc-icon-svg" />
              </span>
              {DOC_LABELS[d.type]}
            </span>
            <DocStatusBadge type={d.type} status={d.status} hasFile={Boolean(d.fileUrl)} />
          </li>
        ))}
      </ul>
    </>
  );
}
