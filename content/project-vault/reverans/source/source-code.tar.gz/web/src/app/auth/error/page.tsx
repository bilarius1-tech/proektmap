import { Suspense } from "react";
import AuthErrorCard from "./auth-error-card";

export const dynamic = "force-dynamic";

export default function AuthErrorPage() {
  return (
    <Suspense fallback={<div className="cab-auth">Загрузка…</div>}>
      <AuthErrorCard />
    </Suspense>
  );
}
