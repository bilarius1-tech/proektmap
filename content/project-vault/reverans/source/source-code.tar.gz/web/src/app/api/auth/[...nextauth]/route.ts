import NextAuth from "next-auth";
import { getAuthOptions } from "@/lib/auth";

const handler = (req: Request, context: { params: Promise<{ nextauth: string[] }> }) =>
  NextAuth(getAuthOptions())(req, context);

export { handler as GET, handler as POST };
