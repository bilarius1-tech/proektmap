import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import sharp from "sharp";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

const ALLOWED = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
const MAX_BYTES = 12 * 1024 * 1024;

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== "admin") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const form = await req.formData();
  const file = form.get("file");
  if (!(file instanceof File)) {
    return NextResponse.json({ error: "Нет файла" }, { status: 400 });
  }
  if (!ALLOWED.has(file.type)) {
    return NextResponse.json({ error: "Только JPG, PNG, WebP, GIF" }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ error: "Файл больше 12 МБ" }, { status: 400 });
  }

  const preserveAlpha =
    form.get("preserveAlpha") === "true" ||
    form.get("preserveAlpha") === "on" ||
    file.type === "image/png";

  const input = Buffer.from(await file.arrayBuffer());
  const base = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const dir = path.join(process.cwd(), "public", "uploads");
  await mkdir(dir, { recursive: true });

  const meta = await sharp(input, { failOn: "none" }).rotate().metadata();
  const hasAlpha = Boolean(meta.hasAlpha) || file.type === "image/png";
  const keepAlpha = preserveAlpha && hasAlpha;

  const resized = sharp(input, { failOn: "none" })
    .rotate()
    .resize({ width: 1920, height: 1920, fit: "inside", withoutEnlargement: true });

  let fullBuf: Buffer;
  let fullName: string;
  let mimeType: string;

  if (keepAlpha) {
    // PNG keeps transparency for cutouts on hero/about
    fullBuf = await resized.png({ compressionLevel: 8 }).toBuffer();
    fullName = `${base}.png`;
    mimeType = "image/png";
  } else {
    fullBuf = await resized.webp({ quality: 82 }).toBuffer();
    fullName = `${base}.webp`;
    mimeType = "image/webp";
  }

  const fullMeta = await sharp(fullBuf).metadata();
  await writeFile(path.join(dir, fullName), fullBuf);

  const thumbPipeline = sharp(input, { failOn: "none" })
    .rotate()
    .resize({ width: 720, height: 720, fit: "inside", withoutEnlargement: true });

  let thumbBuf: Buffer;
  let thumbName: string;
  if (keepAlpha) {
    thumbBuf = await thumbPipeline.png({ compressionLevel: 8 }).toBuffer();
    thumbName = `${base}-thumb.png`;
  } else {
    thumbBuf = await thumbPipeline.webp({ quality: 75 }).toBuffer();
    thumbName = `${base}-thumb.webp`;
  }
  await writeFile(path.join(dir, thumbName), thumbBuf);

  const url = `/uploads/${fullName}`;
  const thumbUrl = `/uploads/${thumbName}`;
  const alt = String(form.get("alt") || "").trim() || file.name || "Фото";

  const media = await prisma.mediaAsset.create({
    data: {
      filename: file.name || fullName,
      url,
      thumbUrl,
      mimeType,
      sizeBytes: fullBuf.length,
      width: fullMeta.width ?? meta.width ?? null,
      height: fullMeta.height ?? meta.height ?? null,
      alt,
    },
  });

  const addToGallery = form.get("gallery") === "true" || form.get("gallery") === "on";
  let galleryItem = null;
  if (addToGallery) {
    const max = await prisma.galleryItem.aggregate({ _max: { sortOrder: true } });
    galleryItem = await prisma.galleryItem.create({
      data: {
        mediaId: media.id,
        alt,
        caption: String(form.get("caption") || "").trim(),
        category: String(form.get("category") || "Клуб").trim() || "Клуб",
        sortOrder: (max._max.sortOrder ?? 0) + 1,
        published: true,
      },
      include: { media: true },
    });
  }

  return NextResponse.json({
    media,
    galleryItem,
    message: keepAlpha
      ? "Фото загружено (прозрачность сохранена)"
      : "Фото загружено и оптимизировано",
  });
}
