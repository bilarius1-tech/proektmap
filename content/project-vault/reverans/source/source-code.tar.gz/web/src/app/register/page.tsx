import { yandexAuthEnabled } from "@/lib/auth";
import RegisterForm from "./register-form";

export const dynamic = "force-dynamic";

export default function RegisterPage() {
  return <RegisterForm yandexEnabled={yandexAuthEnabled()} />;
}
