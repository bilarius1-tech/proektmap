import { CookieBanner } from "@/components/landing/cookie-banner";
import { SiteFooter } from "@/components/landing/site-footer";
import { SiteHeader } from "@/components/landing/site-header";
import { getSection, getSiteSettings } from "@/lib/cms";
import type { CookieBannerData } from "@/lib/cms-defaults";

export default async function MarketingLayout({ children }: { children: React.ReactNode }) {
  const [settings, cookie] = await Promise.all([
    getSiteSettings(),
    getSection<CookieBannerData>("legal.cookieBanner"),
  ]);

  return (
    <>
      <SiteHeader
        brandName={settings.brandName}
        tagline={settings.tagline}
        logoUrl={settings.logoUrl || "/brand/logo.png"}
      />
      <main>{children}</main>
      <SiteFooter />
      <CookieBanner
        data={cookie.data}
        metrikaId={settings.yandexMetrikaId}
        metrikaEnabled={settings.yandexMetrikaOn}
        webvisor={settings.yandexWebvisor}
        googleAnalyticsId={settings.googleAnalyticsId}
      />
    </>
  );
}
