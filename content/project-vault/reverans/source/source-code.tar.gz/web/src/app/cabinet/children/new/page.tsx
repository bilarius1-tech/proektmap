import Link from "next/link";
import { addChild, claimChild } from "@/app/cabinet/actions";

export default function NewChildPage() {
  return (
    <>
      <p>
        <Link href="/cabinet">← Назад</Link>
      </p>
      <h1>Ребёнок в кабинете</h1>

      <section className="cab-child-card" style={{ marginBottom: 16 }}>
        <h2 style={{ fontSize: 18, margin: "0 0 8px" }}>Уже зачислили в студии?</h2>
        <p className="cab-lead" style={{ marginTop: 0 }}>
          Введите код от администратора (у каждой дочери свой) — группа и сумма подтянутся.
          Укажите дату рождения ребёнка.
        </p>
        <form className="cab-form" action={claimChild}>
          <label>
            Код приглашения
            <input
              name="inviteCode"
              required
              placeholder="Например A3K9M2"
              autoCapitalize="characters"
              autoComplete="off"
            />
          </label>
          <label>
            Дата рождения ребёнка
            <input name="dateOfBirth" type="date" required />
          </label>
          <button type="submit" className="cab-btn">
            Привязать ребёнка
          </button>
        </form>
      </section>

      <section className="cab-child-card">
        <h2 style={{ fontSize: 18, margin: "0 0 8px" }}>Или добавить самостоятельно</h2>
        <p className="cab-lead" style={{ marginTop: 0 }}>
          Группу и стоимость абонемента назначит администратор клуба.
        </p>
        <form className="cab-form" action={addChild}>
          <label>
            ФИО ребёнка
            <input name="fullName" required placeholder="Иванова Алиса" />
          </label>
          <label>
            Дата рождения
            <input name="dateOfBirth" type="date" required />
          </label>
          <button type="submit" className="cab-btn cab-btn-secondary">
            Сохранить
          </button>
        </form>
      </section>
    </>
  );
}
