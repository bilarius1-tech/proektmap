import Link from "next/link";
import { requireParent } from "@/lib/session";
import { ensureChildDocuments } from "@/lib/documents";
import { childMonthAmount, defaultBillableMonthKey, formatRub, isBudgetPlace, monthLabel } from "@/lib/pricing";
import { prisma } from "@/lib/prisma";
import { PaymentStatus, PaymentType } from "@prisma/client";

export const dynamic = "force-dynamic";

function ageYears(dob: Date | null) {
  if (!dob) return null;
  const now = new Date();
  let age = now.getFullYear() - dob.getFullYear();
  const m = now.getMonth() - dob.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < dob.getDate())) age -= 1;
  return age;
}

export default async function CabinetHomePage() {
  const session = await requireParent();
  const billMonth = defaultBillableMonthKey();
  const children = await prisma.child.findMany({
    where: { userId: session.user.id },
    include: {
      group: true,
      documents: true,
      payments: {
        where: { type: PaymentType.monthly, month: billMonth },
        take: 1,
      },
    },
    orderBy: { fullName: "asc" },
  });

  await Promise.all(children.map((c) => ensureChildDocuments(c.id)));

  return (
    <>
      <h1>Привет, {session.user.name?.split(" ")[0] || "родитель"}!</h1>
      <p className="cab-lead">Дети, договоры и оплата — в одном месте.</p>

      {children.length === 0 ? (
        <div className="cab-child-card">
          <p className="cab-child-meta">Пока нет добавленных детей.</p>
          <Link href="/cabinet/children/new" className="cab-btn">
            + Добавить или привязать
          </Link>
        </div>
      ) : (
        children.map((child) => {
          const monthPay = child.payments[0];
          const budget = isBudgetPlace(child);
          const amount = childMonthAmount(child.pricePerMonth, child.discount);
          const contract = child.documents.find((d) => d.type === "contract");
          const paid = monthPay?.status === PaymentStatus.paid;
          const age = ageYears(child.dateOfBirth);
          return (
            <article key={child.id} className="cab-child-card">
              <h2>{child.fullName}</h2>
              <p className="cab-child-meta">
                {age != null ? `${age} лет · ` : ""}
                {child.group ? child.group.name : "группа не назначена"}
                {budget ? (
                  <>
                    {" · "}
                    <span className="cab-badge cab-badge-ok">бюджет</span>
                  </>
                ) : (
                  <>
                    {" · "}
                    {formatRub(amount)}/мес
                    {paid ? (
                      <span className="cab-badge cab-badge-ok"> {monthLabel(billMonth)}: оплачено</span>
                    ) : (
                      <span className="cab-badge cab-badge-wait"> {monthLabel(billMonth)}: к оплате</span>
                    )}
                  </>
                )}
              </p>
              <div className="cab-actions">
                <Link href={`/cabinet/children/${child.id}/documents`} className="cab-btn cab-btn-secondary">
                  {contract?.status === "signed" ? "Документы ✓" : "Договор"}
                </Link>
                {budget ? (
                  <Link href={`/cabinet/children/${child.id}`} className="cab-btn cab-btn-secondary">
                    Карточка
                  </Link>
                ) : (
                  <Link href={`/cabinet/children/${child.id}/pay`} className="cab-btn cab-btn-secondary">
                    По ребёнку
                  </Link>
                )}
              </div>
            </article>
          );
        })
      )}

      <div className="cab-actions" style={{ marginTop: 16 }}>
        {children.some((c) => !c.isBudget) ? (
          <Link href="/cabinet/pay" className="cab-btn">
            Оплатить всех
          </Link>
        ) : null}
        <Link href="/cabinet/children/new" className="cab-btn cab-btn-secondary">
          + Добавить или привязать
        </Link>
        <Link href="/cabinet/history" className="cab-btn-ghost">
          История платежей →
        </Link>
      </div>
    </>
  );
}
