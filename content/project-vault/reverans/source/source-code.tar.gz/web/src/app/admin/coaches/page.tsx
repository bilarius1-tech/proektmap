import { createCoach, deleteCoach, updateCoach } from "@/app/admin/actions";
import { AdminListToolbar } from "@/components/admin/admin-list-toolbar";
import { AdminModalForm } from "@/components/admin/admin-modal";
import { normalizeQuery } from "@/lib/admin-list";
import { prisma } from "@/lib/prisma";
import { Prisma, Role } from "@prisma/client";

export const dynamic = "force-dynamic";

export default async function AdminCoachesPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const sp = await searchParams;
  const q = normalizeQuery(sp.q);

  const where: Prisma.UserWhereInput = {
    role: Role.coach,
    ...(q
      ? {
          OR: [
            { name: { contains: q, mode: "insensitive" } },
            { email: { contains: q, mode: "insensitive" } },
          ],
        }
      : {}),
  };

  const coaches = await prisma.user.findMany({
    where,
    orderBy: { name: "asc" },
    include: { coachedGroups: true, coachedGroupsSecond: true },
  });

  const createForm = (
    <form className="admin-form" action={createCoach}>
      <label>
        ФИО педагога
        <input name="name" required placeholder="Иванова Анна Сергеевна" />
      </label>
      <label>
        Email
        <input name="email" type="email" required />
      </label>
      <label>
        Телефон
        <input name="phone" placeholder="+7..." />
      </label>
      <button type="submit">Добавить</button>
    </form>
  );

  function editForm(c: (typeof coaches)[number]) {
    return (
      <form className="admin-form" action={updateCoach}>
        <input type="hidden" name="id" value={c.id} />
        <label>
          ФИО педагога
          <input name="name" defaultValue={c.name} required />
        </label>
        <label>
          Email
          <input name="email" type="email" defaultValue={c.email} required />
        </label>
        <label>
          Телефон
          <input name="phone" defaultValue={c.phone || ""} placeholder="+7..." />
        </label>
        <button type="submit">Сохранить</button>
      </form>
    );
  }

  return (
    <div>
      <div className="admin-page-head">
        <h1>Педагоги</h1>
        <AdminModalForm title="Добавить педагога" triggerLabel="Добавить педагога">
          {createForm}
        </AdminModalForm>
      </div>

      <AdminListToolbar action="/admin/coaches" searchPlaceholder="Поиск по имени или email…" q={q} />

      <div className="admin-table-wrap admin-table-desktop">
        <table className="admin-table">
          <thead>
            <tr>
              <th>ФИО</th>
              <th>Email</th>
              <th>Телефон</th>
              <th>Группы</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {coaches.length === 0 ? (
              <tr>
                <td colSpan={5}>Ничего не найдено</td>
              </tr>
            ) : (
              coaches.map((c) => {
                const groupNames = [
                  ...c.coachedGroups.map((g) => g.name),
                  ...c.coachedGroupsSecond.map((g) => g.name),
                ];
                const unique = [...new Set(groupNames)];
                return (
                  <tr key={c.id}>
                    <td>{c.name}</td>
                    <td>{c.email}</td>
                    <td>{c.phone || "—"}</td>
                    <td>{unique.join(", ") || "—"}</td>
                    <td>
                      <div className="admin-row-actions">
                        <AdminModalForm
                          title={`Изменить: ${c.name}`}
                          triggerLabel="Изменить"
                          triggerVariant="ghost"
                          icon="pencil"
                        >
                          {editForm(c)}
                        </AdminModalForm>
                        <form action={deleteCoach}>
                          <input type="hidden" name="id" value={c.id} />
                          <button type="submit" className="admin-btn admin-btn-danger">
                            Удалить
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <div className="admin-cards">
        {coaches.map((c) => {
          const groupNames = [
            ...c.coachedGroups.map((g) => g.name),
            ...c.coachedGroupsSecond.map((g) => g.name),
          ];
          const unique = [...new Set(groupNames)];
          return (
            <article key={c.id} className="admin-card">
              <h2 className="admin-card-title">{c.name}</h2>
              <p className="admin-card-meta">
                {c.email}
                {c.phone ? ` · ${c.phone}` : ""}
              </p>
              <p className="admin-card-meta">{unique.join(", ") || "Без групп"}</p>
              <div className="admin-card-actions">
                <AdminModalForm
                  title={`Изменить: ${c.name}`}
                  triggerLabel="Изменить"
                  triggerVariant="ghost"
                  icon="pencil"
                >
                  {editForm(c)}
                </AdminModalForm>
                <form action={deleteCoach}>
                  <input type="hidden" name="id" value={c.id} />
                  <button type="submit" className="admin-btn admin-btn-danger">
                    Удалить
                  </button>
                </form>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
