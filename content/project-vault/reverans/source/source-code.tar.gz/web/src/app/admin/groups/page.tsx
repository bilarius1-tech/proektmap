import {
  createGroup,
  deleteGroup,
  updateGroup,
} from "@/app/admin/actions";
import { AdminListToolbar } from "@/components/admin/admin-list-toolbar";
import { AdminModalForm } from "@/components/admin/admin-modal";
import { normalizeQuery } from "@/lib/admin-list";
import { prisma } from "@/lib/prisma";
import { Prisma, Role } from "@prisma/client";

export const dynamic = "force-dynamic";

function coachOptions(coaches: { id: string; name: string }[]) {
  return (
    <>
      <option value="">— не назначен —</option>
      {coaches.map((c) => (
        <option key={c.id} value={c.id}>
          {c.name}
        </option>
      ))}
    </>
  );
}

function coachesLabel(g: {
  coach: { name: string } | null;
  coach2: { name: string } | null;
}) {
  const names = [g.coach?.name, g.coach2?.name].filter(Boolean);
  return names.length ? names.join(", ") : "—";
}

export default async function AdminGroupsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string }>;
}) {
  const sp = await searchParams;
  const q = normalizeQuery(sp.q);

  const where: Prisma.GroupWhereInput = q
    ? { name: { contains: q, mode: "insensitive" } }
    : {};

  const [groups, coaches] = await Promise.all([
    prisma.group.findMany({
      where,
      orderBy: { name: "asc" },
      include: { coach: true, coach2: true, _count: { select: { children: true } } },
    }),
    prisma.user.findMany({ where: { role: Role.coach }, orderBy: { name: "asc" } }),
  ]);

  const createForm = (
    <form className="admin-form" action={createGroup}>
      <label>
        Название
        <input name="name" required placeholder="Подготовительная" />
      </label>
      <label>
        Цена по умолчанию (₽)
        <input name="defaultPrice" type="number" step="0.01" defaultValue={3500} />
      </label>
      <label>
        Педагог 1
        <select name="coachId" defaultValue="">
          {coachOptions(coaches)}
        </select>
      </label>
      <label>
        Педагог 2
        <select name="coach2Id" defaultValue="">
          {coachOptions(coaches)}
        </select>
      </label>
      <button type="submit">Добавить</button>
    </form>
  );

  function editForm(g: (typeof groups)[number]) {
    return (
      <form className="admin-form" action={updateGroup}>
        <input type="hidden" name="id" value={g.id} />
        <label>
          Название
          <input name="name" defaultValue={g.name} required />
        </label>
        <label>
          Цена по умолчанию (₽)
          <input
            name="defaultPrice"
            type="number"
            step="0.01"
            defaultValue={Number(g.defaultPrice)}
          />
        </label>
        <label>
          Педагог 1
          <select name="coachId" defaultValue={g.coachId || ""}>
            {coachOptions(coaches)}
          </select>
        </label>
        <label>
          Педагог 2
          <select name="coach2Id" defaultValue={g.coach2Id || ""}>
            {coachOptions(coaches)}
          </select>
        </label>
        <button type="submit">Сохранить</button>
      </form>
    );
  }

  return (
    <div>
      <div className="admin-page-head">
        <h1>Группы</h1>
        <AdminModalForm title="Создать группу" triggerLabel="Добавить группу">
          {createForm}
        </AdminModalForm>
      </div>

      <AdminListToolbar action="/admin/groups" searchPlaceholder="Поиск по названию…" q={q} />

      <div className="admin-table-wrap admin-table-desktop">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Название</th>
              <th>Педагоги</th>
              <th>Цена</th>
              <th>Детей</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {groups.length === 0 ? (
              <tr>
                <td colSpan={5}>Ничего не найдено</td>
              </tr>
            ) : (
              groups.map((g) => (
                <tr key={g.id}>
                  <td>{g.name}</td>
                  <td>{coachesLabel(g)}</td>
                  <td>{Number(g.defaultPrice).toLocaleString("ru-RU")} ₽</td>
                  <td>{g._count.children}</td>
                  <td>
                    <div className="admin-row-actions">
                      <AdminModalForm
                        title={`Изменить: ${g.name}`}
                        triggerLabel="Изменить"
                        triggerVariant="ghost"
                        icon="pencil"
                      >
                        {editForm(g)}
                      </AdminModalForm>
                      <form action={deleteGroup}>
                        <input type="hidden" name="id" value={g.id} />
                        <button type="submit" className="admin-btn admin-btn-danger">
                          Удалить
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="admin-cards">
        {groups.map((g) => (
          <article key={g.id} className="admin-card">
            <h2 className="admin-card-title">{g.name}</h2>
            <p className="admin-card-meta">{coachesLabel(g)}</p>
            <div className="admin-card-row">
              <strong>{Number(g.defaultPrice).toLocaleString("ru-RU")} ₽</strong>
              <span className="admin-muted">{g._count.children} детей</span>
            </div>
            <div className="admin-card-actions">
              <AdminModalForm
                title={`Изменить: ${g.name}`}
                triggerLabel="Изменить"
                triggerVariant="ghost"
                icon="pencil"
              >
                {editForm(g)}
              </AdminModalForm>
              <form action={deleteGroup}>
                <input type="hidden" name="id" value={g.id} />
                <button type="submit" className="admin-btn admin-btn-danger">
                  Удалить
                </button>
              </form>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
