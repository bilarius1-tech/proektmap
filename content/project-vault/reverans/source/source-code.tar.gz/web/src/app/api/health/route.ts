import { NextResponse } from "next/server";
import { yandexAuthEnabled } from "@/lib/auth";
import { tbankConfigured } from "@/lib/tbank";

export const dynamic = "force-dynamic";

export function GET() {
  return NextResponse.json({
    ok: true,
    service: "reverans",
    ts: new Date().toISOString(),
    integrations: {
      yandex: yandexAuthEnabled(),
      tbank: tbankConfigured(),
    },
  });
}
