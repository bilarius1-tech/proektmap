import Link from "next/link";
import { ensureCmsSeeded } from "@/lib/cms";
import { prisma } from "@/lib/prisma";

export default async function AdminSiteContentPage() {
  await ensureCmsSeeded();
  const sections = await prisma.siteSection.findMany({ orderBy: { key: "asc" } });
  const home = sections.filter((s) => s.key.startsWith("home."));
  const pages = sections.filter((s) => s.key.startsWith("page."));

  return (
    <div>
      <h1>Тексты и блоки</h1>
      <p className="admin-muted">Выберите блок шаблона — правки сразу на сайте после сохранения.</p>

      <h2>Главная</h2>
      <ul className="admin-list">
        {home.map((s) => (
          <li key={s.key}>
            <Link href={`/admin/site/content/${encodeURIComponent(s.key)}`}>{s.label}</Link>
            <span className="admin-muted">{s.enabled ? "виден" : "скрыт"}</span>
          </li>
        ))}
      </ul>

      <h2>Внутренние страницы</h2>
      <ul className="admin-list">
        {pages.map((s) => (
          <li key={s.key}>
            <Link href={`/admin/site/content/${encodeURIComponent(s.key)}`}>{s.label}</Link>
            <span className="admin-muted">{s.enabled ? "виден" : "скрыт"}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
