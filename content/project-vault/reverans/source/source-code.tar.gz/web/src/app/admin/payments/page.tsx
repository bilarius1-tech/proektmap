import { createPayment, setPaymentStatus } from "@/app/admin/actions";
import { AdminListToolbar, AdminPagination } from "@/components/admin/admin-list-toolbar";
import { AdminModalForm } from "@/components/admin/admin-modal";
import { PaymentStatusBadge } from "@/components/admin/status-badge";
import { normalizeQuery, parsePage, totalPages } from "@/lib/admin-list";
import { paymentTypeLabel } from "@/lib/documents";
import { prisma } from "@/lib/prisma";
import { PaymentStatus, Prisma } from "@prisma/client";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 25;

export default async function AdminPaymentsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string; status?: string; group?: string }>;
}) {
  const sp = await searchParams;
  const q = normalizeQuery(sp.q);
  const statusFilter = sp.status && ["pending", "paid", "failed"].includes(sp.status) ? sp.status : "";
  const groupFilter = (sp.group || "").trim();
  const { page, skip, take } = parsePage(sp.page, PAGE_SIZE);

  const groups = await prisma.group.findMany({ orderBy: { name: "asc" } });
  const groupIds = new Set(groups.map((g) => g.id));
  const activeGroup =
    groupFilter === "none" || groupIds.has(groupFilter) ? groupFilter : "";

  const where: Prisma.PaymentWhereInput = {
    AND: [
      q ? { child: { fullName: { contains: q, mode: "insensitive" } } } : {},
      statusFilter ? { status: statusFilter as PaymentStatus } : {},
      activeGroup === "none"
        ? { child: { groupId: null } }
        : activeGroup
          ? { child: { groupId: activeGroup } }
          : {},
    ],
  };

  const statsWhere: Prisma.PaymentWhereInput = {
    AND: [
      q ? { child: { fullName: { contains: q, mode: "insensitive" } } } : {},
      activeGroup === "none"
        ? { child: { groupId: null } }
        : activeGroup
          ? { child: { groupId: activeGroup } }
          : {},
    ],
  };

  const [total, payments, children, paidAgg, pendingAgg] = await Promise.all([
    prisma.payment.count({ where }),
    prisma.payment.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: { child: { include: { group: true } } },
      skip,
      take,
    }),
    prisma.child.findMany({ orderBy: { fullName: "asc" } }),
    prisma.payment.aggregate({
      where: { ...statsWhere, status: PaymentStatus.paid },
      _sum: { amount: true },
    }),
    prisma.payment.aggregate({
      where: { ...statsWhere, status: PaymentStatus.pending },
      _sum: { amount: true },
    }),
  ]);

  const paid = Number(paidAgg._sum.amount || 0);
  const pendingSum = Number(pendingAgg._sum.amount || 0);
  const pages = totalPages(total, PAGE_SIZE);

  const createForm = (
    <form className="admin-form" action={createPayment}>
      <label>
        Ребёнок
        <select name="childId" required defaultValue="">
          <option value="" disabled>
            Выберите
          </option>
          {children.map((c) => (
            <option key={c.id} value={c.id}>
              {c.fullName}
            </option>
          ))}
        </select>
      </label>
      <label>
        Тип
        <select name="type" defaultValue="monthly">
          <option value="monthly">Абонемент</option>
          <option value="individual">Индивидуальная</option>
        </select>
      </label>
      <label>
        Месяц
        <input name="month" placeholder="2026-10" />
      </label>
      <label>
        Сумма (₽)
        <input name="amount" type="number" step="0.01" required />
      </label>
      <label>
        Статус
        <select name="status" defaultValue="pending">
          <option value="pending">Не оплачено</option>
          <option value="paid">Оплачено</option>
          <option value="failed">Ошибка</option>
        </select>
      </label>
      <button type="submit">Добавить</button>
    </form>
  );

  return (
    <div>
      <div className="admin-page-head">
        <h1>Платежи</h1>
        <AdminModalForm title="Добавить платёж" triggerLabel="Добавить платёж">
          {createForm}
        </AdminModalForm>
      </div>

      <div className="admin-stats">
        <div className="admin-stat">
          <strong>{paid.toLocaleString("ru-RU")} ₽</strong>
          <span>Оплачено{activeGroup || statusFilter ? " (фильтр)" : ""}</span>
        </div>
        <div className="admin-stat">
          <strong>{pendingSum.toLocaleString("ru-RU")} ₽</strong>
          <span>Не оплачено{activeGroup || statusFilter ? " (фильтр)" : ""}</span>
        </div>
      </div>

      <AdminListToolbar
        action="/admin/payments"
        searchPlaceholder="Поиск по ребёнку…"
        q={q}
        filters={
          <>
            <select name="status" defaultValue={statusFilter} aria-label="Статус">
              <option value="">Все статусы</option>
              <option value="pending">Не оплачено</option>
              <option value="paid">Оплачено</option>
              <option value="failed">Ошибка</option>
            </select>
            <select name="group" defaultValue={activeGroup} aria-label="Группа">
              <option value="">Все группы</option>
              <option value="none">Без группы</option>
              {groups.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
            </select>
          </>
        }
      />

      <div className="admin-table-wrap admin-table-desktop">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Ребёнок</th>
              <th>Группа</th>
              <th>Тип</th>
              <th>Месяц</th>
              <th>Сумма</th>
              <th>Статус</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {payments.length === 0 ? (
              <tr>
                <td colSpan={7}>Ничего не найдено</td>
              </tr>
            ) : (
              payments.map((p) => (
                <tr key={p.id}>
                  <td>{p.child.fullName}</td>
                  <td>{p.child.group?.name || "—"}</td>
                  <td>{paymentTypeLabel(p.type)}</td>
                  <td>{p.month || "—"}</td>
                  <td>{Number(p.amount).toLocaleString("ru-RU")} ₽</td>
                  <td>
                    <PaymentStatusBadge status={p.status} />
                  </td>
                  <td>
                    <form action={setPaymentStatus} className="admin-row-actions">
                      <input type="hidden" name="id" value={p.id} />
                      <select name="status" defaultValue={p.status}>
                        <option value="pending">Не оплачено</option>
                        <option value="paid">Оплачено</option>
                        <option value="failed">Ошибка</option>
                      </select>
                      <button type="submit" className="admin-btn">
                        OK
                      </button>
                    </form>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="admin-cards">
        {payments.map((p) => (
          <article key={p.id} className="admin-card">
            <h2 className="admin-card-title">{p.child.fullName}</h2>
            <p className="admin-card-meta">
              {p.child.group?.name || "без группы"} · {paymentTypeLabel(p.type)}
              {p.month ? ` · ${p.month}` : ""}
            </p>
            <div className="admin-card-row">
              <strong>{Number(p.amount).toLocaleString("ru-RU")} ₽</strong>
              <PaymentStatusBadge status={p.status} />
            </div>
            <form action={setPaymentStatus} className="admin-card-actions">
              <input type="hidden" name="id" value={p.id} />
              <select name="status" defaultValue={p.status}>
                <option value="pending">Не оплачено</option>
                <option value="paid">Оплачено</option>
                <option value="failed">Ошибка</option>
              </select>
              <button type="submit" className="admin-btn">
                OK
              </button>
            </form>
          </article>
        ))}
      </div>

      <AdminPagination
        basePath="/admin/payments"
        page={page}
        totalPages={pages}
        q={q}
        extraParams={{
          status: statusFilter || undefined,
          group: activeGroup || undefined,
        }}
      />
    </div>
  );
}
