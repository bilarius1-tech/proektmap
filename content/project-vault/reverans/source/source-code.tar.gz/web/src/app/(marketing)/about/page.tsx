import type { Metadata } from "next";
import Link from "next/link";
import { getPageSeo, getSection } from "@/lib/cms";
import type { PageAboutData } from "@/lib/cms-defaults";

export async function generateMetadata(): Promise<Metadata> {
  const seo = await getPageSeo("/about");
  return { title: seo?.title, description: seo?.description };
}

export default async function AboutPage() {
  const { data } = await getSection<PageAboutData>("page.about");

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <span className="section-kicker">{data.kicker}</span>
          <h1>{data.title}</h1>
          <p>{data.lead}</p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="about-content">
            <div className="about-image">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={data.imageUrl} alt={data.imageAlt} width={640} height={480} />
            </div>
            <div className="about-text">
              <h2>{data.heading}</h2>
              {data.paragraphs.map((p) => (
                <p key={p.slice(0, 20)}>{p}</p>
              ))}
              <ul className="about-list">
                {data.bullets.map((b) => (
                  <li key={b}>
                    <span className="about-list-icon">✓</span>
                    {b}
                  </li>
                ))}
              </ul>
              <p style={{ marginTop: 28 }}>
                <Link href={data.btnHref} className="btn btn-primary">
                  {data.btnText}
                </Link>
              </p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
