import type { Metadata } from "next";
import { GalleryGrid } from "@/components/landing/gallery-grid";
import { getPageSeo, getPublishedGallery, getSection } from "@/lib/cms";
import type { PageGalleryData } from "@/lib/cms-defaults";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const seo = await getPageSeo("/gallery");
  return { title: seo?.title, description: seo?.description };
}

export default async function GalleryPage() {
  const [{ data }, photos] = await Promise.all([
    getSection<PageGalleryData>("page.gallery"),
    getPublishedGallery(),
  ]);

  const items = photos.map((p) => ({
    id: p.id,
    src: p.media.url,
    thumbSrc: p.media.thumbUrl || p.media.url,
    alt: p.alt || p.caption || "Фото клуба",
    caption: p.caption || undefined,
  }));

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <h1>{data.title}</h1>
          <p>{data.lead}</p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          {photos.length === 0 ? (
            <div className="pricing-note">
              <p>Галерея пока пуста</p>
              <p className="muted">Добавьте фото в админке: Сайт → Галерея</p>
            </div>
          ) : (
            <GalleryGrid photos={items} />
          )}
        </div>
      </section>
    </>
  );
}
