import { notFound } from "next/navigation";
import Link from "next/link";
import { SectionEditor } from "@/components/admin/section-editor";
import { ensureCmsSeeded } from "@/lib/cms";
import { prisma } from "@/lib/prisma";

export default async function AdminSectionEditPage({
  params,
}: {
  params: Promise<{ key: string }>;
}) {
  await ensureCmsSeeded();
  const { key: raw } = await params;
  const key = decodeURIComponent(raw);
  const section = await prisma.siteSection.findUnique({ where: { key } });
  if (!section) notFound();

  return (
    <div>
      <p className="admin-muted">
        <Link href="/admin/site/content">← Все блоки</Link>
      </p>
      <SectionEditor
        sectionKey={section.key}
        label={section.label}
        initialEnabled={section.enabled}
        initialData={section.data as Record<string, unknown>}
      />
    </div>
  );
}
