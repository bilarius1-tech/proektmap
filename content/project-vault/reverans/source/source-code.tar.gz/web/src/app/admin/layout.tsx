import { AdminNav } from "@/components/admin/admin-nav";
import { requireAdmin } from "@/lib/session";
import "@/components/admin/admin.css";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await requireAdmin();

  return (
    <div className="admin-shell">
      <AdminNav email={session.user.email || ""} />
      <div className="admin-main">{children}</div>
    </div>
  );
}
