import { SeoAdmin } from "@/components/admin/seo-admin";
import { ensureCmsSeeded } from "@/lib/cms";
import { prisma } from "@/lib/prisma";

export default async function AdminSeoPage() {
  await ensureCmsSeeded();
  const rows = await prisma.pageSeo.findMany({ orderBy: { path: "asc" } });

  return (
    <div>
      <h1>SEO</h1>
      <p className="admin-muted">Title, description и превью сниппета для страниц сайта.</p>
      <SeoAdmin rows={rows} />
    </div>
  );
}
