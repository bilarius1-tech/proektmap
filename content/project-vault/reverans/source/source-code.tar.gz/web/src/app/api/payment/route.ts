import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { PaymentStatus } from "@prisma/client";
import { getOrCreateTrainingPayment } from "@/lib/payments";
import { authOptions } from "@/lib/auth";
import { isUsableParentEmail } from "@/lib/parent-identity-shared";
import { prisma } from "@/lib/prisma";
import { tbankConfigured, tbankInit } from "@/lib/tbank";

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id || (session.user.role !== "parent" && session.user.role !== "coach")) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  if (!tbankConfigured()) {
    return NextResponse.json(
      { error: "Эквайринг ТБанк ещё не подключён. Обратитесь к администратору." },
      { status: 503 },
    );
  }

  const body = (await req.json()) as {
    paymentId?: string;
    trainingId?: string;
    batchId?: string;
  };

  const base = process.env.NEXTAUTH_URL || "https://reverans.online";
  const notificationUrl = `${base}/api/payment/webhook`;

  if (body.batchId) {
    const batch = await prisma.paymentBatch.findUnique({
      where: { id: body.batchId },
      include: {
        parent: true,
        payments: { include: { child: true } },
      },
    });
    if (!batch || batch.parentUserId !== session.user.id) {
      return NextResponse.json({ error: "Платёж не найден" }, { status: 404 });
    }
    if (batch.status === PaymentStatus.paid) {
      return NextResponse.json({ error: "Уже оплачено" }, { status: 400 });
    }
    const amount = Number(batch.amount);
    if (amount <= 0) {
      return NextResponse.json({ error: "Сумма 0" }, { status: 400 });
    }

    const names = batch.payments.map((p) => p.child.fullName).join(", ");
    const orderId = `batch_${batch.id}-${Date.now().toString(36)}`;
    const successUrl = `${base}/cabinet/pay?month=${batch.month || ""}&ok=1`;
    const failUrl = `${base}/cabinet/pay?month=${batch.month || ""}&fail=1`;
    const customerEmail = isUsableParentEmail(batch.parent.email)
      ? batch.parent.email
      : undefined;

    try {
      const init = await tbankInit({
        orderId,
        amountRub: amount,
        description: `Абонемент ${batch.month || ""} — ${names}`,
        successUrl,
        failUrl,
        notificationUrl,
        customerEmail,
      });

      await prisma.paymentBatch.update({
        where: { id: batch.id },
        data: { tbankPaymentId: init.paymentId, status: PaymentStatus.pending },
      });
      await prisma.payment.updateMany({
        where: { batchId: batch.id },
        data: { tbankPaymentId: init.paymentId },
      });

      return NextResponse.json({ paymentUrl: init.paymentUrl });
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Init failed";
      console.error("[payment/init-batch]", { batchId: batch.id, orderId, amount, error: msg });
      return NextResponse.json({ error: msg }, { status: 502 });
    }
  }

  let paymentId = body.paymentId;

  if (body.trainingId) {
    const payment = await getOrCreateTrainingPayment(body.trainingId, session.user.id);
    paymentId = payment.id;
  }

  if (!paymentId) {
    return NextResponse.json({ error: "Не указан платёж" }, { status: 400 });
  }

  const payment = await prisma.payment.findUnique({
    where: { id: paymentId },
    include: { child: { include: { parent: true } } },
  });
  if (!payment || payment.child.userId !== session.user.id) {
    return NextResponse.json({ error: "Платёж не найден" }, { status: 404 });
  }
  if (payment.status === PaymentStatus.paid) {
    return NextResponse.json({ error: "Уже оплачено" }, { status: 400 });
  }
  if (payment.child.isBudget && payment.type === "monthly") {
    return NextResponse.json({ error: "Бюджетное место — абонемент не оплачивается" }, { status: 400 });
  }

  const successUrl = `${base}/cabinet/children/${payment.childId}/pay?ok=1`;
  const failUrl = `${base}/cabinet/children/${payment.childId}/pay?fail=1`;
  const customerEmail = isUsableParentEmail(payment.child.parent?.email)
    ? payment.child.parent!.email
    : undefined;

  const orderId = `${payment.id}-${Date.now().toString(36)}`;

  try {
    const init = await tbankInit({
      orderId,
      amountRub: Number(payment.amount),
      description:
        payment.type === "monthly"
          ? `Абонемент ${payment.month || ""} — ${payment.child.fullName}`
          : `Инд. тренировка — ${payment.child.fullName}`,
      successUrl,
      failUrl,
      notificationUrl,
      customerEmail,
    });

    await prisma.payment.update({
      where: { id: payment.id },
      data: { tbankPaymentId: init.paymentId },
    });

    return NextResponse.json({ paymentUrl: init.paymentUrl });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "Init failed";
    console.error("[payment/init]", {
      paymentId: payment.id,
      orderId,
      amount: Number(payment.amount),
      error: msg,
    });
    return NextResponse.json({ error: msg }, { status: 502 });
  }
}
