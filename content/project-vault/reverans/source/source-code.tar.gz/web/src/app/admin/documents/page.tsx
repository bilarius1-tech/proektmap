import { DocumentStatus, DocumentType, Prisma } from "@prisma/client";
import {
  createDocument,
  rejectMedicalScan,
  setDocumentStatus,
} from "@/app/admin/actions";
import { AdminListToolbar, AdminPagination } from "@/components/admin/admin-list-toolbar";
import { AdminModalForm } from "@/components/admin/admin-modal";
import { MedicalPreview } from "@/components/admin/medical-preview";
import { DocumentStatusBadge } from "@/components/admin/status-badge";
import { normalizeQuery, parsePage, totalPages } from "@/lib/admin-list";
import { DOC_LABELS } from "@/lib/documents";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 30;

function reviewRank(d: {
  type: DocumentType;
  status: DocumentStatus;
  fileUrl: string | null;
}) {
  const needsReview =
    d.type === DocumentType.medical_clearance &&
    d.status === DocumentStatus.pending &&
    Boolean(d.fileUrl);
  return needsReview ? 0 : 1;
}

export default async function AdminDocumentsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string; group?: string }>;
}) {
  const sp = await searchParams;
  const q = normalizeQuery(sp.q);
  const groupFilter = (sp.group || "").trim();
  const { page, skip, take } = parsePage(sp.page, PAGE_SIZE);

  const groups = await prisma.group.findMany({ orderBy: { name: "asc" } });
  const groupIds = new Set(groups.map((g) => g.id));
  const activeGroup =
    groupFilter === "none" || groupIds.has(groupFilter) ? groupFilter : "";

  const where: Prisma.DocumentWhereInput = {
    AND: [
      q
        ? {
            OR: [
              { child: { fullName: { contains: q, mode: "insensitive" } } },
              { fileName: { contains: q, mode: "insensitive" } },
            ],
          }
        : {},
      activeGroup === "none"
        ? { child: { groupId: null } }
        : activeGroup
          ? { child: { groupId: activeGroup } }
          : {},
    ],
  };

  const [total, rawDocuments, children] = await Promise.all([
    prisma.document.count({ where }),
    prisma.document.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: { child: { include: { group: true } } },
      skip,
      take,
    }),
    prisma.child.findMany({ orderBy: { fullName: "asc" } }),
  ]);

  const documents = [...rawDocuments].sort((a, b) => {
    const ra = reviewRank(a);
    const rb = reviewRank(b);
    if (ra !== rb) return ra - rb;
    return b.createdAt.getTime() - a.createdAt.getTime();
  });

  const pages = totalPages(total, PAGE_SIZE);

  const createForm = (
    <form className="admin-form" action={createDocument}>
      <label>
        Ребёнок
        <select name="childId" required defaultValue="">
          <option value="" disabled>
            Выберите
          </option>
          {children.map((c) => (
            <option key={c.id} value={c.id}>
              {c.fullName}
            </option>
          ))}
        </select>
      </label>
      <label>
        Тип
        <select name="type" defaultValue="contract">
          <option value="contract">Договор на занятия</option>
          <option value="consent">Согласие на данные</option>
          <option value="medical_clearance">Медсправка</option>
        </select>
      </label>
      <label>
        Статус
        <select name="status" defaultValue="pending">
          <option value="pending">Ожидает</option>
          <option value="signed">Подписан / подтверждён</option>
          <option value="expired">Истёк</option>
        </select>
      </label>
      <button type="submit">Добавить</button>
    </form>
  );

  return (
    <div>
      <div className="admin-page-head">
        <h1>Документы</h1>
        <AdminModalForm title="Добавить документ" triggerLabel="Добавить документ">
          {createForm}
        </AdminModalForm>
      </div>
      <p className="admin-muted">
        Медсправки: откройте скан → подтвердите или отклоните (родитель загрузит снова). Сначала —
        на проверке.
      </p>

      <AdminListToolbar
        action="/admin/documents"
        searchPlaceholder="Поиск по ребёнку…"
        q={q}
        filters={
          <select name="group" defaultValue={activeGroup} aria-label="Группа">
            <option value="">Все группы</option>
            <option value="none">Без группы</option>
            {groups.map((g) => (
              <option key={g.id} value={g.id}>
                {g.name}
              </option>
            ))}
          </select>
        }
      />

      <div className="admin-table-wrap admin-table-desktop">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Ребёнок</th>
              <th>Группа</th>
              <th>Тип</th>
              <th>Статус</th>
              <th>Скан</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {documents.length === 0 ? (
              <tr>
                <td colSpan={6}>Ничего не найдено</td>
              </tr>
            ) : (
              documents.map((d) => {
                const hasFile = Boolean(d.fileUrl);
                const isPdf = Boolean(
                  d.fileName?.toLowerCase().endsWith(".pdf") || d.fileUrl?.endsWith(".pdf"),
                );
                const isMedical = d.type === DocumentType.medical_clearance;
                return (
                  <tr key={d.id}>
                    <td>{d.child.fullName}</td>
                    <td>{d.child.group?.name || "—"}</td>
                    <td>{DOC_LABELS[d.type] || d.type}</td>
                    <td>
                      <DocumentStatusBadge type={d.type} status={d.status} hasFile={hasFile} />
                    </td>
                    <td>
                      {hasFile && isMedical ? (
                        <MedicalPreview
                          documentId={d.id}
                          fileName={d.fileName}
                          hasThumb={Boolean(d.fileThumbUrl)}
                          isPdf={isPdf}
                        />
                      ) : (
                        "—"
                      )}
                    </td>
                    <td>
                      <div className="admin-row-actions">
                        <form action={setDocumentStatus}>
                          <input type="hidden" name="id" value={d.id} />
                          <select name="status" defaultValue={d.status}>
                            <option value="pending">ожидает</option>
                            <option value="signed">подтверждён</option>
                            <option value="expired">истёк</option>
                          </select>
                          <button type="submit" className="admin-btn">
                            OK
                          </button>
                        </form>
                        {isMedical && hasFile && d.status !== "signed" ? (
                          <>
                            <form action={setDocumentStatus}>
                              <input type="hidden" name="id" value={d.id} />
                              <input type="hidden" name="status" value="signed" />
                              <button type="submit" className="admin-btn">
                                Подтвердить
                              </button>
                            </form>
                            <form action={rejectMedicalScan}>
                              <input type="hidden" name="id" value={d.id} />
                              <button type="submit" className="admin-btn admin-btn-danger">
                                Отклонить
                              </button>
                            </form>
                          </>
                        ) : null}
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <div className="admin-cards">
        {documents.map((d) => {
          const hasFile = Boolean(d.fileUrl);
          const isPdf = Boolean(
            d.fileName?.toLowerCase().endsWith(".pdf") || d.fileUrl?.endsWith(".pdf"),
          );
          const isMedical = d.type === DocumentType.medical_clearance;
          return (
            <article key={d.id} className="admin-card">
              <h2 className="admin-card-title">{d.child.fullName}</h2>
              <p className="admin-card-meta">
                {d.child.group?.name || "без группы"} · {DOC_LABELS[d.type] || d.type}
              </p>
              <div className="admin-card-row">
                <DocumentStatusBadge type={d.type} status={d.status} hasFile={hasFile} />
              </div>
              {hasFile && isMedical ? (
                <MedicalPreview
                  documentId={d.id}
                  fileName={d.fileName}
                  hasThumb={Boolean(d.fileThumbUrl)}
                  isPdf={isPdf}
                />
              ) : null}
              <div className="admin-card-actions">
                <form action={setDocumentStatus} className="admin-row-actions">
                  <input type="hidden" name="id" value={d.id} />
                  <select name="status" defaultValue={d.status}>
                    <option value="pending">ожидает</option>
                    <option value="signed">подтверждён</option>
                    <option value="expired">истёк</option>
                  </select>
                  <button type="submit" className="admin-btn">
                    OK
                  </button>
                </form>
                {isMedical && hasFile && d.status !== "signed" ? (
                  <>
                    <form action={setDocumentStatus}>
                      <input type="hidden" name="id" value={d.id} />
                      <input type="hidden" name="status" value="signed" />
                      <button type="submit" className="admin-btn">
                        Подтвердить
                      </button>
                    </form>
                    <form action={rejectMedicalScan}>
                      <input type="hidden" name="id" value={d.id} />
                      <button type="submit" className="admin-btn admin-btn-danger">
                        Отклонить
                      </button>
                    </form>
                  </>
                ) : null}
              </div>
            </article>
          );
        })}
      </div>

      <AdminPagination
        basePath="/admin/documents"
        page={page}
        totalPages={pages}
        q={q}
        extraParams={{ group: activeGroup || undefined }}
      />
    </div>
  );
}
