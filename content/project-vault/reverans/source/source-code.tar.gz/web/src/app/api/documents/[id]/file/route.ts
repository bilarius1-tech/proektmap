import { readFile, stat } from "fs/promises";
import path from "path";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { DocumentType } from "@prisma/client";
import { authOptions } from "@/lib/auth";
import { medicalDiskPath } from "@/lib/medical-storage";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

const MIME: Record<string, string> = {
  ".webp": "image/webp",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".pdf": "application/pdf",
};

export async function GET(
  req: Request,
  context: { params: Promise<{ id: string }> },
) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id) {
    return new NextResponse("Unauthorized", { status: 401 });
  }

  const { id } = await context.params;
  const wantThumb = new URL(req.url).searchParams.get("thumb") === "1";

  const doc = await prisma.document.findUnique({
    where: { id },
    include: { child: true },
  });
  if (!doc || doc.type !== DocumentType.medical_clearance) {
    return new NextResponse("Not found", { status: 404 });
  }

  const isAdmin = session.user.role === "admin";
  const isOwner = doc.child.userId === session.user.id;
  if (!isAdmin && !isOwner) {
    return new NextResponse("Forbidden", { status: 403 });
  }

  const rel = wantThumb ? doc.fileThumbUrl || doc.fileUrl : doc.fileUrl;
  if (!rel) return new NextResponse("No file", { status: 404 });

  const filePath = medicalDiskPath(rel);
  try {
    const info = await stat(filePath);
    if (!info.isFile()) return new NextResponse("Not found", { status: 404 });
    const buf = await readFile(filePath);
    const ext = path.extname(rel).toLowerCase();
    return new NextResponse(buf, {
      headers: {
        "Content-Type": MIME[ext] || "application/octet-stream",
        "Content-Length": String(info.size),
        "Cache-Control": "private, no-store",
        "Content-Disposition": ext === ".pdf" ? `inline; filename="${doc.fileName || "scan.pdf"}"` : "inline",
      },
    });
  } catch {
    return new NextResponse("Not found", { status: 404 });
  }
}
