"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";
import { deleteGalleryItem, updateGalleryItem } from "@/app/admin/site/actions";

type Item = {
  id: string;
  caption: string;
  alt: string;
  category: string;
  sortOrder: number;
  published: boolean;
  media: { url: string; thumbUrl?: string | null; filename: string };
};

export function GalleryAdmin({ items }: { items: Item[] }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [uploading, setUploading] = useState(false);
  const [toast, setToast] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 4000);
    return () => clearTimeout(t);
  }, [toast]);

  async function onUpload(fileList: FileList | null) {
    if (!fileList?.length) return;
    setUploading(true);
    setToast(null);
    let done = 0;
    try {
      for (const file of Array.from(fileList)) {
        const fd = new FormData();
        fd.set("file", file);
        fd.set("gallery", "true");
        fd.set("alt", file.name.replace(/\.[^.]+$/, ""));
        const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || "Ошибка загрузки");
        done += 1;
      }
      setToast({
        type: "ok",
        text:
          done === 1
            ? "✓ Фото успешно загружено и оптимизировано"
            : `✓ Загружено фото: ${done}. Оптимизация выполнена`,
      });
      router.refresh();
    } catch (e) {
      setToast({
        type: "err",
        text: e instanceof Error ? e.message : "Ошибка загрузки",
      });
    } finally {
      setUploading(false);
    }
  }

  return (
    <div>
      {toast ? (
        <div className={`admin-toast admin-toast-${toast.type}`} role="status">
          {toast.text}
        </div>
      ) : null}

      <div className="admin-form" style={{ maxWidth: 560 }}>
        <h2 style={{ margin: 0 }}>Загрузить фото</h2>
        <p className="admin-muted">
          JPG, PNG, WebP, GIF · до 12 МБ · автоматически WebP + превью
        </p>
        <label className="admin-upload-drop">
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif"
            multiple
            disabled={uploading || pending}
            onChange={(e) => {
              void onUpload(e.target.files);
              e.target.value = "";
            }}
          />
          <span>{uploading ? "Загрузка и оптимизация…" : "Выбрать файлы или перетащить сюда"}</span>
        </label>
      </div>

      <h2>Фото в галерее ({items.length})</h2>
      <div className="admin-gallery-grid">
        {items.map((item) => (
          <div key={item.id} className="admin-gallery-card">
            <button
              type="button"
              className="admin-gallery-thumb"
              onClick={() => setPreview(item.media.url)}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={item.media.thumbUrl || item.media.url}
                alt={item.alt || item.caption}
              />
            </button>
            <form
              className="admin-form"
              style={{ margin: 0, padding: 12, border: "none", background: "transparent" }}
              action={async (fd) => {
                startTransition(async () => {
                  await updateGalleryItem(fd);
                  setToast({ type: "ok", text: "✓ Изменения сохранены" });
                  router.refresh();
                });
              }}
            >
              <input type="hidden" name="id" value={item.id} />
              <label>
                Подпись
                <input name="caption" defaultValue={item.caption} />
              </label>
              <label>
                ALT
                <input name="alt" defaultValue={item.alt} />
              </label>
              <label>
                Категория
                <input name="category" defaultValue={item.category} />
              </label>
              <label>
                Порядок
                <input name="sortOrder" type="number" defaultValue={item.sortOrder} />
              </label>
              <label className="admin-check">
                <input type="hidden" name="published" value="false" />
                <input
                  type="checkbox"
                  name="published"
                  value="true"
                  defaultChecked={item.published}
                />
                Опубликовано
              </label>
              <div className="admin-row-actions">
                <button type="submit" className="admin-btn">
                  Сохранить
                </button>
              </div>
            </form>
            <form
              style={{ padding: "0 12px 12px" }}
              action={async (fd) => {
                startTransition(async () => {
                  await deleteGalleryItem(fd);
                  setToast({ type: "ok", text: "Фото удалено" });
                  router.refresh();
                });
              }}
            >
              <input type="hidden" name="id" value={item.id} />
              <button type="submit" className="admin-btn admin-btn-danger">
                Удалить
              </button>
            </form>
          </div>
        ))}
      </div>

      {preview ? (
        <div className="lightbox" role="dialog" aria-modal="true" onClick={() => setPreview(null)}>
          <div className="lightbox-inner" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              className="lightbox-close"
              onClick={() => setPreview(null)}
              aria-label="Закрыть"
            >
              ✕
            </button>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={preview} alt="" className="lightbox-img" />
          </div>
        </div>
      ) : null}
    </div>
  );
}
