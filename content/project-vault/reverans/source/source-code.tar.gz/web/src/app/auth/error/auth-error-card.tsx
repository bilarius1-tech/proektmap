"use client";

import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { authErrorMessage } from "@/lib/auth-errors";
import "@/components/cabinet/cabinet.css";

export default function AuthErrorCard() {
  const params = useSearchParams();
  const code = params.get("error");
  const { title, detail } = authErrorMessage(code);

  return (
    <div className="cab-auth">
      <div className="cab-auth-card">
        <h1>{title}</h1>
        <p>{detail}</p>
        <div className="cab-error" style={{ marginBottom: 16 }}>
          Авторизация не завершена. Данные аккаунта не изменились.
        </div>
        <div className="cab-actions" style={{ flexDirection: "column" }}>
          <Link href="/login" className="cab-btn">
            Попробовать снова
          </Link>
          <Link href="/register" className="cab-btn cab-btn-secondary">
            Регистрация по email
          </Link>
          <Link href="/" className="cab-btn cab-btn-ghost">
            ← На сайт
          </Link>
        </div>
      </div>
    </div>
  );
}
