import Link from "next/link";
import { ensureCmsSeeded } from "@/lib/cms";
import { prisma } from "@/lib/prisma";

export default async function AdminSiteOverviewPage() {
  await ensureCmsSeeded();
  const [sections, galleryCount, settings] = await Promise.all([
    prisma.siteSection.count(),
    prisma.galleryItem.count({ where: { published: true } }),
    prisma.siteSettings.findUnique({ where: { id: "default" } }),
  ]);

  return (
    <div>
      <h1>Сайт</h1>
      <p className="admin-muted">
        Управление шаблоном: тексты, фото, SEO и Метрика. Оплаты и дети — в разделе «Студия».
      </p>

      <div className="admin-stats">
        <div className="admin-stat">
          <strong>{settings?.brandName || "Реверанс"}</strong>
          <span>Бренд</span>
        </div>
        <div className="admin-stat">
          <strong>{sections}</strong>
          <span>Блоков контента</span>
        </div>
        <div className="admin-stat">
          <strong>{galleryCount}</strong>
          <span>Фото в галерее</span>
        </div>
        <div className="admin-stat">
          <strong>{settings?.yandexMetrikaOn ? "ON" : "OFF"}</strong>
          <span>Яндекс Метрика</span>
        </div>
      </div>

      <h2>Быстрые действия</h2>
      <div className="admin-row-actions" style={{ marginTop: 12 }}>
        <Link href="/admin/site/content" className="admin-btn">
          Редактировать тексты
        </Link>
        <Link href="/admin/site/gallery" className="admin-btn admin-btn-ghost">
          Галерея фото
        </Link>
        <Link href="/admin/site/legal" className="admin-btn admin-btn-ghost">
          Политика и cookies
        </Link>
        <Link href="/admin/site/seo" className="admin-btn admin-btn-ghost">
          SEO
        </Link>
        <Link href="/admin/site/settings" className="admin-btn admin-btn-ghost">
          Контакты и Метрика
        </Link>
        <Link href="/" className="admin-btn admin-btn-ghost" target="_blank">
          Смотреть сайт ↗
        </Link>
      </div>
    </div>
  );
}
