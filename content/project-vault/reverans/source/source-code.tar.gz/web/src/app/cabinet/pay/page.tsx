import Link from "next/link";
import { PaymentStatus } from "@prisma/client";
import { PayButtons } from "@/components/cabinet/pay-buttons";
import { PaymentStatusRefresh } from "@/components/cabinet/payment-status-refresh";
import { requireParent } from "@/lib/session";
import { tbankConfigured } from "@/lib/tbank";
import {
  formatRub,
  monthLabel,
  nearbyMonths,
  resolvePayableMonth,
} from "@/lib/pricing";
import { getOrCreateMonthlyBatch } from "@/lib/payments";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function CabinetPayAllPage({
  searchParams,
}: {
  searchParams: Promise<{ month?: string; ok?: string; fail?: string }>;
}) {
  const sp = await searchParams;
  const session = await requireParent();
  const months = nearbyMonths();
  const month = resolvePayableMonth(sp.month);
  const acquiring = tbankConfigured();

  const children = await prisma.child.findMany({
    where: { userId: session.user.id },
    orderBy: { fullName: "asc" },
  });

  const payable = children.filter((c) => !c.isBudget);
  const budgetKids = children.filter((c) => c.isBudget);

  let batch: Awaited<ReturnType<typeof getOrCreateMonthlyBatch>> | null = null;
  let batchError: string | null = null;
  if (payable.length) {
    try {
      batch = await getOrCreateMonthlyBatch(session.user.id, month);
    } catch (e) {
      batchError = e instanceof Error ? e.message : "Не удалось собрать оплату";
    }
  }

  const allPaid =
    Boolean(batch) &&
    batch!.payments.length > 0 &&
    batch!.payments.every((p) => p.status === PaymentStatus.paid);
  const amount = batch ? Number(batch.amount) : 0;
  const canPay = Boolean(batch) && !allPaid && amount > 0;

  return (
    <>
      <p>
        <Link href="/cabinet">← К списку</Link>
      </p>
      <h1>Оплата абонементов</h1>
      <p className="cab-lead">
        Одна сумма за всех детей за месяц. Бюджетные места в оплату не входят.
      </p>

      {sp.ok && batch ? (
        <>
          <PaymentStatusRefresh paid={allPaid || batch.status === PaymentStatus.paid} />
          <div className="cab-ok">
            {allPaid || batch.status === PaymentStatus.paid
              ? "Оплата подтверждена банком."
              : "Оплата принята. Статус обновится после подтверждения банка."}
          </div>
        </>
      ) : null}
      {sp.fail ? <div className="cab-error">Оплата не завершена. Можно попробовать ещё раз.</div> : null}
      {batchError ? <div className="cab-error">{batchError}</div> : null}

      <div className="cab-actions" style={{ marginBottom: 12 }}>
        {months.map((m) => (
          <Link
            key={m}
            href={`/cabinet/pay?month=${m}`}
            className={`cab-btn ${m === month ? "" : "cab-btn-secondary"}`}
            style={{ flex: "0 1 auto", padding: "8px 12px", fontSize: 13 }}
          >
            {monthLabel(m)}
          </Link>
        ))}
      </div>

      <article className="cab-child-card">
        <h2 style={{ marginTop: 0, fontSize: 18 }}>Абонемент · {monthLabel(month)}</h2>

        {!payable.length ? (
          <p className="cab-child-meta">
            Нет платных абонементов.
            {budgetKids.length ? " Есть только бюджетные места — оплата не требуется." : ""}
          </p>
        ) : (
          <>
            <div className="cab-stack" style={{ marginBottom: 14 }}>
              {(batch?.payments || []).map((p) => (
                <div key={p.id} className="cab-row">
                  <span>
                    {p.child.fullName}
                    {p.status === PaymentStatus.paid ? (
                      <span className="cab-badge cab-badge-ok"> оплачено</span>
                    ) : null}
                  </span>
                  <span>{formatRub(p.amount)}</span>
                </div>
              ))}
              <div className="cab-row">
                <strong>Итого к оплате</strong>
                <strong>{formatRub(allPaid ? 0 : amount)}</strong>
              </div>
            </div>

            {allPaid ? (
              <p className="cab-ok" style={{ marginBottom: 0 }}>
                Всё оплачено за {monthLabel(month)}.
              </p>
            ) : canPay ? (
              <PayButtons
                batchId={batch!.id}
                acquiring={acquiring}
                label={`Оплатить ${formatRub(amount)}`}
              />
            ) : (
              <p className="cab-warn">Сумма 0 — проверьте цены у администратора.</p>
            )}
          </>
        )}

        {budgetKids.length ? (
          <p className="cab-child-meta" style={{ marginTop: 14, marginBottom: 0 }}>
            Бюджет (без оплаты): {budgetKids.map((c) => c.fullName).join(", ")}
          </p>
        ) : null}
      </article>

      <p style={{ marginTop: 16 }}>
        <Link href="/cabinet/history">История платежей →</Link>
      </p>
    </>
  );
}
