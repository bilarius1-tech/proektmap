import type { Metadata } from "next";
import { ContactIcon } from "@/components/icons/contact-icons";
import { resolveContact } from "@/components/landing/contacts-block";
import { getPageSeo, getSection, getSiteSettings } from "@/lib/cms";
import type { PageContactsData } from "@/lib/cms-defaults";

export async function generateMetadata(): Promise<Metadata> {
  const seo = await getPageSeo("/contacts");
  return { title: seo?.title, description: seo?.description };
}

export default async function ContactsPage() {
  const [{ data }, settings] = await Promise.all([
    getSection<PageContactsData>("page.contacts"),
    getSiteSettings(),
  ]);

  const items = (data.items || []).filter((i) => i.enabled !== false);

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <h1>{data.title}</h1>
          <p>{data.lead || `${settings.brandName} — ${settings.tagline}`}</p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="contacts-grid">
            <div className="contacts-info">
              {items.map((item) => {
                const resolved = resolveContact(item, settings);
                if (!resolved) return null;
                return (
                  <div key={`${item.source}-${item.label}`} className="contacts-item">
                    <div className="contacts-icon">
                      <ContactIcon name={item.icon || item.source} />
                    </div>
                    <div>
                      <div className="contacts-label">{item.label}</div>
                      <div className="contacts-value">
                        {resolved.lines ? (
                          <>
                            {resolved.lines[0]}
                            <br />
                            {resolved.lines[1]}
                          </>
                        ) : resolved.href ? (
                          <a
                            href={resolved.href}
                            target={resolved.external ? "_blank" : undefined}
                            rel={resolved.external ? "noopener noreferrer" : undefined}
                          >
                            {item.source === "whatsapp" ? "Написать в WhatsApp" : resolved.value}
                          </a>
                        ) : (
                          resolved.value
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="map-container">
              <div>
                <p style={{ color: "var(--text)", fontWeight: 600, marginBottom: 8 }}>
                  {settings.city}
                </p>
                <p>{settings.address}</p>
                <p style={{ marginTop: 16 }}>
                  <a className="btn btn-primary" href={settings.phoneHref}>
                    Позвонить
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
