import { AboutClub } from "@/components/landing/about-club";
import { ContactsBlock } from "@/components/landing/contacts-block";
import { FinalCta } from "@/components/landing/final-cta";
import { GalleryTeaser } from "@/components/landing/gallery-teaser";
import { Hero } from "@/components/landing/hero";
import { Pricing } from "@/components/landing/pricing";
import { Programs } from "@/components/landing/programs";
import { Services } from "@/components/landing/services";
import { WhyChooseUs } from "@/components/landing/why-choose-us";
import { getHomeContent, getPageSeo } from "@/lib/cms";
import type { Metadata } from "next";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const seo = await getPageSeo("/");
  return {
    title: seo?.title,
    description: seo?.description,
    openGraph: {
      title: seo?.ogTitle || seo?.title || undefined,
      description: seo?.ogDescription || seo?.description || undefined,
      images: seo?.ogImageUrl ? [seo.ogImageUrl] : undefined,
    },
  };
}

export default async function HomePage() {
  const content = await getHomeContent();

  return (
    <>
      <Hero data={content.hero.data} enabled={content.hero.enabled} />
      <WhyChooseUs
        data={content.why.data}
        brandName={content.settings.brandName}
        enabled={content.why.enabled}
      />
      <Programs data={content.programs.data} enabled={content.programs.enabled} />
      <AboutClub data={content.about.data} enabled={content.about.enabled} />
      <Services data={content.services.data} enabled={content.services.enabled} />
      <Pricing
        data={content.pricing.data}
        groups={content.priceGroups}
        enabled={content.pricing.enabled}
      />
      <GalleryTeaser
        data={content.gallery.data}
        photos={content.galleryPhotos}
        enabled={content.gallery.enabled}
      />
      <FinalCta data={content.cta.data} settings={content.settings} enabled={content.cta.enabled} />
      <ContactsBlock
        data={content.contacts.data}
        settings={content.settings}
        enabled={content.contacts.enabled}
      />
    </>
  );
}
