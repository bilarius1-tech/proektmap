import Link from "next/link";
import { requireParent } from "@/lib/session";
import { formatRub, monthLabel } from "@/lib/pricing";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export default async function HistoryPage() {
  const session = await requireParent();
  const payments = await prisma.payment.findMany({
    where: { child: { userId: session.user.id } },
    include: { child: true },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return (
    <>
      <p>
        <Link href="/cabinet">← Кабинет</Link>
      </p>
      <h1>История платежей</h1>
      <p className="cab-lead">Последние операции по вашим детям.</p>

      {payments.length === 0 ? (
        <p className="cab-child-meta">Пока нет платежей.</p>
      ) : (
        <ul className="cab-list">
          {payments.map((p) => (
            <li key={p.id} className="cab-list-item">
              <div>
                <div style={{ fontWeight: 600 }}>{p.child.fullName}</div>
                <div className="cab-child-meta" style={{ margin: 0 }}>
                  {p.type === "monthly"
                    ? `Абонемент${p.month ? ` · ${monthLabel(p.month)}` : ""}`
                    : "Индивидуальная тренировка"}
                  {" · "}
                  {p.createdAt.toLocaleDateString("ru-RU")}
                </div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div>{formatRub(p.amount)}</div>
                <span
                  className={`cab-badge ${
                    p.status === "paid" ? "cab-badge-ok" : p.status === "failed" ? "cab-badge-bad" : "cab-badge-wait"
                  }`}
                >
                  {p.status === "paid" ? "Оплачено" : p.status === "failed" ? "Ошибка" : "Ожидает"}
                </span>
              </div>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
