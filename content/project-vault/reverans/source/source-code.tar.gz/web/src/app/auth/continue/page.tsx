import { redirect } from "next/navigation";
import { getServerSession } from "next-auth";
import { authOptions, homeForRole } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** After OAuth (Yandex): send admin → /admin, parent/coach → /cabinet. */
export default async function AuthContinuePage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    redirect("/login");
  }
  redirect(homeForRole(session.user.role));
}
