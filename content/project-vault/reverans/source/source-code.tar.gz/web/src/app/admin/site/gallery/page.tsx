import { GalleryAdmin } from "./gallery-admin";
import { ensureCmsSeeded } from "@/lib/cms";
import { prisma } from "@/lib/prisma";

export default async function AdminGalleryPage() {
  await ensureCmsSeeded();
  const items = await prisma.galleryItem.findMany({
    orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
    include: { media: true },
  });

  return (
    <div>
      <h1>Галерея</h1>
      <p className="admin-muted">
        Фото на странице /gallery и в блоке «Наши фото» на главной. Студийные оплаты — в разделе
        «Студия».
      </p>
      <GalleryAdmin items={items} />
    </div>
  );
}
