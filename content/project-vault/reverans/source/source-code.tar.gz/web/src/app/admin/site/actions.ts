"use server";

import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import type { Prisma } from "@prisma/client";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { ensureCmsSeeded } from "@/lib/cms";

async function assertAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== "admin") {
    throw new Error("Unauthorized");
  }
  return session;
}

function revalidateSite() {
  revalidatePath("/");
  revalidatePath("/about");
  revalidatePath("/prices");
  revalidatePath("/contacts");
  revalidatePath("/gallery");
  revalidatePath("/admin/site");
  revalidatePath("/admin/site/content");
  revalidatePath("/admin/site/gallery");
  revalidatePath("/admin/site/seo");
  revalidatePath("/admin/site/legal");
  revalidatePath("/politika-v-otnoshenii-obrabotki-personalnyh-dannyh");
  revalidatePath("/soglasie-na-obrabotku-personalnyh-dannyh-pri-ispolzovanii-sayta");
}

export async function updateSiteSettings(formData: FormData) {
  await assertAdmin();
  await ensureCmsSeeded();

  const str = (key: string) => {
    const v = String(formData.get(key) ?? "").trim();
    return v || null;
  };
  const bool = (key: string) => formData.getAll(key).includes("on") || formData.getAll(key).includes("true");

  await prisma.siteSettings.update({
    where: { id: "default" },
    data: {
      brandName: String(formData.get("brandName") || "Реверанс").trim(),
      brandNameRu: String(formData.get("brandNameRu") || "Реверанс").trim(),
      tagline: String(formData.get("tagline") || "").trim(),
      city: String(formData.get("city") || "").trim(),
      address: String(formData.get("address") || "").trim(),
      phoneDisplay: String(formData.get("phoneDisplay") || "").trim(),
      phoneHref: String(formData.get("phoneHref") || "").trim(),
      email: str("email"),
      telegram: str("telegram"),
      telegramHref: str("telegramHref"),
      whatsappHref: str("whatsappHref"),
      instagramHref: str("instagramHref"),
      vkHref: str("vkHref"),
      youtubeHref: str("youtubeHref"),
      logoUrl: str("logoUrl") || "/brand/logo.png",
      footerAbout: str("footerAbout"),
      copyrightText: str("copyrightText"),
      yandexMetrikaId: str("yandexMetrikaId"),
      yandexMetrikaOn: bool("yandexMetrikaOn"),
      yandexWebvisor: bool("yandexWebvisor"),
      yandexVerification: str("yandexVerification"),
      googleAnalyticsId: str("googleAnalyticsId"),
    },
  });

  revalidateSite();
}

export async function updateSection(formData: FormData) {
  await assertAdmin();
  await ensureCmsSeeded();
  const key = String(formData.get("key") || "");
  const enabled = formData.get("enabled") === "on" || formData.get("enabled") === "true";
  const raw = String(formData.get("dataJson") || "");
  if (!key) throw new Error("Нет ключа секции");

  let data: Prisma.InputJsonValue;
  try {
    data = JSON.parse(raw) as Prisma.InputJsonValue;
  } catch {
    throw new Error("Некорректный JSON секции");
  }

  await prisma.siteSection.update({
    where: { key },
    data: { enabled, data },
  });

  revalidateSite();
}

export async function updatePageSeo(formData: FormData) {
  await assertAdmin();
  await ensureCmsSeeded();
  const path = String(formData.get("path") || "");
  if (!path) throw new Error("Нет path");

  await prisma.pageSeo.upsert({
    where: { path },
    create: {
      path,
      title: String(formData.get("title") || "").trim(),
      description: String(formData.get("description") || "").trim(),
      h1: String(formData.get("h1") || "").trim() || null,
      ogTitle: String(formData.get("ogTitle") || "").trim() || null,
      ogDescription: String(formData.get("ogDescription") || "").trim() || null,
      ogImageUrl: String(formData.get("ogImageUrl") || "").trim() || null,
    },
    update: {
      title: String(formData.get("title") || "").trim(),
      description: String(formData.get("description") || "").trim(),
      h1: String(formData.get("h1") || "").trim() || null,
      ogTitle: String(formData.get("ogTitle") || "").trim() || null,
      ogDescription: String(formData.get("ogDescription") || "").trim() || null,
      ogImageUrl: String(formData.get("ogImageUrl") || "").trim() || null,
    },
  });

  revalidateSite();
}

export async function createGalleryItem(formData: FormData) {
  await assertAdmin();
  const mediaId = String(formData.get("mediaId") || "");
  if (!mediaId) throw new Error("Нет mediaId");

  const max = await prisma.galleryItem.aggregate({ _max: { sortOrder: true } });
  await prisma.galleryItem.create({
    data: {
      mediaId,
      caption: String(formData.get("caption") || "").trim(),
      alt: String(formData.get("alt") || "").trim(),
      category: String(formData.get("category") || "Клуб").trim() || "Клуб",
      sortOrder: (max._max.sortOrder ?? 0) + 1,
      published: formData.get("published") !== "false",
    },
  });

  revalidateSite();
}

export async function updateGalleryItem(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;

  await prisma.galleryItem.update({
    where: { id },
    data: {
      caption: String(formData.get("caption") || "").trim(),
      alt: String(formData.get("alt") || "").trim(),
      category: String(formData.get("category") || "Клуб").trim() || "Клуб",
      sortOrder: Number(formData.get("sortOrder") || 0),
      published: formData.getAll("published").includes("true"),
    },
  });

  revalidateSite();
}

export async function deleteGalleryItem(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;
  await prisma.galleryItem.delete({ where: { id } });
  revalidateSite();
}
