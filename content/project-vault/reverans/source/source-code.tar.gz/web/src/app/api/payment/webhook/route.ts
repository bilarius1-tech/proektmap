import { NextRequest, NextResponse } from "next/server";
import { PaymentStatus } from "@prisma/client";
import { markBatchFailed, markBatchPaid } from "@/lib/payments";
import { prisma } from "@/lib/prisma";
import { verifyTbankNotification } from "@/lib/tbank";

function ok() {
  return new NextResponse("OK", {
    status: 200,
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  });
}

async function parseNotification(req: NextRequest): Promise<Record<string, unknown> | null> {
  const text = await req.text();
  if (!text.trim()) return null;
  try {
    return JSON.parse(text) as Record<string, unknown>;
  } catch {
    const form = Object.fromEntries(new URLSearchParams(text));
    return Object.keys(form).length ? form : null;
  }
}

/**
 * ТБанк NotificationURL — проверяем Token, обновляем статус.
 * Ответ должен быть ровно "OK" при успехе.
 */
export async function POST(req: NextRequest) {
  const body = await parseNotification(req);
  if (!body) {
    return new NextResponse("bad body", { status: 400 });
  }

  if (!verifyTbankNotification(body)) {
    return new NextResponse("invalid token", { status: 403 });
  }

  const orderId = String(body.OrderId || "");
  const status = String(body.Status || "");
  const tbankPaymentId = body.PaymentId != null ? String(body.PaymentId) : null;

  if (!orderId && !tbankPaymentId) {
    return ok();
  }

  const paidStatuses = new Set(["CONFIRMED", "AUTHORIZED"]);
  const failedStatuses = new Set(["REJECTED", "CANCELED", "DEADLINE_EXPIRED", "REVERSED"]);

  // Family batch: OrderId = batch_${batchId}-${suffix}
  if (orderId.startsWith("batch_")) {
    const rest = orderId.slice("batch_".length);
    const batchId = rest.includes("-") ? rest.slice(0, rest.indexOf("-")) : rest;
    if (batchId) {
      if (paidStatuses.has(status)) {
        await markBatchPaid(batchId, tbankPaymentId);
      } else if (failedStatuses.has(status)) {
        await markBatchFailed(batchId, tbankPaymentId);
      }
      return ok();
    }
  }

  // OrderId may be `${paymentId}-${suffix}` for Init retries
  const paymentIdFromOrder = orderId.includes("-") ? orderId.slice(0, orderId.indexOf("-")) : orderId;

  const orClauses: { id?: string; tbankPaymentId?: string }[] = [];
  if (orderId) orClauses.push({ id: orderId });
  if (paymentIdFromOrder && paymentIdFromOrder !== orderId) orClauses.push({ id: paymentIdFromOrder });
  if (tbankPaymentId) orClauses.push({ tbankPaymentId });

  const where = orClauses.length ? { OR: orClauses } : { tbankPaymentId: tbankPaymentId! };

  if (paidStatuses.has(status)) {
    await prisma.payment.updateMany({
      where,
      data: {
        status: PaymentStatus.paid,
        paidAt: new Date(),
        tbankPaymentId: tbankPaymentId || undefined,
      },
    });
  } else if (failedStatuses.has(status)) {
    await prisma.payment.updateMany({
      where: { ...where, status: { not: PaymentStatus.paid } },
      data: { status: PaymentStatus.failed, tbankPaymentId: tbankPaymentId || undefined },
    });
  }

  return ok();
}
