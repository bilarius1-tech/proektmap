"use client";

import { signIn } from "next-auth/react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { FormEvent, useState } from "react";
import "@/components/cabinet/cabinet.css";

export default function LoginForm({ yandexEnabled }: { yandexEnabled: boolean }) {
  const router = useRouter();
  const params = useSearchParams();
  const callbackUrl = params.get("callbackUrl") || "/cabinet";
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const fd = new FormData(e.currentTarget);
    const res = await signIn("credentials", {
      email: String(fd.get("email") || ""),
      password: String(fd.get("password") || ""),
      redirect: false,
    });
    setLoading(false);
    if (res?.error) {
      setError("Неверный email или пароль");
      return;
    }

    const sessionRes = await fetch("/api/auth/session");
    const session = await sessionRes.json();
    const role = session?.user?.role as string | undefined;
    const dest =
      role === "admin"
        ? "/admin"
        : callbackUrl.startsWith("/")
          ? callbackUrl
          : "/cabinet";
    router.push(dest);
    router.refresh();
  }

  return (
    <div className="cab-auth">
      <div className="cab-auth-card">
        <h1>Вход</h1>
        <p>Личный кабинет СКХГ «Реверанс»</p>
        {error ? <div className="cab-error">{error}</div> : null}

        {yandexEnabled ? (
          <>
            <button
              type="button"
              className="cab-btn cab-btn-yandex"
              disabled={loading}
            onClick={() => signIn("yandex", { callbackUrl: "/auth/continue" })}
          >
            Войти через Яндекс
          </button>
          <p className="cab-auth-or">или по email</p>
        </>
      ) : null}

      <form className="cab-form" onSubmit={onSubmit}>
        <label>
          Email
          <input name="email" type="email" required autoComplete="username" />
        </label>
        <label>
          Пароль
          <input name="password" type="password" required autoComplete="current-password" />
        </label>
        <button type="submit" className="cab-btn" disabled={loading}>
          {loading ? "Входим…" : "Войти"}
        </button>
      </form>

      <p className="cab-auth-footer">
        Нет аккаунта? <Link href="/register">Зарегистрироваться</Link>
      </p>
      <p className="cab-auth-footer">
        <Link href="/">← На сайт</Link>
      </p>
    </div>
  </div>
);
}
