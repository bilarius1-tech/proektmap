import Link from "next/link";
import { notFound } from "next/navigation";
import { DocumentType } from "@prisma/client";
import { signDocument } from "@/app/cabinet/actions";
import { DocCardHeader, docCardClass } from "@/components/cabinet/doc-ui";
import { IconCreditCard, IconSparkles } from "@/components/icons/doc-icons";
import { MedicalUpload } from "@/components/cabinet/medical-upload";
import { requireParent } from "@/lib/session";
import { documentBody, ensureChildDocuments } from "@/lib/documents";
import { isBudgetPlace } from "@/lib/pricing";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

const DOC_ORDER: DocumentType[] = [
  DocumentType.contract,
  DocumentType.consent,
  DocumentType.medical_clearance,
];

export default async function DocumentsPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const session = await requireParent();
  const child = await prisma.child.findFirst({
    where: { id, userId: session.user.id },
  });
  if (!child) notFound();
  await ensureChildDocuments(child.id);

  const docs = await prisma.document.findMany({
    where: { childId: child.id },
  });
  docs.sort((a, b) => DOC_ORDER.indexOf(a.type) - DOC_ORDER.indexOf(b.type));

  const parentName = session.user.name || session.user.email || "Родитель";
  const signedCount = docs.filter((d) => d.status === "signed").length;
  const budget = isBudgetPlace(child);

  return (
    <>
      <p>
        <Link href={`/cabinet/children/${child.id}`}>← {child.fullName}</Link>
      </p>
      <h1>Документы</h1>
      <p className="cab-lead">
        {budget
          ? "Договор, согласие и медсправка. Место бюджетное — абонемент оплачивать не нужно."
          : "Три коротких шага: договор, согласие и медсправка. Оплату можно сделать отдельно — не обязательно ждать проверку скана."}
      </p>

      <div className="cab-progress">
        <IconSparkles className="cab-progress-svg" />
        <span>
          Готово {signedCount} из {docs.length}
          {signedCount === docs.length ? " — всё оформлено!" : ""}
        </span>
      </div>

      <div className="cab-actions" style={{ marginBottom: 16 }}>
        {budget ? null : (
          <Link href={`/cabinet/children/${child.id}/pay`} className="cab-btn">
            <IconCreditCard className="cab-btn-svg" />
            Перейти к оплате
          </Link>
        )}
        <Link href={`/cabinet/children/${child.id}`} className="cab-btn cab-btn-secondary">
          Карточка ребёнка
        </Link>
      </div>

      <div className="cab-stack">
        {docs.map((doc) => {
          const canSign =
            doc.status !== "signed" &&
            (doc.type === DocumentType.contract || doc.type === DocumentType.consent);
          const hasFile = Boolean(doc.fileUrl);
          return (
            <article key={doc.id} className={docCardClass(doc.type)}>
              <DocCardHeader type={doc.type} status={doc.status} hasFile={hasFile} />
              <div className="cab-doc-body">{documentBody(doc.type, child.fullName, parentName)}</div>
              {doc.status === "signed" && doc.signedAt ? (
                <p className="cab-child-meta">
                  {doc.type === DocumentType.medical_clearance ? "Подтверждено" : "Подписано"}:{" "}
                  {doc.signedAt.toLocaleString("ru-RU")}
                </p>
              ) : null}
              {canSign ? (
                <form action={signDocument} className="cab-form">
                  <input type="hidden" name="documentId" value={doc.id} />
                  <label className="cab-check">
                    <input type="checkbox" name="accepted" required />
                    <span>
                      Я ознакомилась и подписываю от имени законного представителя
                    </span>
                  </label>
                  <button type="submit" className="cab-btn">
                    Подписать
                  </button>
                </form>
              ) : null}
              {doc.type === DocumentType.medical_clearance ? (
                <MedicalUpload
                  documentId={doc.id}
                  hasFile={hasFile}
                  signed={doc.status === "signed"}
                />
              ) : null}
            </article>
          );
        })}
      </div>
    </>
  );
}
