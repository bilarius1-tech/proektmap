import Link from "next/link";
import { CookieBannerEditor, LegalDocEditor } from "@/components/admin/legal-editors";
import { ensureCmsSeeded, getSection } from "@/lib/cms";
import type { CookieBannerData, LegalDocData } from "@/lib/cms-defaults";

export default async function AdminLegalPage() {
  await ensureCmsSeeded();
  const [privacy, consent, banner] = await Promise.all([
    getSection<LegalDocData>("legal.privacy"),
    getSection<LegalDocData>("legal.consent"),
    getSection<CookieBannerData>("legal.cookieBanner"),
  ]);

  return (
    <div>
      <h1>Политика и cookies</h1>
      <p className="admin-muted">
        Документы 152-ФЗ и баннер согласия. Метрика грузится только после «Принять».{" "}
        <Link href="/politika-v-otnoshenii-obrabotki-personalnyh-dannyh" target="_blank">
          Открыть политику ↗
        </Link>
      </p>

      <LegalDocEditor
        sectionKey="legal.privacy"
        label="Политика конфиденциальности"
        initialTitle={privacy.data.title}
        initialUpdatedAt={privacy.data.updatedAt}
        initialHtml={privacy.data.bodyHtml}
      />

      <div style={{ height: 32 }} />

      <LegalDocEditor
        sectionKey="legal.consent"
        label="Согласие на обработку ПДн"
        initialTitle={consent.data.title}
        initialUpdatedAt={consent.data.updatedAt}
        initialHtml={consent.data.bodyHtml}
      />

      <div style={{ height: 32 }} />

      <CookieBannerEditor initial={banner.data} />
    </div>
  );
}
