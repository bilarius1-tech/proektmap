"use client";

import { signIn } from "next-auth/react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useMemo, useState, useTransition } from "react";
import { registerParent } from "@/app/(auth)/actions";
import { REGISTER_CONSENTS } from "@/lib/register-consents";
import "@/components/cabinet/cabinet.css";

export default function RegisterForm({ yandexEnabled }: { yandexEnabled: boolean }) {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();
  const [checks, setChecks] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(REGISTER_CONSENTS.map((c) => [c.id, false])),
  );

  const allChecked = useMemo(
    () => REGISTER_CONSENTS.every((c) => checks[c.id]),
    [checks],
  );

  function toggle(id: string, value: boolean) {
    setChecks((prev) => ({ ...prev, [id]: value }));
  }

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    if (!allChecked) {
      setError("Отметьте все согласия — это обязательно по закону");
      return;
    }
    const fd = new FormData(e.currentTarget);
    startTransition(async () => {
      const result = await registerParent(fd);
      if (!result.ok) {
        setError(result.error);
        return;
      }
      const res = await signIn("credentials", {
        email: String(fd.get("email") || ""),
        password: String(fd.get("password") || ""),
        redirect: false,
      });
      if (res?.error) {
        setError("Аккаунт создан, но вход не удался — попробуйте войти вручную");
        router.push("/login");
        return;
      }
      router.push("/cabinet");
      router.refresh();
    });
  }

  const consentBlock = (
    <fieldset className="cab-consents">
      <legend>Согласия</legend>
      <p className="cab-consents-lead">
        Отметьте каждый пункт и при необходимости скачайте документ.
      </p>
      {REGISTER_CONSENTS.map((c) => (
        <label key={c.id} className="cab-consent-row">
          <input
            type="checkbox"
            name={`consent_${c.id}`}
            checked={checks[c.id] || false}
            onChange={(e) => toggle(c.id, e.target.checked)}
            required
          />
          <span className="cab-consent-body">
            <span className="cab-consent-title">{c.label}</span>
            <a
              className="cab-consent-download"
              href={c.href}
              target="_blank"
              rel="noopener noreferrer"
              download
              onClick={(e) => e.stopPropagation()}
            >
              Скачать
            </a>
          </span>
        </label>
      ))}
    </fieldset>
  );

  return (
    <div className="cab-auth">
      <div className="cab-auth-card">
        <h1>Регистрация</h1>
        <p>Кабинет родителя СКХГ «Реверанс»</p>
        {error ? <div className="cab-error">{error}</div> : null}

        <form className="cab-form" onSubmit={onSubmit}>
          <label>
            Имя
            <input name="name" required autoComplete="name" />
          </label>
          <label>
            Email
            <input name="email" type="email" required autoComplete="email" />
          </label>
          <label>
            Телефон
            <input
              name="phone"
              type="tel"
              autoComplete="tel"
              placeholder="+7… (если админ уже внёс детей — укажите тот же номер)"
            />
          </label>
          <label>
            Пароль
            <input name="password" type="password" required minLength={6} autoComplete="new-password" />
          </label>
          <label>
            Повтор пароля
            <input name="password2" type="password" required minLength={6} autoComplete="new-password" />
          </label>

          {consentBlock}

          <button type="submit" className="cab-btn" disabled={pending || !allChecked}>
            {pending ? "Создаём…" : "Зарегистрироваться"}
          </button>
        </form>

        {yandexEnabled ? (
          <>
            <p className="cab-auth-or">или</p>
            <button
              type="button"
              className="cab-btn cab-btn-yandex"
              disabled={pending || !allChecked}
              title={!allChecked ? "Сначала отметьте все согласия" : undefined}
              onClick={() => signIn("yandex", { callbackUrl: "/auth/continue" })}
            >
              Регистрация через Яндекс
            </button>
            {!allChecked ? (
              <p className="cab-auth-hint">Для входа через Яндекс тоже отметьте все согласия выше</p>
            ) : null}
          </>
        ) : null}

        <p className="cab-auth-footer">
          Уже есть аккаунт? <Link href="/login">Войти</Link>
        </p>
      </div>
    </div>
  );
}
