import { SiteSettingsForm } from "@/components/admin/site-settings-form";
import { getSiteSettings } from "@/lib/cms";

export default async function AdminSiteSettingsPage() {
  const settings = await getSiteSettings();

  return (
    <div>
      <h1>Контакты и Метрика</h1>
      <p className="admin-muted">Глобальные данные сайта. Платежи студии — в «Студия → Платежи».</p>
      <SiteSettingsForm initial={settings} />
    </div>
  );
}
