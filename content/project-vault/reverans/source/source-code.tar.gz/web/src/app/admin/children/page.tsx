import {
  createParentChild,
  deleteChild,
  enrollChild,
  regenerateChildInvite,
  updateChild,
} from "@/app/admin/actions";
import { AdminChildrenBulkBar } from "@/components/admin/admin-children-bulk";
import { AdminListToolbar, AdminPagination } from "@/components/admin/admin-list-toolbar";
import { AdminModalForm } from "@/components/admin/admin-modal";
import { normalizeQuery, parsePage, totalPages } from "@/lib/admin-list";
import { formatParentContact } from "@/lib/parent-identity-shared";
import { prisma } from "@/lib/prisma";
import { Prisma, Role } from "@prisma/client";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 20;

export default async function AdminChildrenPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string; group?: string }>;
}) {
  const sp = await searchParams;
  const q = normalizeQuery(sp.q);
  const groupFilter = (sp.group || "").trim();
  const { page, skip, take } = parsePage(sp.page, PAGE_SIZE);

  const groups = await prisma.group.findMany({ orderBy: { name: "asc" } });
  const groupIds = new Set(groups.map((g) => g.id));
  const activeGroup =
    groupFilter === "none" || groupIds.has(groupFilter) ? groupFilter : "";

  const where: Prisma.ChildWhereInput = {
    AND: [
      q
        ? {
            OR: [
              { fullName: { contains: q, mode: "insensitive" } },
              { inviteCode: { contains: q, mode: "insensitive" } },
              { parent: { email: { contains: q, mode: "insensitive" } } },
              { parent: { name: { contains: q, mode: "insensitive" } } },
            ],
          }
        : {},
      activeGroup === "none"
        ? { groupId: null }
        : activeGroup
          ? { groupId: activeGroup }
          : {},
    ],
  };

  const [total, children, parentUsers] = await Promise.all([
    prisma.child.count({ where }),
    prisma.child.findMany({
      where,
      orderBy: { fullName: "asc" },
      include: { parent: true, group: true },
      skip,
      take,
    }),
    prisma.user.findMany({
      where: { role: Role.parent },
      orderBy: { name: "asc" },
      include: { _count: { select: { children: true } } },
    }),
  ]);

  const pages = totalPages(total, PAGE_SIZE);
  const siblingCount = new Map<string, number>();
  for (const p of parentUsers) {
    siblingCount.set(p.id, p._count.children);
  }
  const parentsForBulk = parentUsers.map((p) => ({
    id: p.id,
    name: p.name,
    email: p.email,
    phone: p.phone,
    childrenCount: p._count.children,
  }));
  const childrenForBulk = children.map((c) => ({
    id: c.id,
    fullName: c.fullName,
    pricePerMonth: Number(c.pricePerMonth),
  }));

  const enrollForm = (
    <form className="admin-form" action={enrollChild}>
      <p className="admin-muted" style={{ marginTop: 0 }}>
        Только имя и группа. Родителю передайте код из списка — он привяжет ребёнка в кабинете.
      </p>
      <label>
        ФИО ребёнка
        <input name="fullName" required placeholder="Иванова Алиса" />
      </label>
      <label>
        Группа
        <select name="groupId" required defaultValue="">
          <option value="" disabled>
            Выберите группу
          </option>
          {groups.map((g) => (
            <option key={g.id} value={g.id}>
              {g.name} · {Number(g.defaultPrice).toLocaleString("ru-RU")} ₽
            </option>
          ))}
        </select>
      </label>
      <label>
        Дата рождения (необязательно)
        <input name="dateOfBirth" type="date" />
      </label>
      <label className="admin-check">
        <input name="isBudget" type="checkbox" />
        Бюджетное место (абонемент не оплачивается)
      </label>
      <button type="submit">Зачислить</button>
    </form>
  );

  const createWithParentForm = (
    <form className="admin-form" action={createParentChild}>
      <p className="admin-muted" style={{ marginTop: 0 }}>
        Email можно не указывать: достаточно телефона — родитель сам добавит почту при регистрации.
        Цену и скидку задаёте вы вручную.
      </p>
      <label>
        ФИО родителя
        <input name="parentName" required />
      </label>
      <label>
        Телефон родителя
        <input name="parentPhone" type="tel" placeholder="+7… (нужен, если нет email)" />
      </label>
      <label>
        Email родителя (необязательно)
        <input name="parentEmail" type="email" placeholder="можно позже" />
      </label>
      <label>
        ФИО ребёнка
        <input name="fullName" required />
      </label>
      <label>
        Дата рождения
        <input name="dateOfBirth" type="date" required />
      </label>
      <label>
        Группа
        <select name="groupId" defaultValue="">
          <option value="">— без группы —</option>
          {groups.map((g) => (
            <option key={g.id} value={g.id}>
              {g.name}
            </option>
          ))}
        </select>
      </label>
      <label>
        Цена / месяц (₽)
        <input name="pricePerMonth" type="number" step="0.01" defaultValue={3500} />
      </label>
      <label>
        Скидка (₽)
        <input name="discount" type="number" step="0.01" defaultValue={0} />
      </label>
      <label>
        Причина скидки
        <input name="discountReason" placeholder="сестра" />
      </label>
      <label className="admin-check">
        <input name="isBudget" type="checkbox" />
        Бюджетное место (абонемент не оплачивается)
      </label>
      <button type="submit">Добавить</button>
    </form>
  );

  function editForm(c: (typeof children)[number]) {
    return (
      <form className="admin-form" action={updateChild}>
        <input type="hidden" name="id" value={c.id} />
        <label>
          ФИО ребёнка
          <input name="fullName" defaultValue={c.fullName} required />
        </label>
        <label>
          Группа
          <select name="groupId" defaultValue={c.groupId || ""}>
            <option value="">— без группы —</option>
            {groups.map((g) => (
              <option key={g.id} value={g.id}>
                {g.name}
              </option>
            ))}
          </select>
        </label>
        <label>
          Цена / месяц (₽)
          <input
            name="pricePerMonth"
            type="number"
            step="0.01"
            defaultValue={Number(c.pricePerMonth)}
          />
        </label>
        <label>
          Скидка (₽)
          <input name="discount" type="number" step="0.01" defaultValue={Number(c.discount)} />
        </label>
        <label>
          Причина скидки
          <input name="discountReason" defaultValue={c.discountReason || ""} placeholder="скидка" />
        </label>
        <label className="admin-check">
          <input name="isBudget" type="checkbox" defaultChecked={c.isBudget} />
          Бюджетное место (абонемент не оплачивается)
        </label>
        <button type="submit">Сохранить</button>
      </form>
    );
  }

  return (
    <div>
      <div className="admin-page-head">
        <h1>Дети</h1>
        <div className="admin-row-actions">
          <AdminModalForm title="Зачислить в группу" triggerLabel="Зачислить">
            {enrollForm}
          </AdminModalForm>
          <AdminModalForm
            title="Ребёнок + родитель"
            triggerLabel="С родителем"
            triggerVariant="ghost"
            icon="none"
          >
            {createWithParentForm}
          </AdminModalForm>
        </div>
      </div>

      <AdminListToolbar
        action="/admin/children"
        searchPlaceholder="Имя, код или email родителя…"
        q={q}
        filters={
          <select name="group" defaultValue={activeGroup} aria-label="Группа">
            <option value="">Все группы</option>
            <option value="none">Без группы</option>
            {groups.map((g) => (
              <option key={g.id} value={g.id}>
                {g.name}
              </option>
            ))}
          </select>
        }
      />

      <AdminChildrenBulkBar parents={parentsForBulk} childrenOptions={childrenForBulk} />

      <div className="admin-table-wrap admin-table-desktop">
        <table className="admin-table">
          <thead>
            <tr>
              <th style={{ width: 36 }}></th>
              <th>Ребёнок</th>
              <th>Родитель / код</th>
              <th>Группа</th>
              <th>Цена</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {children.length === 0 ? (
              <tr>
                <td colSpan={6}>Ничего не найдено</td>
              </tr>
            ) : (
              children.map((c) => (
                <tr key={c.id}>
                  <td>
                    <input
                      type="checkbox"
                      className="admin-child-check"
                      name="childIds"
                      value={c.id}
                      aria-label={`Выбрать ${c.fullName}`}
                    />
                  </td>
                  <td>
                    <div>{c.fullName}</div>
                    <div className="admin-muted">
                      {c.dateOfBirth ? c.dateOfBirth.toISOString().slice(0, 10) : "ДР не указана"}
                    </div>
                  </td>
                  <td>
                    {c.parent ? (
                      <>
                        {c.parent.name}
                        <div className="admin-muted">{formatParentContact(c.parent)}</div>
                        {(siblingCount.get(c.parent.id) || 0) > 1 ? (
                          <div className="admin-status admin-status-review" style={{ marginTop: 6 }}>
                            {siblingCount.get(c.parent.id)} детей у родителя
                          </div>
                        ) : null}
                      </>
                    ) : (
                      <span className="admin-status admin-status-wait">Ждёт родителя</span>
                    )}
                    {c.inviteCode ? (
                      <div className="admin-muted" style={{ marginTop: 6 }}>
                        Код: <strong style={{ letterSpacing: "0.06em" }}>{c.inviteCode}</strong>
                      </div>
                    ) : null}
                    <form action={regenerateChildInvite} style={{ marginTop: 6 }}>
                      <input type="hidden" name="id" value={c.id} />
                      <button type="submit" className="admin-btn admin-btn-ghost">
                        {c.inviteCode ? "Новый код" : "Выдать код"}
                      </button>
                    </form>
                  </td>
                  <td>{c.group?.name || "—"}</td>
                  <td>
                    {c.isBudget ? (
                      <span className="admin-status admin-status-ok">Бюджет</span>
                    ) : (
                      <>
                        {Number(c.pricePerMonth).toLocaleString("ru-RU")} ₽
                        {Number(c.discount) > 0 ? (
                          <div className="admin-muted">−{Number(c.discount).toLocaleString("ru-RU")} ₽</div>
                        ) : null}
                      </>
                    )}
                  </td>
                  <td>
                    <div className="admin-row-actions">
                      <AdminModalForm
                        title={`Изменить: ${c.fullName}`}
                        triggerLabel="Изменить"
                        triggerVariant="ghost"
                        icon="pencil"
                      >
                        {editForm(c)}
                      </AdminModalForm>
                      <form action={deleteChild}>
                        <input type="hidden" name="id" value={c.id} />
                        <button type="submit" className="admin-btn admin-btn-danger">
                          Удалить
                        </button>
                      </form>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="admin-cards">
        {children.map((c) => (
          <article key={c.id} className="admin-card">
            <label className="admin-check" style={{ marginBottom: 4 }}>
              <input type="checkbox" className="admin-child-check" value={c.id} />
              Выбрать
            </label>
            <h2 className="admin-card-title">{c.fullName}</h2>
            <p className="admin-card-meta">
              {c.group?.name || "Без группы"}
              {c.dateOfBirth ? ` · ${c.dateOfBirth.toISOString().slice(0, 10)}` : ""}
            </p>
            <div className="admin-card-row">
              {c.isBudget ? (
                <span className="admin-status admin-status-ok">Бюджет</span>
              ) : (
                <span>
                  {Number(c.pricePerMonth).toLocaleString("ru-RU")} ₽
                  {Number(c.discount) > 0 ? ` (−${Number(c.discount).toLocaleString("ru-RU")})` : ""}
                </span>
              )}
              {!c.parent ? <span className="admin-status admin-status-wait">Ждёт родителя</span> : null}
              {c.parent && (siblingCount.get(c.parent.id) || 0) > 1 ? (
                <span className="admin-status admin-status-review">
                  {siblingCount.get(c.parent.id)} детей
                </span>
              ) : null}
            </div>
            {c.parent ? (
              <p className="admin-card-meta">
                {c.parent.name} · {formatParentContact(c.parent)}
              </p>
            ) : null}
            {c.inviteCode ? (
              <p className="admin-card-meta">
                Код: <strong style={{ letterSpacing: "0.06em" }}>{c.inviteCode}</strong>
              </p>
            ) : null}
            <div className="admin-card-actions">
              <form action={regenerateChildInvite}>
                <input type="hidden" name="id" value={c.id} />
                <button type="submit" className="admin-btn admin-btn-ghost">
                  {c.inviteCode ? "Новый код" : "Выдать код"}
                </button>
              </form>
              <AdminModalForm
                title={`Изменить: ${c.fullName}`}
                triggerLabel="Изменить"
                triggerVariant="ghost"
                icon="pencil"
              >
                {editForm(c)}
              </AdminModalForm>
              <form action={deleteChild}>
                <input type="hidden" name="id" value={c.id} />
                <button type="submit" className="admin-btn admin-btn-danger">
                  Удалить
                </button>
              </form>
            </div>
          </article>
        ))}
      </div>

      <AdminPagination
        basePath="/admin/children"
        page={page}
        totalPages={pages}
        q={q}
        extraParams={{ group: activeGroup || undefined }}
      />
    </div>
  );
}
