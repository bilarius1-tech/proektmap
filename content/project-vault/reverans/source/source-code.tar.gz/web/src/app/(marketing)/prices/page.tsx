import type { Metadata } from "next";
import { PriceGroups } from "@/components/landing/price-groups";
import { getPageSeo, getSection } from "@/lib/cms";
import type { PagePricesData } from "@/lib/cms-defaults";

export async function generateMetadata(): Promise<Metadata> {
  const seo = await getPageSeo("/prices");
  return { title: seo?.title, description: seo?.description };
}

export default async function PricesPage() {
  const { data } = await getSection<PagePricesData>("page.prices");

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <h1>{data.title}</h1>
          <p>{data.lead}</p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <PriceGroups groups={data.groups || []} />
          {(data.note || data.noteMuted) && (
            <div className="pricing-note" style={{ marginTop: 40 }}>
              {data.note ? <p>{data.note}</p> : null}
              {data.noteMuted ? <p className="muted">{data.noteMuted}</p> : null}
            </div>
          )}
        </div>
      </section>
    </>
  );
}
