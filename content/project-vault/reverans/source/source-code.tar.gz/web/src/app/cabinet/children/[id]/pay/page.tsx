import Link from "next/link";
import { notFound } from "next/navigation";
import { PaymentStatus } from "@prisma/client";
import { PayButtons } from "@/components/cabinet/pay-buttons";
import { PaymentStatusRefresh } from "@/components/cabinet/payment-status-refresh";
import { requireParent } from "@/lib/session";
import { tbankConfigured } from "@/lib/tbank";
import {
  childMonthAmount,
  formatRub,
  isBudgetPlace,
  monthLabel,
  nearbyMonths,
  resolvePayableMonth,
} from "@/lib/pricing";
import { prisma } from "@/lib/prisma";
import { getOrCreateMonthlyPayment } from "@/lib/payments";

export const dynamic = "force-dynamic";

export default async function PayPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ month?: string; ok?: string; fail?: string }>;
}) {
  const { id } = await params;
  const sp = await searchParams;
  const session = await requireParent();
  const child = await prisma.child.findFirst({
    where: { id, userId: session.user.id },
    include: {
      individualTrainings: {
        include: { payment: true, coach: true },
        orderBy: { date: "asc" },
      },
    },
  });
  if (!child) notFound();

  const budget = isBudgetPlace(child);
  const months = nearbyMonths();
  const month = resolvePayableMonth(sp.month);
  const amount = childMonthAmount(child.pricePerMonth, child.discount);
  const payment = budget ? null : await getOrCreateMonthlyPayment(child.id, month);
  const acquiring = tbankConfigured();

  const unpaidTrainings = child.individualTrainings.filter(
    (t) => !t.payment || t.payment.status !== PaymentStatus.paid,
  );

  const trainingGroups = (() => {
    const map = new Map<string, typeof unpaidTrainings>();
    for (const t of unpaidTrainings) {
      const key = t.packageId || t.id;
      const list = map.get(key) || [];
      list.push(t);
      map.set(key, list);
    }
    return Array.from(map.entries()).map(([key, items]) => ({
      key,
      items,
      total: items.reduce((sum, x) => sum + Number(x.price), 0),
      payTrainingId: items[0].id,
      coachName: items[0].coach?.name,
      isPackage: Boolean(items[0].packageId) && items.length > 1,
    }));
  })();

  const trainingSection =
    trainingGroups.length > 0 ? (
      <section style={{ marginTop: 20 }}>
        <h2 style={{ fontSize: 18 }}>Индивидуальные тренировки</h2>
        <ul className="cab-list">
          {trainingGroups.map((g) => (
            <li
              key={g.key}
              className="cab-list-item"
              style={{ flexDirection: "column", alignItems: "stretch" }}
            >
              {g.isPackage ? (
                <>
                  <div className="cab-row">
                    <strong>Пакет · {g.items.length} занят.</strong>
                    <strong>{formatRub(g.total)}</strong>
                  </div>
                  <ul style={{ margin: "6px 0 10px", paddingLeft: 18 }}>
                    {g.items.map((t) => (
                      <li key={t.id} style={{ marginBottom: 4, color: "var(--cab-muted, #7a6b5d)" }}>
                        {t.date.toLocaleDateString("ru-RU")} · {t.time}
                        {g.coachName ? ` · ${g.coachName}` : ""}
                      </li>
                    ))}
                  </ul>
                </>
              ) : (
                <div className="cab-row">
                  <span>
                    {g.items[0].date.toLocaleDateString("ru-RU")} · {g.items[0].time}
                    {g.coachName ? ` · ${g.coachName}` : ""}
                  </span>
                  <strong>{formatRub(g.total)}</strong>
                </div>
              )}
              <PayButtons
                trainingId={g.payTrainingId}
                acquiring={acquiring}
                label={`Оплатить ${formatRub(g.total)}`}
              />
            </li>
          ))}
        </ul>
      </section>
    ) : null;

  if (budget) {
    return (
      <>
        <p>
          <Link href={`/cabinet/children/${child.id}`}>← {child.fullName}</Link>
        </p>
        <h1>Оплата</h1>
        <article className="cab-child-card">
          <p className="cab-lead" style={{ marginTop: 0 }}>
            <span className="cab-badge cab-badge-ok">бюджет</span>
            {" · "}
            Абонемент не оплачивается. Документы и группа — как обычно.
          </p>
          <Link href={`/cabinet/children/${child.id}/documents`} className="cab-btn cab-btn-secondary">
            К документам
          </Link>
        </article>

        {trainingSection}
      </>
    );
  }

  return (
    <>
      <p>
        <Link href={`/cabinet/children/${child.id}`}>← {child.fullName}</Link>
      </p>
      <h1>Оплата</h1>
      <p className="cab-lead">Абонемент по месяцам и индивидуальные тренировки.</p>

      {sp.ok && payment ? (
        <>
          <PaymentStatusRefresh paid={payment.status === PaymentStatus.paid} />
          <div className="cab-ok">
            {payment.status === PaymentStatus.paid
              ? "Оплата подтверждена банком."
              : "Оплата принята. Статус обновится после подтверждения банка."}
          </div>
        </>
      ) : null}
      {sp.fail ? <div className="cab-error">Оплата не завершена. Можно попробовать ещё раз.</div> : null}

      <article className="cab-child-card">
        <h2 style={{ marginTop: 0, fontSize: 18 }}>{monthLabel(month)}</h2>
        <p className="cab-child-meta" style={{ marginBottom: 12 }}>
          Статус:{" "}
          <span
            className={`cab-badge ${
              payment!.status === PaymentStatus.paid
                ? "cab-badge-ok"
                : payment!.status === PaymentStatus.failed
                  ? "cab-badge-bad"
                  : "cab-badge-wait"
            }`}
          >
            {payment!.status === PaymentStatus.paid
              ? "Оплачено"
              : payment!.status === PaymentStatus.failed
                ? "Ошибка"
                : "Не оплачено"}
          </span>
        </p>

        <div className="cab-stack" style={{ marginBottom: 14 }}>
          <div className="cab-row">
            <span>Абонемент</span>
            <span>{formatRub(child.pricePerMonth)}</span>
          </div>
          {Number(child.discount) > 0 ? (
            <div className="cab-row">
              <span>Скидка{child.discountReason ? ` (${child.discountReason})` : ""}</span>
              <span>− {formatRub(child.discount)}</span>
            </div>
          ) : null}
          <div className="cab-row">
            <strong>К оплате</strong>
            <strong>{formatRub(amount)}</strong>
          </div>
        </div>

        <div className="cab-actions" style={{ marginBottom: 12 }}>
          {months.map((m) => (
            <Link
              key={m}
              href={`/cabinet/children/${child.id}/pay?month=${m}`}
              className={`cab-btn ${m === month ? "" : "cab-btn-secondary"}`}
              style={{ flex: "0 1 auto", padding: "8px 12px", fontSize: 13 }}
            >
              {monthLabel(m)}
            </Link>
          ))}
        </div>

        {payment!.status !== PaymentStatus.paid ? (
          amount > 0 ? (
            <PayButtons
              paymentId={payment!.id}
              acquiring={acquiring}
              label={`Оплатить ${formatRub(amount)}`}
            />
          ) : (
            <p className="cab-warn">
              Стоимость ещё не назначена администратором — кнопка оплаты появится после назначения
              цены (и группы) в админке.
            </p>
          )
        ) : null}

        {!acquiring ? (
          <p className="cab-warn" style={{ marginTop: 12, marginBottom: 0 }}>
            Онлайн-эквайринг ТБанк будет доступен после подключения терминала. Администратор может
            отметить оплату вручную.
          </p>
        ) : null}
      </article>

      {trainingSection}

      <p style={{ marginTop: 16 }}>
        <Link href="/cabinet/history">История платежей →</Link>
      </p>
    </>
  );
}
