import type { Metadata } from "next";
import { getPageSeo, getSection } from "@/lib/cms";
import type { LegalDocData } from "@/lib/cms-defaults";

export const dynamic = "force-dynamic";

const PATH = "/politika-v-otnoshenii-obrabotki-personalnyh-dannyh";

export async function generateMetadata(): Promise<Metadata> {
  const seo = await getPageSeo(PATH);
  return { title: seo?.title, description: seo?.description };
}

export default async function PrivacyPolicyPage() {
  const { data } = await getSection<LegalDocData>("legal.privacy");

  return (
    <>
      <section className="page-hero">
        <div className="container">
          <h1>{data.title}</h1>
          {data.updatedAt ? <p>Дата редакции: {data.updatedAt}</p> : null}
        </div>
      </section>
      <section className="section">
        <div className="container legal-doc">
          <div
            className="legal-doc-body"
            dangerouslySetInnerHTML={{ __html: data.bodyHtml }}
          />
        </div>
      </section>
    </>
  );
}
