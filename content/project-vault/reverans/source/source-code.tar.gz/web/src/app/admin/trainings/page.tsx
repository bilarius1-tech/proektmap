import {
  createIndividualTraining,
  deleteIndividualTraining,
} from "@/app/admin/actions";
import { AdminListToolbar, AdminPagination } from "@/components/admin/admin-list-toolbar";
import { AdminModalForm } from "@/components/admin/admin-modal";
import { AdminTrainingPackageForm } from "@/components/admin/admin-training-package-form";
import { PaymentStatusBadge } from "@/components/admin/status-badge";
import { normalizeQuery, parsePage, totalPages } from "@/lib/admin-list";
import { formatRub } from "@/lib/pricing";
import { prisma } from "@/lib/prisma";
import { Prisma, Role } from "@prisma/client";

export const dynamic = "force-dynamic";

const PAGE_SIZE = 20;

export default async function AdminTrainingsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string; scope?: string; from?: string; to?: string }>;
}) {
  const sp = await searchParams;
  const q = normalizeQuery(sp.q);
  const scope = sp.scope === "upcoming" ? "upcoming" : "";
  const from = (sp.from || "").trim();
  const to = (sp.to || "").trim();
  const { page, skip, take } = parsePage(sp.page, PAGE_SIZE);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const where: Prisma.IndividualTrainingWhereInput = {
    AND: [
      q ? { child: { fullName: { contains: q, mode: "insensitive" } } } : {},
      scope === "upcoming" ? { date: { gte: today } } : {},
      from ? { date: { gte: new Date(from) } } : {},
      to
        ? {
            date: {
              lte: (() => {
                const d = new Date(to);
                d.setHours(23, 59, 59, 999);
                return d;
              })(),
            },
          }
        : {},
    ],
  };

  const [total, trainings, children, coaches] = await Promise.all([
    prisma.individualTraining.count({ where }),
    prisma.individualTraining.findMany({
      where,
      orderBy: [{ date: "desc" }, { time: "desc" }],
      include: {
        child: true,
        coach: true,
        payment: true,
      },
      skip,
      take,
    }),
    prisma.child.findMany({ orderBy: { fullName: "asc" } }),
    prisma.user.findMany({ where: { role: Role.coach }, orderBy: { name: "asc" } }),
  ]);

  const pages = totalPages(total, PAGE_SIZE);
  const childOpts = children.map((c) => ({ id: c.id, label: c.fullName }));
  const coachOpts = coaches.map((c) => ({ id: c.id, label: c.name }));

  const createForm = (
    <form className="admin-form" action={createIndividualTraining}>
      <label>
        Ребёнок
        <select name="childId" required defaultValue="">
          <option value="" disabled>
            Выберите
          </option>
          {children.map((c) => (
            <option key={c.id} value={c.id}>
              {c.fullName}
            </option>
          ))}
        </select>
      </label>
      <label>
        Педагог
        <select name="coachId" required defaultValue="">
          <option value="" disabled>
            Выберите
          </option>
          {coaches.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </label>
      <label>
        Дата
        <input name="date" type="date" required />
      </label>
      <label>
        Время
        <input name="time" placeholder="16:00" required />
      </label>
      <label>
        Цена, ₽
        <input name="price" type="number" step="0.01" required defaultValue={2000} />
      </label>
      <button type="submit">Создать</button>
    </form>
  );

  return (
    <div>
      <div className="admin-page-head">
        <h1>Индивидуальные тренировки</h1>
        <div className="admin-row-actions">
          <AdminModalForm title="Разовая тренировка" triggerLabel="Разовая">
            {createForm}
          </AdminModalForm>
          <AdminModalForm title="Пакет тренировок" triggerLabel="Пакет">
            <AdminTrainingPackageForm childrenOptions={childOpts} coaches={coachOpts} />
          </AdminModalForm>
        </div>
      </div>
      <p className="admin-muted">
        Разовая — одно занятие. Пакет — несколько дат и одна сумма (родитель платит один раз).
      </p>

      <AdminListToolbar
        action="/admin/trainings"
        searchPlaceholder="Поиск по ребёнку…"
        q={q}
        filters={
          <>
            <select name="scope" defaultValue={scope} aria-label="Период">
              <option value="">Все даты</option>
              <option value="upcoming">Предстоящие</option>
            </select>
            <label className="admin-muted" style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
              от
              <input type="date" name="from" defaultValue={from} />
            </label>
            <label className="admin-muted" style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
              до
              <input type="date" name="to" defaultValue={to} />
            </label>
          </>
        }
      />

      <div className="admin-table-wrap admin-table-desktop">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Дата</th>
              <th>Ребёнок</th>
              <th>Педагог</th>
              <th>Цена</th>
              <th>Оплата</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {trainings.length === 0 ? (
              <tr>
                <td colSpan={6}>Ничего не найдено</td>
              </tr>
            ) : (
              trainings.map((t) => (
                <tr key={t.id}>
                  <td>
                    {t.date.toLocaleDateString("ru-RU")} {t.time}
                    {t.packageId ? (
                      <div className="admin-muted" style={{ fontSize: 12 }}>
                        пакет
                      </div>
                    ) : null}
                  </td>
                  <td>{t.child.fullName}</td>
                  <td>{t.coach.name}</td>
                  <td>{formatRub(t.price)}</td>
                  <td>{t.payment ? <PaymentStatusBadge status={t.payment.status} /> : "—"}</td>
                  <td>
                    <form action={deleteIndividualTraining}>
                      <input type="hidden" name="id" value={t.id} />
                      <button type="submit" className="admin-btn admin-btn-danger">
                        Удалить
                      </button>
                    </form>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <div className="admin-cards">
        {trainings.map((t) => (
          <article key={t.id} className="admin-card">
            <h2 className="admin-card-title">{t.child.fullName}</h2>
            <p className="admin-card-meta">
              {t.date.toLocaleDateString("ru-RU")} {t.time} · {t.coach.name}
              {t.packageId ? " · пакет" : ""}
            </p>
            <div className="admin-card-row">
              <strong>{formatRub(t.price)}</strong>
              {t.payment ? <PaymentStatusBadge status={t.payment.status} /> : <span>—</span>}
            </div>
            <div className="admin-card-actions">
              <form action={deleteIndividualTraining}>
                <input type="hidden" name="id" value={t.id} />
                <button type="submit" className="admin-btn admin-btn-danger">
                  Удалить
                </button>
              </form>
            </div>
          </article>
        ))}
      </div>

      <AdminPagination
        basePath="/admin/trainings"
        page={page}
        totalPages={pages}
        q={q}
        extraParams={{
          scope: scope || undefined,
          from: from || undefined,
          to: to || undefined,
        }}
      />
    </div>
  );
}
