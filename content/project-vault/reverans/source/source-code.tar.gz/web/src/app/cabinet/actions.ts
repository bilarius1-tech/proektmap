"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { DocumentStatus, DocumentType } from "@prisma/client";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { ensureChildDocuments } from "@/lib/documents";
import { normalizeInviteCode } from "@/lib/invite";
import { prisma } from "@/lib/prisma";

async function requireParentSession() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.id || (session.user.role !== "parent" && session.user.role !== "coach")) {
    throw new Error("Unauthorized");
  }
  return session;
}

export async function addChild(formData: FormData) {
  const session = await requireParentSession();
  const fullName = String(formData.get("fullName") || "").trim();
  const dateOfBirth = String(formData.get("dateOfBirth") || "");
  if (!fullName || !dateOfBirth) throw new Error("Укажите ФИО и дату рождения");

  const child = await prisma.child.create({
    data: {
      userId: session.user.id,
      fullName,
      dateOfBirth: new Date(dateOfBirth),
      pricePerMonth: 0,
      discount: 0,
    },
  });
  await ensureChildDocuments(child.id);
  revalidatePath("/cabinet");
  redirect(`/cabinet/children/${child.id}`);
}

/** Родитель привязывает ребёнка по коду из админки. Код можно оставить справочным. */
export async function claimChild(formData: FormData) {
  const session = await requireParentSession();
  const code = normalizeInviteCode(String(formData.get("inviteCode") || ""));
  const dateOfBirth = String(formData.get("dateOfBirth") || "").trim();
  if (!code) throw new Error("Введите код приглашения");
  if (!dateOfBirth) throw new Error("Укажите дату рождения ребёнка");

  const child = await prisma.child.findFirst({
    where: { inviteCode: code },
    include: { parent: true },
  });
  if (!child) throw new Error("Код не найден");

  if (child.userId && child.userId !== session.user.id) {
    // Можно забрать по коду, если «родитель» ещё черновик (админ объединил, пароля нет)
    const canTakeOver = Boolean(child.parent && !child.parent.passwordHash);
    if (!canTakeOver) {
      throw new Error("Ребёнок уже привязан к другому родителю");
    }
  }

  await prisma.child.update({
    where: { id: child.id },
    data: {
      userId: session.user.id,
      dateOfBirth: new Date(dateOfBirth),
      // код оставляем — админу удобно видеть у обоих детей
    },
  });
  await ensureChildDocuments(child.id);
  revalidatePath("/cabinet");
  revalidatePath("/admin/children");
  redirect(`/cabinet/children/${child.id}`);
}

export async function signDocument(formData: FormData) {
  const session = await requireParentSession();
  const documentId = String(formData.get("documentId") || "");
  const accepted = String(formData.get("accepted") || "") === "on";
  if (!documentId || !accepted) throw new Error("Подтвердите согласие с текстом");

  const doc = await prisma.document.findUnique({
    where: { id: documentId },
    include: { child: true },
  });
  if (!doc || doc.child.userId !== session.user.id) throw new Error("Документ не найден");
  if (doc.type === DocumentType.medical_clearance) {
    throw new Error("Меддопуск подтверждает администратор");
  }

  await prisma.document.update({
    where: { id: documentId },
    data: { status: DocumentStatus.signed, signedAt: new Date() },
  });
  revalidatePath(`/cabinet/children/${doc.childId}`);
  revalidatePath(`/cabinet/children/${doc.childId}/documents`);
  revalidatePath("/admin/documents");
}
