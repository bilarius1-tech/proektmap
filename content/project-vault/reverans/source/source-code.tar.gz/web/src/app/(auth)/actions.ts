"use server";

import bcrypt from "bcryptjs";
import { Role } from "@prisma/client";
import { claimPendingParentByPhone } from "@/lib/parent-identity";
import { missingRegisterConsents } from "@/lib/register-consents";
import { prisma } from "@/lib/prisma";

export type RegisterResult = { ok: true } | { ok: false; error: string };

export async function registerParent(formData: FormData): Promise<RegisterResult> {
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const phone = String(formData.get("phone") || "").trim() || null;
  const password = String(formData.get("password") || "");
  const password2 = String(formData.get("password2") || "");

  const missing = missingRegisterConsents(formData);
  if (missing.length) {
    return { ok: false, error: "Отметьте все согласия — это обязательно по закону" };
  }

  if (!name || !email || password.length < 6) {
    return { ok: false, error: "Заполните имя, email и пароль (от 6 символов)" };
  }
  if (password !== password2) {
    return { ok: false, error: "Пароли не совпадают" };
  }

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing?.passwordHash) {
    return { ok: false, error: "Этот email уже зарегистрирован. Войдите в кабинет." };
  }

  const passwordHash = await bcrypt.hash(password, 10);

  // Админ привязал детей по телефону без почты — забираем этот черновик
  const claimed = await claimPendingParentByPhone({
    email,
    name,
    phone,
    passwordHash,
  });
  if (claimed) {
    return { ok: true };
  }

  if (existing) {
    await prisma.user.update({
      where: { id: existing.id },
      data: {
        name,
        phone,
        passwordHash,
        role: existing.role === Role.admin ? existing.role : Role.parent,
      },
    });
  } else {
    await prisma.user.create({
      data: {
        name,
        email,
        phone,
        passwordHash,
        role: Role.parent,
      },
    });
  }

  return { ok: true };
}
