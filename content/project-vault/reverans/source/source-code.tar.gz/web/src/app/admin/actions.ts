"use server";

import { revalidatePath } from "next/cache";
import { getServerSession } from "next-auth";
import { DocumentStatus, DocumentType, PaymentStatus, PaymentType, Role } from "@prisma/client";
import bcrypt from "bcryptjs";
import { authOptions } from "@/lib/auth";
import { ensureChildDocuments } from "@/lib/documents";
import { generateInviteCode } from "@/lib/invite";
import { resolveParentAccount } from "@/lib/parent-identity";
import { prisma } from "@/lib/prisma";

async function assertAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== "admin") {
    throw new Error("Unauthorized");
  }
  return session;
}

function money(value: FormDataEntryValue | null): number {
  const n = Number(String(value ?? "0").replace(",", "."));
  return Number.isFinite(n) ? n : 0;
}

/** Up to two coaches; drop duplicate second if same as first. */
function groupCoachIds(formData: FormData) {
  const coachId = String(formData.get("coachId") || "") || null;
  let coach2Id = String(formData.get("coach2Id") || "") || null;
  if (coach2Id && coach2Id === coachId) coach2Id = null;
  return { coachId, coach2Id };
}

export async function createGroup(formData: FormData) {
  await assertAdmin();
  const name = String(formData.get("name") || "").trim();
  const defaultPrice = money(formData.get("defaultPrice"));
  const { coachId, coach2Id } = groupCoachIds(formData);
  if (!name) throw new Error("Название группы обязательно");

  await prisma.group.create({
    data: { name, defaultPrice, coachId, coach2Id },
  });
  revalidatePath("/admin/groups");
  revalidatePath("/admin");
}

export async function updateGroup(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  const name = String(formData.get("name") || "").trim();
  const defaultPrice = money(formData.get("defaultPrice"));
  const { coachId, coach2Id } = groupCoachIds(formData);
  if (!id || !name) throw new Error("Некорректные данные группы");

  await prisma.group.update({
    where: { id },
    data: { name, defaultPrice, coachId, coach2Id },
  });
  revalidatePath("/admin/groups");
  revalidatePath("/admin");
}

export async function deleteGroup(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;
  await prisma.group.delete({ where: { id } });
  revalidatePath("/admin/groups");
  revalidatePath("/admin");
}

export async function createCoach(formData: FormData) {
  await assertAdmin();
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const phone = String(formData.get("phone") || "").trim() || null;
  if (!name || !email) throw new Error("Имя и email обязательны");

  await prisma.user.create({
    data: { name, email, phone, role: Role.coach },
  });
  revalidatePath("/admin/coaches");
  revalidatePath("/admin/groups");
}

export async function updateCoach(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  const name = String(formData.get("name") || "").trim();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const phone = String(formData.get("phone") || "").trim() || null;
  if (!id || !name || !email) throw new Error("Имя и email обязательны");

  await prisma.user.update({
    where: { id },
    data: { name, email, phone },
  });
  revalidatePath("/admin/coaches");
  revalidatePath("/admin/groups");
}

export async function deleteCoach(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;
  await prisma.user.delete({ where: { id } });
  revalidatePath("/admin/coaches");
  revalidatePath("/admin/groups");
}

export async function createParentChild(formData: FormData) {
  await assertAdmin();
  const parentName = String(formData.get("parentName") || "").trim();
  const parentEmail = String(formData.get("parentEmail") || "").trim().toLowerCase() || null;
  const parentPhone = String(formData.get("parentPhone") || "").trim() || null;
  const fullName = String(formData.get("fullName") || "").trim();
  const dateOfBirth = String(formData.get("dateOfBirth") || "");
  const groupId = String(formData.get("groupId") || "") || null;
  const pricePerMonth = money(formData.get("pricePerMonth"));
  const discount = money(formData.get("discount"));
  const discountReason = String(formData.get("discountReason") || "").trim() || null;
  const isBudget = String(formData.get("isBudget") || "") === "on";

  if (!parentName || !fullName || !dateOfBirth) {
    throw new Error("Заполните обязательные поля");
  }

  const parent = await resolveParentAccount({
    email: parentEmail,
    name: parentName,
    phone: parentPhone,
  });

  const child = await prisma.child.create({
    data: {
      userId: parent.id,
      fullName,
      dateOfBirth: new Date(dateOfBirth),
      groupId,
      pricePerMonth: isBudget ? 0 : pricePerMonth,
      discount: isBudget ? 0 : discount,
      discountReason: isBudget ? null : discountReason,
      isBudget,
    },
  });

  await ensureChildDocuments(child.id);

  revalidatePath("/admin/children");
  revalidatePath("/admin");
}

/** Зачисление по ФИО + группа: родитель привяжется сам по коду. */
export async function enrollChild(formData: FormData) {
  await assertAdmin();
  const fullName = String(formData.get("fullName") || "").trim();
  const groupId = String(formData.get("groupId") || "") || null;
  const dateOfBirthRaw = String(formData.get("dateOfBirth") || "").trim();
  if (!fullName) throw new Error("Укажите имя и фамилию ребёнка");
  if (!groupId) throw new Error("Выберите группу");

  const group = await prisma.group.findUnique({ where: { id: groupId } });
  if (!group) throw new Error("Группа не найдена");

  const isBudget = String(formData.get("isBudget") || "") === "on";

  let inviteCode = generateInviteCode();
  for (let i = 0; i < 5; i++) {
    const clash = await prisma.child.findUnique({ where: { inviteCode } });
    if (!clash) break;
    inviteCode = generateInviteCode();
  }

  const child = await prisma.child.create({
    data: {
      userId: null,
      fullName,
      dateOfBirth: dateOfBirthRaw ? new Date(dateOfBirthRaw) : null,
      groupId,
      pricePerMonth: isBudget ? 0 : group.defaultPrice,
      discount: 0,
      isBudget,
      inviteCode,
    },
  });

  await ensureChildDocuments(child.id);

  revalidatePath("/admin/children");
  revalidatePath("/admin");
}

export async function regenerateChildInvite(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;

  const child = await prisma.child.findUnique({ where: { id } });
  if (!child) throw new Error("Ребёнок не найден");

  let inviteCode = generateInviteCode();
  for (let i = 0; i < 5; i++) {
    const clash = await prisma.child.findUnique({ where: { inviteCode } });
    if (!clash) break;
    inviteCode = generateInviteCode();
  }

  await prisma.child.update({
    where: { id },
    data: { inviteCode },
  });
  revalidatePath("/admin/children");
}

/** Выдать/вернуть коды выбранным (в т.ч. уже объединённым под родителем). */
export async function ensureChildrenInviteCodes(formData: FormData) {
  await assertAdmin();
  const childIds = formData
    .getAll("childIds")
    .map((v) => String(v).trim())
    .filter(Boolean);
  if (!childIds.length) throw new Error("Выберите детей");

  for (const id of childIds) {
    const existing = await prisma.child.findUnique({ where: { id } });
    if (!existing || existing.inviteCode) continue;

    let inviteCode = generateInviteCode();
    for (let i = 0; i < 5; i++) {
      const clash = await prisma.child.findUnique({ where: { inviteCode } });
      if (!clash) break;
      inviteCode = generateInviteCode();
    }
    await prisma.child.update({ where: { id }, data: { inviteCode } });
  }

  revalidatePath("/admin/children");
}

/** Привязать выбранных детей к одному родителю (объединение семьи). */
export async function linkChildrenToParent(formData: FormData) {
  await assertAdmin();
  const childIds = formData
    .getAll("childIds")
    .map((v) => String(v).trim())
    .filter(Boolean);
  const parentEmail = String(formData.get("parentEmail") || "").trim().toLowerCase() || null;
  const parentPhone = String(formData.get("parentPhone") || "").trim() || null;
  const parentName =
    String(formData.get("parentName") || "").trim() ||
    (parentEmail ? parentEmail.split("@")[0] : "") ||
    "Родитель";
  const priceMode = String(formData.get("priceMode") || "keep"); // keep | each | total
  const priceValueRaw = String(formData.get("priceValue") || "").trim();

  if (!childIds.length) throw new Error("Выберите хотя бы одного ребёнка");

  const parent = await resolveParentAccount({
    email: parentEmail,
    name: parentName,
    phone: parentPhone,
  });

  let eachPrice: number | null = null;
  if (priceMode === "each" && priceValueRaw !== "") {
    eachPrice = money(formData.get("priceValue"));
  } else if (priceMode === "total" && priceValueRaw !== "") {
    const total = money(formData.get("priceValue"));
    eachPrice = Math.round((total / childIds.length) * 100) / 100;
  }

  for (const id of childIds) {
    const existing = await prisma.child.findUnique({ where: { id } });
    if (!existing) continue;

    let inviteCode = existing.inviteCode;
    if (!inviteCode) {
      inviteCode = generateInviteCode();
      for (let i = 0; i < 5; i++) {
        const clash = await prisma.child.findUnique({ where: { inviteCode } });
        if (!clash) break;
        inviteCode = generateInviteCode();
      }
    }

    const data: {
      userId: string;
      inviteCode: string;
      pricePerMonth?: number;
      isBudget?: boolean;
    } = {
      userId: parent.id,
      inviteCode,
    };
    if (eachPrice != null && eachPrice >= 0) {
      data.pricePerMonth = eachPrice;
      data.isBudget = false;
    }
    await prisma.child.update({ where: { id }, data });
    await ensureChildDocuments(id);
  }

  revalidatePath("/admin/children");
  revalidatePath("/admin");
  revalidatePath("/cabinet");
}

/**
 * Назначить цены выбранным:
 * - mode=each: одна цена на каждого
 * - mode=total: общая сумма семьи, делится поровну
 * - mode=per: price_<childId> порознь
 */
export async function assignChildrenPrice(formData: FormData) {
  await assertAdmin();
  const childIds = formData
    .getAll("childIds")
    .map((v) => String(v).trim())
    .filter(Boolean);
  const mode = String(formData.get("mode") || "each");

  if (!childIds.length) throw new Error("Выберите детей");

  if (mode === "per") {
    for (const id of childIds) {
      const raw = formData.get(`price_${id}`);
      if (raw == null || String(raw).trim() === "") continue;
      const pricePerMonth = money(raw);
      await prisma.child.update({
        where: { id },
        data: { pricePerMonth, isBudget: false },
      });
    }
  } else if (mode === "total") {
    const total = money(formData.get("pricePerMonth"));
    if (total < 0) throw new Error("Некорректная сумма");
    const each = Math.round((total / childIds.length) * 100) / 100;
    await prisma.child.updateMany({
      where: { id: { in: childIds } },
      data: { pricePerMonth: each, isBudget: false },
    });
  } else {
    const pricePerMonth = money(formData.get("pricePerMonth"));
    if (pricePerMonth < 0) throw new Error("Некорректная сумма");
    await prisma.child.updateMany({
      where: { id: { in: childIds } },
      data: { pricePerMonth, isBudget: false },
    });
  }

  revalidatePath("/admin/children");
  revalidatePath("/cabinet");
}

export async function updateChild(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  const fullName = String(formData.get("fullName") || "").trim();
  const groupId = String(formData.get("groupId") || "") || null;
  const pricePerMonth = money(formData.get("pricePerMonth"));
  const discount = money(formData.get("discount"));
  const discountReason = String(formData.get("discountReason") || "").trim() || null;
  const isBudget = String(formData.get("isBudget") || "") === "on";
  if (!id || !fullName) throw new Error("Некорректные данные ребёнка");

  await prisma.child.update({
    where: { id },
    data: {
      fullName,
      groupId,
      pricePerMonth: isBudget ? 0 : pricePerMonth,
      discount: isBudget ? 0 : discount,
      discountReason: isBudget ? null : discountReason,
      isBudget,
    },
  });
  revalidatePath("/admin/children");
  revalidatePath("/admin");
  revalidatePath("/cabinet");
}

export async function deleteChild(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;
  await prisma.child.delete({ where: { id } });
  revalidatePath("/admin/children");
  revalidatePath("/admin");
}

export async function createPayment(formData: FormData) {
  await assertAdmin();
  const childId = String(formData.get("childId") || "");
  const amount = money(formData.get("amount"));
  const month = String(formData.get("month") || "").trim() || null;
  const status = (String(formData.get("status") || "pending") as PaymentStatus) || PaymentStatus.pending;
  const type = (String(formData.get("type") || "monthly") as PaymentType) || PaymentType.monthly;
  if (!childId || amount <= 0) throw new Error("Укажите ребёнка и сумму");

  await prisma.payment.create({
    data: {
      childId,
      amount,
      month,
      status,
      type,
      paidAt: status === PaymentStatus.paid ? new Date() : null,
    },
  });
  revalidatePath("/admin/payments");
  revalidatePath("/admin");
}

export async function setPaymentStatus(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  const status = String(formData.get("status") || "") as PaymentStatus;
  if (!id || !status) return;

  await prisma.payment.update({
    where: { id },
    data: {
      status,
      paidAt: status === PaymentStatus.paid ? new Date() : null,
    },
  });
  revalidatePath("/admin/payments");
  revalidatePath("/admin");
}

export async function createDocument(formData: FormData) {
  await assertAdmin();
  const childId = String(formData.get("childId") || "");
  const type = (String(formData.get("type") || "contract") as DocumentType) || DocumentType.contract;
  const status =
    (String(formData.get("status") || "pending") as DocumentStatus) || DocumentStatus.pending;
  if (!childId) throw new Error("Укажите ребёнка");

  await prisma.document.create({
    data: {
      childId,
      type,
      status,
      signedAt: status === DocumentStatus.signed ? new Date() : null,
    },
  });
  revalidatePath("/admin/documents");
  revalidatePath("/admin");
}

export async function setDocumentStatus(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  const status = String(formData.get("status") || "") as DocumentStatus;
  if (!id || !status) return;

  const doc = await prisma.document.findUnique({ where: { id } });
  if (!doc) return;

  await prisma.document.update({
    where: { id },
    data: {
      status,
      signedAt: status === DocumentStatus.signed ? new Date() : null,
    },
  });
  revalidatePath("/admin/documents");
  revalidatePath("/admin");
  revalidatePath(`/cabinet/children/${doc.childId}`);
  revalidatePath(`/cabinet/children/${doc.childId}/documents`);
}

export async function rejectMedicalScan(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;

  const doc = await prisma.document.findUnique({ where: { id } });
  if (!doc || doc.type !== DocumentType.medical_clearance) return;

  const { deleteMedicalFiles } = await import("@/lib/medical-storage");
  await deleteMedicalFiles(doc.fileUrl, doc.fileThumbUrl);

  await prisma.document.update({
    where: { id },
    data: {
      status: DocumentStatus.pending,
      fileUrl: null,
      fileThumbUrl: null,
      fileName: null,
      signedAt: null,
    },
  });
  revalidatePath("/admin/documents");
  revalidatePath(`/cabinet/children/${doc.childId}/documents`);
  revalidatePath(`/cabinet/children/${doc.childId}`);
  revalidatePath("/admin");
}

export type ChangePasswordResult = { ok: true } | { ok: false; error: string };

export async function changeAdminPassword(formData: FormData): Promise<ChangePasswordResult> {
  const session = await assertAdmin();
  const userId = session.user.id;
  if (!userId) return { ok: false, error: "Сессия без пользователя" };

  const currentPassword = String(formData.get("currentPassword") || "");
  const newPassword = String(formData.get("newPassword") || "");
  const confirmPassword = String(formData.get("confirmPassword") || "");

  if (!currentPassword || !newPassword || !confirmPassword) {
    return { ok: false, error: "Заполните все поля" };
  }
  if (newPassword.length < 8) {
    return { ok: false, error: "Новый пароль — минимум 8 символов" };
  }
  if (newPassword !== confirmPassword) {
    return { ok: false, error: "Пароли не совпадают" };
  }

  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user?.passwordHash) {
    return { ok: false, error: "Учётка без пароля" };
  }

  const matches = await bcrypt.compare(currentPassword, user.passwordHash);
  if (!matches) {
    return { ok: false, error: "Текущий пароль неверный" };
  }

  const passwordHash = await bcrypt.hash(newPassword, 12);
  await prisma.user.update({
    where: { id: userId },
    data: { passwordHash },
  });

  revalidatePath("/admin/settings");
  return { ok: true };
}

export async function createIndividualTraining(formData: FormData) {
  await assertAdmin();
  const childId = String(formData.get("childId") || "");
  const coachId = String(formData.get("coachId") || "");
  const date = String(formData.get("date") || "");
  const time = String(formData.get("time") || "").trim();
  const price = money(formData.get("price"));
  if (!childId || !coachId || !date || !time || price <= 0) {
    throw new Error("Заполните ребёнка, педагога, дату, время и цену");
  }

  await prisma.individualTraining.create({
    data: {
      childId,
      coachId,
      date: new Date(date),
      time,
      price,
    },
  });
  revalidatePath("/admin/trainings");
  revalidatePath("/admin/payments");
  revalidatePath("/cabinet");
}

/** Пакет: несколько дат + одна общая сумма (в кабинете — одна кнопка оплаты). */
export async function createIndividualTrainingPackage(formData: FormData) {
  await assertAdmin();
  const childId = String(formData.get("childId") || "");
  const coachId = String(formData.get("coachId") || "");
  const packagePrice = money(formData.get("packagePrice"));
  const dates = formData.getAll("sessionDate").map((v) => String(v).trim()).filter(Boolean);
  const times = formData.getAll("sessionTime").map((v) => String(v).trim());

  if (!childId || !coachId || packagePrice <= 0) {
    throw new Error("Укажите ребёнка, педагога и сумму пакета");
  }
  if (dates.length < 2) throw new Error("В пакете минимум 2 занятия");
  if (dates.length !== times.filter(Boolean).length) {
    throw new Error("У каждого занятия должны быть дата и время");
  }

  const n = dates.length;
  const amountCents = Math.round(packagePrice * 100);
  const each = Math.floor(amountCents / n);
  const pricesCents = Array.from({ length: n }, () => each);
  pricesCents[n - 1] += amountCents - each * n;

  const packageId = `pkg_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;

  await prisma.$transaction(
    dates.map((date, i) =>
      prisma.individualTraining.create({
        data: {
          childId,
          coachId,
          packageId,
          date: new Date(date),
          time: times[i],
          price: pricesCents[i] / 100,
        },
      }),
    ),
  );

  revalidatePath("/admin/trainings");
  revalidatePath("/admin/payments");
  revalidatePath("/cabinet");
}

export async function deleteIndividualTraining(formData: FormData) {
  await assertAdmin();
  const id = String(formData.get("id") || "");
  if (!id) return;
  await prisma.individualTraining.delete({ where: { id } });
  revalidatePath("/admin/trainings");
  revalidatePath("/cabinet");
}
