import type { NextAuthOptions, Profile } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import YandexProvider from "next-auth/providers/yandex";
import bcrypt from "bcryptjs";
import { Role } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { runtimeEnv } from "@/lib/env";

type YandexProfile = Profile & {
  id: string;
  login?: string;
  display_name?: string;
  real_name?: string;
  default_email?: string;
  emails?: string[];
};

const credentialsProvider = CredentialsProvider({
  name: "Email",
  credentials: {
    email: { label: "Email", type: "email" },
    password: { label: "Password", type: "password" },
  },
  async authorize(credentials) {
    const email = credentials?.email?.trim().toLowerCase();
    const password = credentials?.password;
    if (!email || !password) return null;

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user?.passwordHash) return null;

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) return null;

    return {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
    };
  },
});

function yandexCredentials() {
  const clientId = runtimeEnv("YANDEX_CLIENT_ID");
  const clientSecret = runtimeEnv("YANDEX_CLIENT_SECRET");
  if (!clientId || !clientSecret) return null;
  return { clientId, clientSecret };
}

export function yandexAuthEnabled() {
  return Boolean(yandexCredentials());
}

function buildProviders(): NextAuthOptions["providers"] {
  const providers: NextAuthOptions["providers"] = [credentialsProvider];
  const yandex = yandexCredentials();
  if (yandex) {
    providers.push(
      YandexProvider({
        clientId: yandex.clientId,
        clientSecret: yandex.clientSecret,
        authorization: {
          params: { scope: "login:email login:info" },
        },
        client: {
          token_endpoint_auth_method: "client_secret_post",
        },
      }),
    );
  }
  return providers;
}

export function getAuthOptions(): NextAuthOptions {
  return {
    secret: runtimeEnv("NEXTAUTH_SECRET") || process.env.NEXTAUTH_SECRET,
    session: { strategy: "jwt" },
    pages: {
      signIn: "/login",
      error: "/auth/error",
    },
    providers: buildProviders(),
    callbacks: {
      async jwt({ token, user, account, profile }) {
        if (account?.provider === "yandex" && profile) {
          const yp = profile as YandexProfile;
          const yandexId = String(yp.id);
          const email = (
            yp.default_email ||
            yp.emails?.[0] ||
            `${yandexId}@yandex.oauth.local`
          ).toLowerCase();
          const name = yp.real_name || yp.display_name || yp.login || "Родитель";

          let dbUser = await prisma.user.findFirst({
            where: { OR: [{ yandexId }, { email }] },
          });

          if (!dbUser) {
            dbUser = await prisma.user.create({
              data: {
                email,
                name,
                yandexId,
                role: Role.parent,
              },
            });
          } else {
            dbUser = await prisma.user.update({
              where: { id: dbUser.id },
              data: {
                yandexId: dbUser.yandexId || yandexId,
                name: dbUser.name || name,
              },
            });
          }

          token.id = dbUser.id;
          token.role = dbUser.role;
          token.email = dbUser.email;
          token.name = dbUser.name;
          return token;
        }

        if (user) {
          token.role = (user as { role?: string }).role;
          token.id = user.id;
        }
        return token;
      },
      async session({ session, token }) {
        if (session.user) {
          session.user.id = token.id as string;
          session.user.role = (token.role as string) || "parent";
        }
        return session;
      },
    },
  };
}

/** Snapshot used by getServerSession (providers re-read via getter). */
export const authOptions: NextAuthOptions = {
  ...getAuthOptions(),
  get providers() {
    return buildProviders();
  },
};

export function homeForRole(role?: string | null) {
  if (role === "admin") return "/admin";
  if (role === "coach") return "/cabinet";
  return "/cabinet";
}
