import { PaymentStatus, PaymentType } from "@prisma/client";
import { childMonthAmount, isBudgetPlace, isMonthBillable } from "@/lib/pricing";
import { prisma } from "@/lib/prisma";

export async function getOrCreateMonthlyPayment(childId: string, month: string) {
  if (!isMonthBillable(month)) {
    throw new Error("Этот месяц уже закрыт офлайн — онлайн-оплата с следующего расчётного месяца");
  }
  const child = await prisma.child.findUnique({ where: { id: childId } });
  if (!child) throw new Error("Ребёнок не найден");
  if (isBudgetPlace(child)) {
    throw new Error("Бюджетное место — абонемент не оплачивается");
  }

  const amount = childMonthAmount(child.pricePerMonth, child.discount);
  const existing = await prisma.payment.findFirst({
    where: { childId, type: PaymentType.monthly, month },
  });
  if (existing) {
    if (existing.status === PaymentStatus.pending && Number(existing.amount) !== amount) {
      return prisma.payment.update({
        where: { id: existing.id },
        data: { amount },
      });
    }
    return existing;
  }

  return prisma.payment.create({
    data: {
      childId,
      type: PaymentType.monthly,
      month,
      amount,
      status: PaymentStatus.pending,
    },
  });
}

export async function getOrCreateTrainingPayment(trainingId: string, parentUserId: string) {
  const training = await prisma.individualTraining.findUnique({
    where: { id: trainingId },
    include: { child: true, payment: true },
  });
  if (!training || training.child.userId !== parentUserId) {
    throw new Error("Тренировка не найдена");
  }
  if (training.payment) return training.payment;

  const siblings = training.packageId
    ? await prisma.individualTraining.findMany({
        where: { packageId: training.packageId },
        include: { payment: true },
        orderBy: [{ date: "asc" }, { time: "asc" }],
      })
    : [training];

  const existingPay = siblings.find((s) => s.paymentId)?.paymentId;
  if (existingPay) {
    const payment = await prisma.payment.findUnique({ where: { id: existingPay } });
    if (payment) {
      await prisma.individualTraining.updateMany({
        where: { id: { in: siblings.map((s) => s.id) }, paymentId: null },
        data: { paymentId: payment.id },
      });
      return payment;
    }
  }

  const amount = siblings.reduce((sum, s) => sum + Number(s.price), 0);
  const payment = await prisma.payment.create({
    data: {
      childId: training.childId,
      type: PaymentType.individual,
      amount,
      status: PaymentStatus.pending,
      month: null,
    },
  });
  await prisma.individualTraining.updateMany({
    where: { id: { in: siblings.map((s) => s.id) } },
    data: { paymentId: payment.id },
  });
  return payment;
}

/** Собирает абонементы всех платных детей родителя в один PaymentBatch за месяц. */
export async function getOrCreateMonthlyBatch(parentUserId: string, month: string) {
  const children = await prisma.child.findMany({
    where: { userId: parentUserId, isBudget: false },
    orderBy: { fullName: "asc" },
  });
  if (!children.length) throw new Error("Нет детей для оплаты");

  const payments = [];
  for (const child of children) {
    payments.push(await getOrCreateMonthlyPayment(child.id, month));
  }

  const pending = payments.filter((p) => p.status !== PaymentStatus.paid);
  const total = pending.reduce((sum, p) => sum + Number(p.amount), 0);

  if (pending.length === 0) {
    const existingPaid = await prisma.paymentBatch.findFirst({
      where: { parentUserId, month, status: PaymentStatus.paid },
      include: { payments: { include: { child: true } } },
      orderBy: { createdAt: "desc" },
    });
    if (existingPaid) return existingPaid;
  }

  let batch = await prisma.paymentBatch.findFirst({
    where: {
      parentUserId,
      month,
      status: { in: [PaymentStatus.pending, PaymentStatus.failed] },
    },
    orderBy: { createdAt: "desc" },
  });

  if (!batch) {
    batch = await prisma.paymentBatch.create({
      data: {
        parentUserId,
        month,
        amount: total,
        status: PaymentStatus.pending,
      },
    });
  } else {
    batch = await prisma.paymentBatch.update({
      where: { id: batch.id },
      data: {
        amount: total,
        status: PaymentStatus.pending,
      },
    });
  }

  await prisma.payment.updateMany({
    where: { id: { in: pending.map((p) => p.id) } },
    data: { batchId: batch.id },
  });

  return prisma.paymentBatch.findUniqueOrThrow({
    where: { id: batch.id },
    include: {
      payments: {
        include: { child: true },
        orderBy: { createdAt: "asc" },
      },
    },
  });
}

export async function markBatchPaid(batchId: string, tbankPaymentId?: string | null) {
  const paidAt = new Date();
  await prisma.paymentBatch.update({
    where: { id: batchId },
    data: {
      status: PaymentStatus.paid,
      paidAt,
      tbankPaymentId: tbankPaymentId || undefined,
    },
  });
  await prisma.payment.updateMany({
    where: { batchId },
    data: {
      status: PaymentStatus.paid,
      paidAt,
      tbankPaymentId: tbankPaymentId || undefined,
    },
  });
}

export async function markBatchFailed(batchId: string, tbankPaymentId?: string | null) {
  await prisma.paymentBatch.update({
    where: { id: batchId },
    data: {
      status: PaymentStatus.failed,
      tbankPaymentId: tbankPaymentId || undefined,
    },
  });
  await prisma.payment.updateMany({
    where: { batchId, status: { not: PaymentStatus.paid } },
    data: {
      status: PaymentStatus.failed,
      tbankPaymentId: tbankPaymentId || undefined,
    },
  });
}
