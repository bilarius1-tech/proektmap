/** Legal docs for registration (152‑ФЗ). Served at /tz/doc/ via Nginx. */
export const REGISTER_CONSENTS = [
  {
    id: "oferta",
    label: "Оферта",
    href: "/tz/doc/oferta.docx",
  },
  {
    id: "politika",
    label: "Политика обработки персональных данных",
    href: "/tz/doc/politika-obrabotki.docx",
  },
  {
    id: "sayt",
    label: "Согласие на обработку персональных данных (сайт)",
    href: "/tz/doc/soglasie-sayt.docx",
  },
  {
    id: "ias",
    label: "Согласие на обработку персональных данных (ИАС)",
    href: "/tz/doc/soglasie-ias.docx",
  },
  {
    id: "sorevnovaniya",
    label: "Согласие на обработку персональных данных (соревнования)",
    href: "/tz/doc/soglasie-sorevnovaniya.docx",
  },
  {
    id: "foto",
    label: "Согласие на фото- и видеосъёмку",
    href: "/tz/doc/soglasie-foto-video.docx",
  },
] as const;

export type RegisterConsentId = (typeof REGISTER_CONSENTS)[number]["id"];

export function missingRegisterConsents(formData: FormData): string[] {
  return REGISTER_CONSENTS.filter((c) => String(formData.get(`consent_${c.id}`) || "") !== "on").map(
    (c) => c.label,
  );
}
