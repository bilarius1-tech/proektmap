import { mkdir, writeFile, unlink } from "fs/promises";
import path from "path";
import sharp from "sharp";

export const MEDICAL_STORAGE_DIR = path.join(process.cwd(), "storage", "medical");

const IMAGE_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/heic", "image/heif"]);
const PDF_TYPE = "application/pdf";
export const MEDICAL_MAX_BYTES = 12 * 1024 * 1024;

export function isMedicalImage(mime: string) {
  return IMAGE_TYPES.has(mime) || mime.startsWith("image/");
}

export function isMedicalPdf(mime: string) {
  return mime === PDF_TYPE || mime === "application/x-pdf";
}

export function medicalDiskPath(relative: string) {
  const safe = relative.replace(/^\/+/, "").replace(/\.\./g, "");
  return path.join(MEDICAL_STORAGE_DIR, path.basename(safe));
}

/** Save scan: images → compressed webp + thumb; PDF → as-is. */
export async function saveMedicalScan(input: {
  buffer: Buffer;
  mime: string;
  originalName: string;
}) {
  await mkdir(MEDICAL_STORAGE_DIR, { recursive: true });
  const base = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  if (isMedicalPdf(input.mime) || input.originalName.toLowerCase().endsWith(".pdf")) {
    const fileName = `${base}.pdf`;
    await writeFile(path.join(MEDICAL_STORAGE_DIR, fileName), input.buffer);
    return {
      fileUrl: fileName,
      fileThumbUrl: null as string | null,
      fileName: input.originalName || fileName,
      mimeType: "application/pdf",
      sizeBytes: input.buffer.length,
    };
  }

  if (!isMedicalImage(input.mime) && !/\.(jpe?g|png|webp|heic|heif)$/i.test(input.originalName)) {
    throw new Error("Допустимы фото (JPG/PNG/WebP) или PDF");
  }

  let fullBuf: Buffer;
  let thumbBuf: Buffer;
  try {
    fullBuf = await sharp(input.buffer, { failOn: "none" })
      .rotate()
      .resize({ width: 2000, height: 2000, fit: "inside", withoutEnlargement: true })
      .webp({ quality: 82 })
      .toBuffer();
    thumbBuf = await sharp(input.buffer, { failOn: "none" })
      .rotate()
      .resize({ width: 480, height: 480, fit: "inside", withoutEnlargement: true })
      .webp({ quality: 70 })
      .toBuffer();
  } catch {
    throw new Error("Не удалось обработать изображение. Попробуйте JPG или PDF.");
  }

  const fileName = `${base}.webp`;
  const thumbName = `${base}-thumb.webp`;
  await writeFile(path.join(MEDICAL_STORAGE_DIR, fileName), fullBuf);
  await writeFile(path.join(MEDICAL_STORAGE_DIR, thumbName), thumbBuf);

  return {
    fileUrl: fileName,
    fileThumbUrl: thumbName,
    fileName: input.originalName || fileName,
    mimeType: "image/webp",
    sizeBytes: fullBuf.length,
  };
}

export async function deleteMedicalFiles(fileUrl?: string | null, thumbUrl?: string | null) {
  for (const rel of [fileUrl, thumbUrl]) {
    if (!rel) continue;
    try {
      await unlink(medicalDiskPath(rel));
    } catch {
      /* ignore missing */
    }
  }
}
