import { createHash } from "crypto";
import { readFileSync, existsSync } from "fs";
import { runtimeEnv } from "@/lib/env";

function apiUrl() {
  return runtimeEnv("TBANK_API_URL") || "https://securepay.tinkoff.ru/v2";
}

/**
 * Secret must NOT go through Next.js dotenv — `$` in the password is treated as
 * variable expansion and the key becomes 13 chars (bank error 204).
 * Prefer a one-line file (TBANK_SECRET_FILE), then process.env.
 */
let cachedSecret: string | undefined | null = null;

export function tbankSecret(): string | undefined {
  if (cachedSecret !== null) return cachedSecret || undefined;

  const filePath = runtimeEnv("TBANK_SECRET_FILE") || "/var/www/reverans/secrets/tbank_secret";
  if (existsSync(filePath)) {
    try {
      const raw = readFileSync(filePath, "utf8").replace(/^\uFEFF/, "").trim();
      if (raw) {
        cachedSecret = raw;
        return raw;
      }
    } catch {
      /* fall through */
    }
  }

  const fromEnv = runtimeEnv("TBANK_SECRET_KEY");
  cachedSecret = fromEnv || "";
  return fromEnv;
}

export function tbankTerminalKey(): string | undefined {
  return runtimeEnv("TBANK_TERMINAL_KEY");
}

export function tbankConfigured() {
  return Boolean(tbankTerminalKey() && tbankSecret());
}

/** Tinkoff Token: sorted root scalar fields + Password, SHA-256 hex */
export function tbankToken(params: Record<string, unknown>, secret: string) {
  const withPassword: Record<string, unknown> = { ...params, Password: secret };
  const keys = Object.keys(withPassword)
    .filter((k) => {
      const v = withPassword[k];
      return v !== undefined && v !== null && typeof v !== "object";
    })
    .sort();
  const concat = keys.map((k) => String(withPassword[k])).join("");
  return createHash("sha256").update(concat).digest("hex");
}

export function verifyTbankNotification(body: Record<string, unknown>) {
  const secret = tbankSecret();
  if (!secret) return false;
  const received = String(body.Token || "");
  if (!received) return false;
  const copy = { ...body };
  delete copy.Token;
  const expected = tbankToken(copy, secret);
  return expected.toLowerCase() === received.toLowerCase();
}

export async function tbankInit(input: {
  orderId: string;
  amountRub: number;
  description: string;
  successUrl: string;
  failUrl: string;
  notificationUrl: string;
  customerEmail?: string;
}) {
  const terminalKey = tbankTerminalKey();
  const secret = tbankSecret();
  if (!terminalKey || !secret) {
    throw new Error("TBANK_NOT_CONFIGURED");
  }

  const amountKopeks = Math.round(input.amountRub * 100);
  const payload: Record<string, unknown> = {
    TerminalKey: terminalKey,
    Amount: amountKopeks,
    OrderId: input.orderId,
    Description: input.description.slice(0, 240),
    PayType: "O",
    Language: "ru",
    SuccessURL: input.successUrl,
    FailURL: input.failUrl,
    NotificationURL: input.notificationUrl,
  };

  if (input.customerEmail) {
    payload.DATA = { Email: input.customerEmail };
  }

  const taxation = runtimeEnv("TBANK_TAXATION");
  if (taxation) {
    payload.Receipt = {
      Email: input.customerEmail,
      Taxation: taxation,
      Items: [
        {
          Name: input.description.slice(0, 128),
          Price: amountKopeks,
          Quantity: 1,
          Amount: amountKopeks,
          Tax: runtimeEnv("TBANK_VAT") || "none",
          PaymentMethod: "full_payment",
          PaymentObject: "service",
        },
      ],
    };
  }

  payload.Token = tbankToken(payload, secret);

  let res: Response;
  try {
    res = await fetch(`${apiUrl()}/Init`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } catch (e) {
    const cause = e instanceof Error && "cause" in e ? (e as Error & { cause?: Error }).cause : undefined;
    const detail = cause?.message || (e instanceof Error ? e.message : "network error");
    throw new Error(
      `Нет связи с Т‑Банк (${detail}). Проверьте NODE_EXTRA_CA_CERTS / сертификаты Минцифры на сервере.`,
    );
  }

  const data = (await res.json()) as {
    Success?: boolean;
    ErrorCode?: string;
    Message?: string;
    Details?: string;
    PaymentId?: string | number;
    PaymentURL?: string;
  };

  if (!data.Success || !data.PaymentURL) {
    const parts = [
      data.Message,
      data.Details,
      data.ErrorCode ? `код ${data.ErrorCode}` : null,
      `терминал…${terminalKey.slice(-4)} (${terminalKey.length} симв.)`,
      `секрет ${secret.length} симв.${secret.includes("$") ? ", $ ok" : ", без $"}`,
    ].filter(Boolean);
    throw new Error(parts.join(" — "));
  }

  return {
    paymentId: String(data.PaymentId),
    paymentUrl: data.PaymentURL,
  };
}
