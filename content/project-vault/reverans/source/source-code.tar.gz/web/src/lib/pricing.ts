export function childMonthAmount(pricePerMonth: number | string | { toString(): string }, discount: number | string | { toString(): string }) {
  const price = Number(pricePerMonth) || 0;
  const disc = Number(discount) || 0;
  return Math.max(0, Math.round((price - disc) * 100) / 100);
}

/** Бюджетное место — абонемент не выставляется. */
export function isBudgetPlace(child: { isBudget?: boolean | null }) {
  return Boolean(child.isBudget);
}

export function formatRub(amount: number | string | { toString(): string }) {
  const n = Number(amount) || 0;
  return new Intl.NumberFormat("ru-RU", {
    style: "currency",
    currency: "RUB",
    maximumFractionDigits: 0,
  }).format(n);
}

/** YYYY-MM */
export function currentMonthKey(d = new Date()) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function nextMonthKey(d = new Date()) {
  return currentMonthKey(new Date(d.getFullYear(), d.getMonth() + 1, 1));
}

function parseMonthKey(month: string): Date {
  const [y, m] = month.split("-").map(Number);
  return new Date(y, m - 1, 1);
}

/**
 * Первый месяц онлайн-оплаты (запуск сайта).
 * Сентябрь и раньше не предлагаем — уже собраны офлайн.
 * .env: FIRST_BILLABLE_MONTH=2026-10
 */
export function firstBillableMonthKey(): string | null {
  const raw = String(process.env.FIRST_BILLABLE_MONTH || "").trim();
  return /^\d{4}-\d{2}$/.test(raw) ? raw : null;
}

/**
 * С какого числа месяца открывается оплата за СЛЕДУЮЩИЙ месяц.
 * С 20 сент → октябрь; с 20 окт → ноябрь. До 20-го — текущий месяц.
 * .env: BILLING_ADVANCE_DAY=20
 */
export function billingAdvanceDay(): number {
  const n = Number(process.env.BILLING_ADVANCE_DAY || 20);
  if (!Number.isFinite(n) || n < 1 || n > 28) return 20;
  return Math.floor(n);
}

export function isMonthBillable(month: string): boolean {
  const first = firstBillableMonthKey();
  if (!first) return true;
  return month >= first;
}

/**
 * Месяц «к оплате» по умолчанию:
 * - до 20-го числа → текущий календарный месяц
 * - с 20-го → следующий месяц
 * - не раньше FIRST_BILLABLE_MONTH
 */
export function defaultBillableMonthKey(d = new Date()) {
  const focus = d.getDate() >= billingAdvanceDay() ? nextMonthKey(d) : currentMonthKey(d);
  const first = firstBillableMonthKey();
  if (first && focus < first) return first;
  return focus;
}

export function monthLabel(month: string) {
  const [y, m] = month.split("-").map(Number);
  if (!y || !m) return month;
  const date = new Date(y, m - 1, 1);
  return date.toLocaleDateString("ru-RU", { month: "long", year: "numeric" });
}

/** Актуальный месяц к оплате и следующий (две кнопки). */
export function nearbyMonths(center = new Date()) {
  const focus = defaultBillableMonthKey(center);
  const next = currentMonthKey(
    new Date(parseMonthKey(focus).getFullYear(), parseMonthKey(focus).getMonth() + 1, 1),
  );
  return [focus, next];
}

/** Разрешённый месяц из query, иначе актуальный. */
export function resolvePayableMonth(requested: string | undefined, center = new Date()) {
  const allowed = nearbyMonths(center);
  if (requested && /^\d{4}-\d{2}$/.test(requested) && allowed.includes(requested)) {
    return requested;
  }
  return allowed[0];
}
