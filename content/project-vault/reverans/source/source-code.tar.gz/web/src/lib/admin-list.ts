/** Shared list helpers for admin studio pages. */

export function parsePage(raw: string | undefined, pageSize: number) {
  const page = Math.max(1, Number.parseInt(raw || "1", 10) || 1);
  return { page, skip: (page - 1) * pageSize, take: pageSize };
}

export function totalPages(total: number, pageSize: number) {
  return Math.max(1, Math.ceil(total / pageSize));
}

export function normalizeQuery(q: string | undefined) {
  return (q || "").trim();
}
