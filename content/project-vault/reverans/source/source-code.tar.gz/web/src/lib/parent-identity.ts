import { Role } from "@prisma/client";
import {
  isPendingParentEmail,
  normalizePhone,
  pendingEmailForPhone,
} from "@/lib/parent-identity-shared";
import { prisma } from "@/lib/prisma";

export {
  isPendingParentEmail,
  isUsableParentEmail,
  normalizePhone,
  PENDING_PARENT_EMAIL_DOMAIN,
  formatParentContact,
} from "@/lib/parent-identity-shared";

/**
 * Найти или создать родителя: по email и/или телефону.
 * Без почты — черновик с pending-email; родитель потом зарегистрируется с тем же телефоном.
 */
export async function resolveParentAccount(input: {
  email?: string | null;
  name: string;
  phone?: string | null;
}) {
  const email = String(input.email || "").trim().toLowerCase() || null;
  const phoneRaw = String(input.phone || "").trim() || null;
  const norm = normalizePhone(phoneRaw);
  const name = input.name.trim();

  if (!name) throw new Error("Укажите ФИО родителя");
  if (!email && !norm) {
    throw new Error("Укажите email или телефон родителя");
  }
  if (email && isPendingParentEmail(email)) {
    throw new Error("Укажите настоящий email или оставьте поле пустым");
  }

  if (email) {
    const existing = await prisma.user.findUnique({ where: { email } });
    if (existing?.role === Role.admin) {
      throw new Error("Нельзя привязать детей к аккаунту администратора");
    }
    return prisma.user.upsert({
      where: { email },
      update: {
        name,
        phone: phoneRaw ?? undefined,
        role: Role.parent,
      },
      create: {
        email,
        name,
        phone: phoneRaw,
        role: Role.parent,
      },
    });
  }

  const withPhone = await prisma.user.findMany({
    where: { role: Role.parent, phone: { not: null } },
    select: { id: true, email: true, phone: true, name: true, role: true },
  });
  const byPhone = withPhone.find((u) => normalizePhone(u.phone) === norm);
  if (byPhone) {
    return prisma.user.update({
      where: { id: byPhone.id },
      data: { name, phone: phoneRaw },
    });
  }

  const pendingEmail = pendingEmailForPhone(norm);
  return prisma.user.upsert({
    where: { email: pendingEmail },
    update: { name, phone: phoneRaw, role: Role.parent },
    create: {
      email: pendingEmail,
      name,
      phone: phoneRaw,
      role: Role.parent,
    },
  });
}

/** При регистрации: забрать черновик родителя с тем же телефоном. */
export async function claimPendingParentByPhone(opts: {
  email: string;
  name: string;
  phone: string | null;
  passwordHash: string;
}) {
  const norm = normalizePhone(opts.phone);
  if (!norm) return null;

  const candidates = await prisma.user.findMany({
    where: { role: Role.parent, phone: { not: null }, passwordHash: null },
    select: { id: true, email: true, phone: true },
  });
  const pending = candidates.find(
    (u) => normalizePhone(u.phone) === norm && isPendingParentEmail(u.email),
  );
  if (!pending) return null;

  const emailTaken = await prisma.user.findUnique({ where: { email: opts.email } });
  if (emailTaken && emailTaken.id !== pending.id) return null;

  return prisma.user.update({
    where: { id: pending.id },
    data: {
      email: opts.email,
      name: opts.name,
      phone: opts.phone,
      passwordHash: opts.passwordHash,
      role: Role.parent,
    },
  });
}
