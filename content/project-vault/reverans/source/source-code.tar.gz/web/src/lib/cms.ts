import { prisma } from "@/lib/prisma";
import {
  DEFAULT_SETTINGS,
  DEFAULT_SEO,
  SECTION_DEFS,
  type AboutData,
  type ContactsData,
  type FinalCtaData,
  type GalleryTeaserData,
  type HeroData,
  type InstallAppData,
  type PageAboutData,
  type PageContactsData,
  type PageGalleryData,
  type PagePricesData,
  type PricingData,
  type ProgramsData,
  type ServicesData,
  type SiteSettingsView,
  type WhyData,
} from "@/lib/cms-defaults";

export async function ensureCmsSeeded() {
  const settings = await prisma.siteSettings.findUnique({ where: { id: "default" } });
  if (!settings) {
    await prisma.siteSettings.create({
      data: {
        id: "default",
        ...DEFAULT_SETTINGS,
      },
    });
  }

  for (const section of SECTION_DEFS) {
    await prisma.siteSection.upsert({
      where: { key: section.key },
      create: {
        key: section.key,
        label: section.label,
        data: section.data,
        enabled: true,
      },
      // Keep existing content; only refresh label if missing section was just created above
      update: { label: section.label },
    });
  }

  for (const seo of DEFAULT_SEO) {
    await prisma.pageSeo.upsert({
      where: { path: seo.path },
      create: {
        path: seo.path,
        title: seo.title,
        description: seo.description,
        h1: seo.h1 ?? null,
      },
      update: {},
    });
  }
}

function mapSettings(row: Awaited<ReturnType<typeof prisma.siteSettings.findUnique>>): SiteSettingsView {
  if (!row) return DEFAULT_SETTINGS;
  return {
    brandName: row.brandName,
    brandNameRu: row.brandNameRu,
    tagline: row.tagline,
    city: row.city,
    address: row.address,
    phoneDisplay: row.phoneDisplay,
    phoneHref: row.phoneHref,
    email: row.email,
    telegram: row.telegram,
    telegramHref: row.telegramHref,
    whatsappHref: row.whatsappHref,
    instagramHref: row.instagramHref,
    vkHref: row.vkHref,
    youtubeHref: row.youtubeHref,
    logoUrl: row.logoUrl,
    faviconUrl: row.faviconUrl,
    ogImageUrl: row.ogImageUrl,
    footerAbout: row.footerAbout,
    copyrightText: row.copyrightText,
    yandexMetrikaId: row.yandexMetrikaId,
    yandexMetrikaOn: row.yandexMetrikaOn,
    yandexWebvisor: row.yandexWebvisor,
    yandexVerification: row.yandexVerification,
    googleAnalyticsId: row.googleAnalyticsId,
  };
}

export async function getSiteSettings(): Promise<SiteSettingsView> {
  try {
    await ensureCmsSeeded();
    const row = await prisma.siteSettings.findUnique({ where: { id: "default" } });
    return mapSettings(row);
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function defaultSectionData(key: string) {
  return SECTION_DEFS.find((s) => s.key === key)?.data ?? {};
}

/** Shallow-merge CMS JSON with defaults so new fields appear without re-seed. */
export function mergeSectionData<T extends Record<string, unknown>>(key: string, data: unknown): T {
  const defaults = defaultSectionData(key) as Record<string, unknown>;
  const raw = data && typeof data === "object" && !Array.isArray(data) ? (data as Record<string, unknown>) : {};
  const merged: Record<string, unknown> = { ...defaults, ...raw };

  if (Array.isArray(defaults.items)) {
    const rawItems = Array.isArray(raw.items) ? (raw.items as Record<string, unknown>[]) : [];
    const defItems = defaults.items as Record<string, unknown>[];
    if (rawItems.length === 0) {
      merged.items = defItems;
    } else {
      merged.items = rawItems.map((item, i) => ({
        ...(defItems[i] || defItems[0] || {}),
        ...item,
      }));
    }
  }

  if (Array.isArray(defaults.groups)) {
    const rawGroups = Array.isArray(raw.groups) ? (raw.groups as Record<string, unknown>[]) : [];
    const defGroups = defaults.groups as Record<string, unknown>[];
    if (rawGroups.length === 0) {
      merged.groups = defGroups;
    } else {
      merged.groups = rawGroups.map((group, i) => {
        const def = (defGroups[i] || defGroups[0] || {}) as Record<string, unknown>;
        const mergedGroup = { ...def, ...group };
        const defPlans = Array.isArray(def.plans) ? (def.plans as Record<string, unknown>[]) : [];
        const rawPlans = Array.isArray(group.plans) ? (group.plans as Record<string, unknown>[]) : [];
        mergedGroup.plans =
          rawPlans.length === 0
            ? defPlans
            : rawPlans.map((plan, pi) => ({
                ...(defPlans[pi] || defPlans[0] || {}),
                ...plan,
              }));
        return mergedGroup;
      });
    }
    delete merged.cards;
    delete merged.imageUrl;
    delete merged.imageAlt;
  }

  return merged as T;
}

export async function getSection<T>(key: string): Promise<{ enabled: boolean; data: T }> {
  try {
    await ensureCmsSeeded();
    const row = await prisma.siteSection.findUnique({ where: { key } });
    if (!row) {
      return { enabled: true, data: mergeSectionData<T & Record<string, unknown>>(key, {}) as T };
    }
    return {
      enabled: row.enabled,
      data: mergeSectionData<T & Record<string, unknown>>(key, row.data) as T,
    };
  } catch {
    return { enabled: true, data: mergeSectionData<T & Record<string, unknown>>(key, {}) as T };
  }
}

export async function getPageSeo(path: string) {
  try {
    await ensureCmsSeeded();
    const row = await prisma.pageSeo.findUnique({ where: { path } });
    if (row) return row;
    const fallback = DEFAULT_SEO.find((s) => s.path === path);
    return fallback
      ? {
          path,
          title: fallback.title,
          description: fallback.description,
          h1: fallback.h1 ?? null,
          ogTitle: null,
          ogDescription: null,
          ogImageUrl: null,
        }
      : null;
  } catch {
    return null;
  }
}

export async function getPublishedGallery(limit?: number) {
  try {
    await ensureCmsSeeded();
    return await prisma.galleryItem.findMany({
      where: { published: true },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "desc" }],
      take: limit,
      include: { media: true },
    });
  } catch {
    return [];
  }
}

export async function getHomeContent() {
  const [
    settings,
    hero,
    why,
    programs,
    about,
    services,
    pricing,
    pagePrices,
    gallery,
    cta,
    contacts,
    installApp,
    photos,
  ] = await Promise.all([
    getSiteSettings(),
    getSection<HeroData>("home.hero"),
    getSection<WhyData>("home.why"),
    getSection<ProgramsData>("home.programs"),
    getSection<AboutData>("home.about"),
    getSection<ServicesData>("home.services"),
    getSection<PricingData>("home.pricing"),
    getSection<PagePricesData>("page.prices"),
    getSection<GalleryTeaserData>("home.gallery"),
    getSection<FinalCtaData>("home.cta"),
    getSection<ContactsData>("home.contacts"),
    getSection<InstallAppData>("home.installApp"),
    getPublishedGallery(12),
  ]);

  const teaserLimit = gallery.data.limit || 6;

  return {
    settings,
    hero,
    why,
    programs,
    about,
    services,
    pricing,
    priceGroups: pagePrices.data.groups || [],
    gallery,
    cta,
    contacts,
    installApp,
    galleryPhotos: photos.slice(0, teaserLimit),
  };
}

export type {
  AboutData,
  ContactsData,
  FinalCtaData,
  GalleryTeaserData,
  HeroData,
  InstallAppData,
  PageAboutData,
  PageContactsData,
  PageGalleryData,
  PagePricesData,
  PricingData,
  ProgramsData,
  ServicesData,
  SiteSettingsView,
  WhyData,
};
