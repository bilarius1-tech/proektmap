/** Human-readable NextAuth error codes (OAuth / session). */
export function authErrorMessage(code: string | null | undefined): {
  title: string;
  detail: string;
} {
  switch (code) {
    case "OAuthSignin":
    case "OAuthCallback":
    case "OAuthCreateAccount":
      return {
        title: "Не удалось войти через Яндекс",
        detail:
          "Яндекс не подтвердил вход. Попробуйте ещё раз или войдите по email и паролю.",
      };
    case "OAuthAccountNotLinked":
      return {
        title: "Аккаунт уже есть",
        detail:
          "Этот email уже зарегистрирован другим способом. Войдите по email и паролю или напишите администратору.",
      };
    case "AccessDenied":
      return {
        title: "Доступ отклонён",
        detail: "Вы отменили вход или Яндекс не дал разрешение. Можно попробовать снова.",
      };
    case "Configuration":
      return {
        title: "Вход временно недоступен",
        detail: "Настройки авторизации ещё не готовы. Войдите по email или напишите в клуб.",
      };
    case "Verification":
      return {
        title: "Ссылка недействительна",
        detail: "Срок подтверждения истёк. Запросите вход заново.",
      };
    case "SessionRequired":
      return {
        title: "Нужно войти",
        detail: "Эта страница доступна только после входа в личный кабинет.",
      };
    case "Callback":
      return {
        title: "Ошибка при возврате с Яндекса",
        detail:
          "Проверьте, что в приложении Яндекса указан Redirect URI: https://reverans.online/api/auth/callback/yandex",
      };
    default:
      return {
        title: "Не удалось войти",
        detail: "Что-то пошло не так. Попробуйте ещё раз или войдите по email и паролю.",
      };
  }
}
