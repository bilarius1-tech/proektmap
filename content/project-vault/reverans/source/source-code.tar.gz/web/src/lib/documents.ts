import { DocumentStatus, DocumentType } from "@prisma/client";
import { prisma } from "@/lib/prisma";

/** Короткие понятные названия для родителей */
export const DOC_LABELS: Record<DocumentType, string> = {
  contract: "Договор на занятия",
  consent: "Согласие на данные",
  medical_clearance: "Медсправка",
};

export const DOC_HINTS: Record<DocumentType, string> = {
  contract: "Один раз подпишите онлайн — и можно переходить к оплате",
  consent: "Нужно по закону: подтверждаете обработку данных ребёнка",
  medical_clearance: "Фото или PDF справки — проверит администратор студии",
};

const AUTO_TYPES: DocumentType[] = [
  DocumentType.contract,
  DocumentType.consent,
  DocumentType.medical_clearance,
];

export async function ensureChildDocuments(childId: string) {
  for (const type of AUTO_TYPES) {
    const existing = await prisma.document.findFirst({
      where: { childId, type },
    });
    if (!existing) {
      await prisma.document.create({
        data: { childId, type, status: DocumentStatus.pending },
      });
    }
  }
}

export type DocTone = "ok" | "wait" | "need" | "review" | "expired";

export function documentStatusLabel(
  type: DocumentType,
  status: DocumentStatus,
  hasFile?: boolean,
) {
  if (status === DocumentStatus.signed) {
    return type === DocumentType.medical_clearance ? "Подтверждена" : "Подписано";
  }
  if (status === DocumentStatus.expired) return "Истекла";
  if (type === DocumentType.medical_clearance && hasFile) return "На проверке";
  if (type === DocumentType.medical_clearance) return "Прикрепите скан";
  return "Ждёт подписи";
}

export function documentStatusTone(
  type: DocumentType,
  status: DocumentStatus,
  hasFile?: boolean,
): DocTone {
  if (status === DocumentStatus.signed) return "ok";
  if (status === DocumentStatus.expired) return "expired";
  if (type === DocumentType.medical_clearance && hasFile) return "review";
  if (type === DocumentType.medical_clearance) return "need";
  return "wait";
}

export function paymentStatusLabel(status: string) {
  switch (status) {
    case "paid":
      return "Оплачено";
    case "failed":
      return "Ошибка";
    case "pending":
    default:
      return "Не оплачено";
  }
}

export function paymentTypeLabel(type: string) {
  switch (type) {
    case "monthly":
      return "Абонемент";
    case "individual":
      return "Инд. тренировка";
    default:
      return type;
  }
}

export function documentBody(type: DocumentType, childName: string, parentName: string) {
  if (type === DocumentType.contract) {
    return `Договор на занятия художественной гимнастикой в СКХГ «Реверанс».

Ребёнок: ${childName}
Родитель / законный представитель: ${parentName}

Подписывая, вы соглашаетесь с правилами студии и своевременной оплатой абонемента.`;
  }
  if (type === DocumentType.consent) {
    return `Согласие на обработку персональных данных ребёнка ${childName} и представителя ${parentName} для учёта в «Реверанс», договора и организации занятий (152‑ФЗ).`;
  }
  return `Медицинский допуск к занятиям для ${childName}. Сфотографируйте справку или выберите PDF — администратор проверит и подтвердит.`;
}
