import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions, homeForRole } from "@/lib/auth";

export async function getSession() {
  return getServerSession(authOptions);
}

export async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user || session.user.role !== "admin") {
    redirect("/login");
  }
  return session;
}

export async function requireParent() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    redirect("/login?callbackUrl=/cabinet");
  }
  if (session.user.role === "admin") {
    redirect("/admin");
  }
  if (session.user.role !== "parent" && session.user.role !== "coach") {
    redirect("/login");
  }
  return session;
}

export async function requireUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    redirect("/login");
  }
  return session;
}

export { homeForRole };
