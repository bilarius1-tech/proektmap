export const PENDING_PARENT_EMAIL_DOMAIN = "pending.reverans.local";

/** Только цифры; для РФ берём последние 10 (без кода страны). */
export function normalizePhone(phone: string | null | undefined): string {
  const digits = String(phone || "").replace(/\D/g, "");
  if (digits.length >= 11 && (digits.startsWith("7") || digits.startsWith("8"))) {
    return digits.slice(-10);
  }
  return digits.length >= 10 ? digits.slice(-10) : digits;
}

export function isPendingParentEmail(email: string | null | undefined): boolean {
  const e = String(email || "").toLowerCase();
  return e.endsWith(`@${PENDING_PARENT_EMAIL_DOMAIN}`);
}

export function isUsableParentEmail(email: string | null | undefined): boolean {
  const e = String(email || "").trim().toLowerCase();
  if (!e || !e.includes("@")) return false;
  if (isPendingParentEmail(e)) return false;
  if (e.endsWith("@yandex.oauth.local")) return false;
  return true;
}

export function pendingEmailForPhone(normPhone: string) {
  return `p.${normPhone}@${PENDING_PARENT_EMAIL_DOMAIN}`;
}

export function formatParentContact(parent: {
  email: string;
  phone?: string | null;
}): string {
  if (isUsableParentEmail(parent.email)) return parent.email;
  if (parent.phone) return `${parent.phone} · без почты`;
  return "без почты";
}
