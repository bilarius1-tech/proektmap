import type { Prisma } from "@prisma/client";

export type SiteSettingsView = {
  brandName: string;
  brandNameRu: string;
  tagline: string;
  city: string;
  address: string;
  phoneDisplay: string;
  phoneHref: string;
  email: string | null;
  telegram: string | null;
  telegramHref: string | null;
  whatsappHref: string | null;
  instagramHref: string | null;
  vkHref: string | null;
  youtubeHref: string | null;
  logoUrl: string | null;
  faviconUrl: string | null;
  ogImageUrl: string | null;
  footerAbout: string | null;
  copyrightText: string | null;
  yandexMetrikaId: string | null;
  yandexMetrikaOn: boolean;
  yandexWebvisor: boolean;
  yandexVerification: string | null;
  googleAnalyticsId: string | null;
};

export type HeroData = {
  eyebrow: string;
  title: string;
  brand: string;
  lead: string;
  btn1Text: string;
  btn1Href: string;
  btn2Text: string;
  btn2Href: string;
  linkText: string;
  linkHref: string;
  imageUrl: string;
  imageAlt: string;
  showRibbon: boolean;
};

export type WhyItem = { num: string; title: string; text: string };
export type WhyData = { title: string; subtitle: string; items: WhyItem[] };

export type ProgramItem = {
  age: string;
  title: string;
  text: string;
  btnText: string;
  btnHref: string;
};
export type ProgramsData = { title: string; subtitle: string; items: ProgramItem[] };

export type AboutData = {
  kicker: string;
  title: string;
  paragraphs: string[];
  btnText: string;
  btnHref: string;
  imageUrl: string;
  imageAlt: string;
};

export type ServiceItem = { title: string; text: string; linkText: string; linkHref: string };
export type ServicesData = { title: string; subtitle: string; items: ServiceItem[] };

export type PricingData = {
  title: string;
  subtitle: string;
  note: string;
  noteMuted: string;
  btnText: string;
  btnHref: string;
};

export type GalleryTeaserData = {
  title: string;
  subtitle: string;
  btnText: string;
  btnHref: string;
  limit: number;
};

export type FinalCtaData = {
  title: string;
  subtitle: string;
  btnText: string;
  btnHref: string;
  showPhone: boolean;
};

export type ContactSource = "phone" | "telegram" | "whatsapp" | "address" | "email";

export type ContactItem = {
  source: ContactSource;
  label: string;
  icon: string;
  enabled: boolean;
};

export type ContactsData = {
  title: string;
  subtitle: string;
  items: ContactItem[];
};

export type InstallAppData = {
  eyebrow: string;
  title: string;
  lead: string;
  imageUrl: string;
  imageAlt: string;
  badgeTitle: string;
  badgeSubtitle: string;
  iosTop: string;
  iosName: string;
  androidTop: string;
  androidName: string;
};

export type PageAboutData = {
  kicker: string;
  title: string;
  lead: string;
  heading: string;
  paragraphs: string[];
  bullets: string[];
  btnText: string;
  btnHref: string;
  imageUrl: string;
  imageAlt: string;
};

export type PricePlan = {
  schedule: string;
  price: string;
};

export type PriceGroup = {
  name: string;
  discipline: string;
  plans: PricePlan[];
  ctaText: string;
  ctaHref: string;
};

export type PagePricesData = {
  title: string;
  lead: string;
  groups: PriceGroup[];
  note: string;
  noteMuted: string;
};

export type PageContactsData = {
  title: string;
  lead: string;
  items: ContactItem[];
};

export type PageGalleryData = {
  title: string;
  lead: string;
};

export const DEFAULT_SETTINGS: SiteSettingsView = {
  brandName: "Реверанс",
  brandNameRu: "Реверанс",
  tagline: "Спортивный клуб художественной гимнастики",
  city: "Москва",
  address: "ул. Судостроительная, 44 стр. 1",
  phoneDisplay: "+7 (999) 623-13-01",
  phoneHref: "tel:+79996231301",
  email: null,
  telegram: "@sc_reverence_rg",
  telegramHref: "https://t.me/sc_reverence_rg",
  whatsappHref: "https://wa.me/79996231301",
  instagramHref: "https://www.instagram.com/sc_reverence_rg",
  vkHref: null,
  youtubeHref: null,
  logoUrl: "/brand/logo.png",
  faviconUrl: null,
  ogImageUrl: null,
  footerAbout:
    "Спортивный клуб художественной гимнастики в Москве. Обучаем детей от 3 лет с 2021 года.",
  copyrightText: null,
  yandexMetrikaId: null,
  yandexMetrikaOn: false,
  yandexWebvisor: true,
  yandexVerification: null,
  googleAnalyticsId: null,
};

export type LegalDocData = {
  title: string;
  updatedAt: string;
  bodyHtml: string;
};

export type CookieBannerData = {
  text: string;
  acceptLabel: string;
  declineLabel: string;
  privacyPath: string;
  consentPath: string;
  privacyLinkLabel: string;
  consentLinkLabel: string;
};

const PRIVACY_HTML = `
<p>Настоящая Политика в отношении обработки персональных данных (далее — Политика) составлена в соответствии с требованиями Федерального закона от 27.07.2006 № 152-ФЗ «О персональных данных» и определяет порядок обработки персональных данных и меры по обеспечению безопасности персональных данных, предпринимаемые оператором сайта спортивного клуба художественной гимнастики «Реверанс» (СКХГ «Реверанс») (далее — Оператор).</p>
<h3>1. Общие положения</h3>
<p>1.1. Оператор ставит своей важнейшей целью соблюдение прав и свобод человека и гражданина при обработке его персональных данных, в том числе защиты прав на неприкосновенность частной жизни, личную и семейную тайну.</p>
<p>1.2. Политика применяется ко всей информации, которую Оператор может получить о посетителях сайта <strong>https://reverans.online</strong> (далее — Сайт).</p>
<p>1.3. Используя Сайт, Пользователь подтверждает согласие с условиями настоящей Политики. При несогласии Пользователь должен прекратить использование Сайта.</p>
<h3>2. Основные понятия</h3>
<p><strong>Персональные данные</strong> — любая информация, относящаяся прямо или косвенно к определённому или определяемому физическому лицу (субъекту персональных данных).</p>
<p><strong>Обработка персональных данных</strong> — любое действие или совокупность действий с персональными данными, включая сбор, запись, систематизацию, накопление, хранение, уточнение, извлечение, использование, передачу, обезличивание, блокирование, удаление, уничтожение.</p>
<p><strong>Cookies</strong> — небольшие файлы, сохраняемые на устройстве Пользователя браузером, в том числе для обеспечения работы Сайта и аналитики.</p>
<h3>3. Оператор и контакты</h3>
<p>3.1. Оператор: спортивный клуб художественной гимнастики «Реверанс» (СКХГ «Реверанс»).</p>
<p>3.2. Адрес: г. Москва, ул. Судостроительная, 44 стр. 1.</p>
<p>3.3. Телефон: +7 (999) 623-13-01.</p>
<p>3.4. По вопросам обработки персональных данных Пользователь может обратиться по указанным контактам.</p>
<h3>4. Какие данные обрабатываются</h3>
<p>4.1. Данные, которые Пользователь может предоставить самостоятельно: имя, номер телефона, адрес электронной почты, сведения о ребёнке (возраст/имя — при заполнении форм записи), текст сообщения.</p>
<p>4.2. Данные, собираемые автоматически при использовании Сайта: IP-адрес, сведения о браузере и устройстве, дата и время посещения, адреса запрашиваемых страниц, данные файлов cookie, данные сервиса веб-аналитики Яндекс.Метрика (при наличии согласия Пользователя).</p>
<p>4.3. Оператор не обрабатывает специальные категории персональных данных без отдельного законного основания.</p>
<h3>5. Цели обработки</h3>
<ul>
<li>обеспечение работы Сайта и обратной связи с Пользователем;</li>
<li>запись на занятия, консультирование по услугам клуба;</li>
<li>исполнение договорных обязательств (при заключении договора);</li>
<li>улучшение качества Сайта и анализ посещаемости (при согласии на cookie/Метрику);</li>
<li>соблюдение требований законодательства РФ.</li>
</ul>
<h3>6. Правовые основания</h3>
<p>Обработка осуществляется на основании: согласия субъекта персональных данных; необходимости исполнения договора; исполнения обязанностей Оператора, установленных законодательством РФ; иных оснований, предусмотренных ст. 6 Федерального закона № 152-ФЗ.</p>
<h3>7. Cookies и Яндекс.Метрика</h3>
<p>7.1. Сайт может использовать файлы cookie, необходимые для работы, а также аналитические cookie сервиса Яндекс.Метрика.</p>
<p>7.2. Загрузка и использование Яндекс.Метрики осуществляется <strong>только после явного согласия</strong> Пользователя в баннере cookies («Принять»). При выборе «Отклонить» аналитические cookie и Метрика не подключаются.</p>
<p>7.3. Пользователь может изменить решение, очистив данные сайта в браузере (localStorage) и обновив страницу, либо обратившись к Оператору.</p>
<h3>8. Передача данных третьим лицам</h3>
<p>8.1. Оператор не продаёт персональные данные.</p>
<p>8.2. Передача возможна: хостинг-провайдеру и подрядчикам, обеспечивающим работу Сайта; сервису Яндекс.Метрика (при согласии); государственным органам в случаях, предусмотренных законом.</p>
<h3>9. Сроки хранения</h3>
<p>Персональные данные хранятся не дольше, чем этого требуют цели обработки, если иной срок не установлен договором или законом. По достижении целей данные уничтожаются или обезличиваются, если иное не предусмотрено законодательством.</p>
<h3>10. Права субъекта персональных данных</h3>
<p>Пользователь вправе получать сведения об обработке своих данных, требовать уточнения, блокирования или уничтожения данных при наличии оснований, отозвать согласие, обжаловать действия Оператора в Роскомнадзор или в суд.</p>
<h3>11. Меры защиты</h3>
<p>Оператор принимает необходимые правовые, организационные и технические меры для защиты персональных данных от неправомерного доступа, уничтожения, изменения, блокирования, копирования, предоставления, распространения.</p>
<h3>12. Изменение Политики</h3>
<p>Оператор вправе обновлять Политику. Актуальная версия всегда доступна на Сайте. Продолжение использования Сайта после публикации изменений означает согласие с новой редакцией в части, не требующей отдельного согласия.</p>
`.trim();

const CONSENT_HTML = `
<p>Настоящим я, субъект персональных данных (далее — Пользователь), свободно, своей волей и в своём интересе даю согласие спортивному клубу художественной гимнастики «Реверанс» (СКХГ «Реверанс») (далее — Оператор) на обработку моих персональных данных на условиях ниже и в соответствии с Федеральным законом от 27.07.2006 № 152-ФЗ «О персональных данных».</p>
<h3>1. Состав персональных данных</h3>
<p>Имя; номер телефона; адрес электронной почты; сведения, указанные в формах на сайте https://reverans.online; технические данные устройства и браузера; IP-адрес; данные файлов cookie; данные Яндекс.Метрики (при согласии на использование аналитических cookie).</p>
<h3>2. Цели обработки</h3>
<ul>
<li>обработка обращений и заявок с Сайта;</li>
<li>связь с Пользователем по вопросам услуг клуба;</li>
<li>заключение и исполнение договоров на оказание услуг;</li>
<li>обеспечение работоспособности Сайта;</li>
<li>статистика и улучшение Сайта с использованием Яндекс.Метрики — только при отдельном согласии в баннере cookies.</li>
</ul>
<h3>3. Действия с данными</h3>
<p>Сбор, запись, систематизация, накопление, хранение, уточнение (обновление, изменение), извлечение, использование, передача (предоставление, доступ), обезличивание, блокирование, удаление, уничтожение — с использованием средств автоматизации и без них.</p>
<h3>4. Срок действия согласия</h3>
<p>Согласие действует с момента его предоставления до достижения целей обработки либо до отзыва согласия Пользователем, если иное не предусмотрено законодательством РФ.</p>
<h3>5. Отзыв согласия</h3>
<p>Пользователь вправе отозвать согласие, направив обращение Оператору по контактам, указанным на Сайте (телефон +7 (999) 623-13-01, адрес: г. Москва, ул. Судостроительная, 44 стр. 1). В случае отзыва Оператор прекращает обработку и уничтожает данные в сроки, установленные законом, за исключением случаев, когда обработка может продолжаться на иных правовых основаниях.</p>
<h3>6. Cookies и Метрика</h3>
<p>Отдельное согласие на использование аналитических cookie и Яндекс.Метрики Пользователь выражает нажатием кнопки «Принять» в баннере на Сайте. Нажатие «Отклонить» означает отказ от аналитических cookie и Метрики; необходимые для работы Сайта технические процессы могут сохраняться в рамках закона.</p>
`.trim();

export const SECTION_DEFS: {
  key: string;
  label: string;
  group: "home" | "pages";
  data: Prisma.InputJsonValue;
}[] = [
  {
    key: "home.hero",
    label: "Главная — Hero",
    group: "home",
    data: {
      eyebrow: "Спортивный клуб художественной гимнастики",
      title: "Художественная\nгимнастика\nдля детей",
      brand: "Реверанс",
      lead: "Профессиональное обучение детей от 3 лет с индивидуальным подходом и подготовкой к соревнованиям.",
      btn1Text: "Записаться на занятие",
      btn1Href: "/contacts",
      btn2Text: "Оплатить",
      btn2Href: "/prices",
      linkText: "Договор",
      linkHref: "/contacts",
      imageUrl: "/brand/hero-placeholder.svg",
      imageAlt: "Художественная гимнастика — Реверанс",
      showRibbon: true,
    } satisfies HeroData,
  },
  {
    key: "home.why",
    label: "Главная — Почему выбирают нас",
    group: "home",
    data: {
      title: "Почему выбирают Реверанс",
      subtitle: "Мы создаём среду, где каждый ребёнок раскрывает свой потенциал.",
      items: [
        {
          num: "01",
          title: "Соревнования",
          text: "Регулярное участие в межрегиональных и всероссийских соревнованиях. Выполнение спортивных разрядов.",
        },
        {
          num: "02",
          title: "Индивидуальный подход",
          text: "Каждый ребёнок уникален. Мы разрабатываем персональную программу обучения с учётом способностей.",
        },
        {
          num: "03",
          title: "Профессиональные тренеры",
          text: "Опытные педагоги с высшим образованием и спортивными достижениями.",
        },
        {
          num: "04",
          title: "Работа на результат",
          text: "Систематические тренировки, ведущие к уверенному прогрессу и достижениям на соревнованиях.",
        },
      ],
    } satisfies WhyData,
  },
  {
    key: "home.programs",
    label: "Главная — Программы",
    group: "home",
    data: {
      title: "Наши программы",
      subtitle: "Возрастные ступени обучения — от первых шагов до спортивной подготовки.",
      items: [
        {
          age: "3–4 года",
          title: "Первые шаги",
          text: "Общее физическое развитие, элементы гимнастики в игровой форме.",
          btnText: "Подробнее",
          btnHref: "/contacts",
        },
        {
          age: "5–7 лет",
          title: "Начальная подготовка",
          text: "Освоение базовых элементов, работа с предметами.",
          btnText: "Подробнее",
          btnHref: "/contacts",
        },
        {
          age: "7+ лет",
          title: "Спортивная подготовка",
          text: "Повышение мастерства, участие в соревнованиях.",
          btnText: "Подробнее",
          btnHref: "/contacts",
        },
      ],
    } satisfies ProgramsData,
  },
  {
    key: "home.about",
    label: "Главная — О клубе",
    group: "home",
    data: {
      kicker: "О клубе",
      title: "О клубе",
      paragraphs: [
        "Реверанс — спортивный клуб художественной гимнастики в Москве. Обучаем детей от 3 лет с 2021 года.",
        "Работаем на результат с индивидуальным подходом к каждому ребёнку. Участие в межрегиональных и всероссийских соревнованиях.",
      ],
      btnText: "Подробнее о клубе",
      btnHref: "/about",
      imageUrl: "/brand/hero-placeholder.svg",
      imageAlt: "Воспитанницы клуба Реверанс",
    } satisfies AboutData,
  },
  {
    key: "home.services",
    label: "Главная — Услуги",
    group: "home",
    data: {
      title: "Услуги",
      subtitle: "Форматы занятий под цели семьи и уровень подготовки ребёнка.",
      items: [
        {
          title: "Групповые занятия",
          text: "Регулярные тренировки в возрастных группах с акцентом на технику, дисциплину и командный дух.",
          linkText: "Записаться →",
          linkHref: "/contacts",
        },
        {
          title: "Индивидуальные тренировки",
          text: "Персональная работа с педагогом для ускорения прогресса и подготовки отдельных элементов.",
          linkText: "Записаться →",
          linkHref: "/contacts",
        },
        {
          title: "Подготовка к соревнованиям",
          text: "Постановка программ, работа над артистичностью и уверенным выступлением на ковре.",
          linkText: "Записаться →",
          linkHref: "/contacts",
        },
      ],
    } satisfies ServicesData,
  },
  {
    key: "home.pricing",
    label: "Главная — Цены",
    group: "home",
    data: {
      title: "Цены",
      subtitle: "Актуальные тарифы по группам — суммы можно править в админке.",
      note: "",
      noteMuted: "",
      btnText: "Все тарифы",
      btnHref: "/prices",
    } satisfies PricingData,
  },
  {
    key: "home.gallery",
    label: "Главная — Наши фото",
    group: "home",
    data: {
      title: "Наши фото",
      subtitle: "Моменты тренировок, соревнований и жизни клуба.",
      btnText: "Вся галерея",
      btnHref: "/gallery",
      limit: 6,
    } satisfies GalleryTeaserData,
  },
  {
    key: "home.cta",
    label: "Главная — Финальный CTA",
    group: "home",
    data: {
      title: "Запишитесь\nна пробное занятие",
      subtitle: "Первый шаг к красивому движению, уверенности и спортивным достижениям.",
      btnText: "Записаться на пробное занятие",
      btnHref: "/contacts",
      showPhone: true,
    } satisfies FinalCtaData,
  },
  {
    key: "home.contacts",
    label: "Главная — Контакты",
    group: "home",
    data: {
      title: "Контакты",
      subtitle: "Реверанс — спортивный клуб художественной гимнастики",
      items: [
        { source: "phone", label: "Телефон", icon: "phone", enabled: true },
        { source: "telegram", label: "Telegram", icon: "telegram", enabled: true },
        { source: "whatsapp", label: "WhatsApp", icon: "whatsapp", enabled: true },
        { source: "address", label: "Адрес", icon: "address", enabled: true },
      ],
    } satisfies ContactsData,
  },
  {
    key: "home.installApp",
    label: "Главная — Сайт как приложение",
    group: "home",
    data: {
      eyebrow: "Удобнее с телефона",
      title: "Сайт как приложение",
      lead: "Добавьте «Реверанс» на экран — как привычные кнопки магазинов, откроется наш сайт с иконкой клуба.",
      imageUrl: "/brand/pwa/promo.webp",
      imageAlt: "Занятие художественной гимнастикой в СКХГ Реверанс",
      badgeTitle: "Реверанс",
      badgeSubtitle: "на домашнем экране",
      iosTop: "Добавить на",
      iosName: "iPhone",
      androidTop: "Добавить на",
      androidName: "Android",
    } satisfies InstallAppData,
  },
  {
    key: "page.about",
    label: "Страница — О нас",
    group: "pages",
    data: {
      kicker: "Реверанс",
      title: "О клубе",
      lead: "Спортивный клуб художественной гимнастики в Москве — дисциплина, красота движения и профессиональная подготовка.",
      heading: "Спортивный клуб Реверанс",
      paragraphs: [
        "Мы обучаем детей от 3 лет с 2021 года. Сочетаем строгую спортивную методику с внимательным отношением к каждому ребёнку.",
        "Занятия проходят в современном зале. Работаем на результат: техника, артистичность и уверенность на соревнованиях.",
      ],
      bullets: [
        "Индивидуальный подход и возрастные программы",
        "Участие в межрегиональных и всероссийских стартах",
        "Педагоги с профильным образованием",
      ],
      btnText: "Записаться",
      btnHref: "/contacts",
      imageUrl: "/brand/hero-placeholder.svg",
      imageAlt: "Реверанс",
    } satisfies PageAboutData,
  },
  {
    key: "page.prices",
    label: "Страница — Цены",
    group: "pages",
    data: {
      title: "Цены",
      lead: "Выберите подходящую группу для вашего ребёнка",
      groups: [
        {
          name: "Младшая группа",
          discipline: "Художественная гимнастика",
          plans: [
            { schedule: "2 раза в неделю по 1 часу", price: "7 500 ₽/месяц" },
            { schedule: "3 раза в неделю по 1 часу", price: "9 500 ₽/месяц" },
          ],
          ctaText: "Запишитесь на пробное занятие!",
          ctaHref: "/contacts",
        },
        {
          name: "Средняя группа",
          discipline: "Художественная гимнастика",
          plans: [
            { schedule: "2 раза в неделю по 1.5 часа", price: "9 500 ₽/месяц" },
            { schedule: "3 раза в неделю по 1.5 часа", price: "12 500 ₽/месяц" },
          ],
          ctaText: "Запишитесь на пробное занятие!",
          ctaHref: "/contacts",
        },
        {
          name: "Старшая группа",
          discipline: "Художественная гимнастика",
          plans: [{ schedule: "5 раз в неделю", price: "20 500 ₽/месяц" }],
          ctaText: "Запишитесь на пробное занятие!",
          ctaHref: "/contacts",
        },
      ],
      note: "Если в семье две и более дочери — скидка на каждое следующее ребёнка (уточняйте у администратора).",
      noteMuted: "Индивидуальные тренировки — в личном кабинете и по записи.",
    } satisfies PagePricesData,
  },
  {
    key: "page.contacts",
    label: "Страница — Контакты",
    group: "pages",
    data: {
      title: "Контакты",
      lead: "Реверанс — спортивный клуб художественной гимнастики",
      items: [
        { source: "address", label: "Адрес", icon: "address", enabled: true },
        { source: "phone", label: "Телефон", icon: "phone", enabled: true },
        { source: "telegram", label: "Telegram", icon: "telegram", enabled: true },
        { source: "whatsapp", label: "WhatsApp", icon: "whatsapp", enabled: true },
      ],
    } satisfies PageContactsData,
  },
  {
    key: "page.gallery",
    label: "Страница — Галерея",
    group: "pages",
    data: {
      title: "Галерея",
      lead: "Фотографии тренировок, соревнований и жизни клуба Реверанс.",
    } satisfies PageGalleryData,
  },
  {
    key: "legal.privacy",
    label: "Политика конфиденциальности",
    group: "pages",
    data: {
      title: "Политика в отношении обработки персональных данных",
      updatedAt: "05.09.2026",
      bodyHtml: PRIVACY_HTML,
    },
  },
  {
    key: "legal.consent",
    label: "Согласие на обработку ПДн",
    group: "pages",
    data: {
      title: "Согласие на обработку персональных данных при использовании сайта",
      updatedAt: "05.09.2026",
      bodyHtml: CONSENT_HTML,
    },
  },
  {
    key: "legal.cookieBanner",
    label: "Баннер cookie",
    group: "pages",
    data: {
      text: "Мы используем файлы cookie и сервис Яндекс.Метрика для анализа посещаемости и улучшения работы сайта. Продолжая пользоваться сайтом после согласия, вы подтверждаете ознакомление с документами ниже.",
      acceptLabel: "Принять",
      declineLabel: "Отклонить",
      privacyPath: "/politika-v-otnoshenii-obrabotki-personalnyh-dannyh",
      consentPath: "/soglasie-na-obrabotku-personalnyh-dannyh-pri-ispolzovanii-sayta",
      privacyLinkLabel: "Политикой конфиденциальности",
      consentLinkLabel: "Согласие на обработку персональных данных",
    },
  },
];



export const DEFAULT_SEO: { path: string; title: string; description: string; h1?: string }[] = [
  {
    path: "/",
    title: "Художественная гимнастика для детей в Москве | Реверанс",
    description:
      "Спортивный клуб художественной гимнастики Реверанс для детей от 3 лет в Москве. Индивидуальный подход, тренировки и соревнования.",
    h1: "Художественная гимнастика для детей",
  },
  {
    path: "/about",
    title: "О клубе",
    description: "О спортивном клубе художественной гимнастики «Реверанс» (СКХГ «Реверанс»).",
  },
  {
    path: "/prices",
    title: "Цены",
    description: "Цены на занятия в спортивном клубе Реверанс.",
  },
  {
    path: "/contacts",
    title: "Контакты",
    description: "Контакты спортивного клуба Реверанс в Москве.",
  },
  {
    path: "/gallery",
    title: "Галерея",
    description: "Фотогалерея спортивного клуба Реверанс.",
  },
  {
    path: "/politika-v-otnoshenii-obrabotki-personalnyh-dannyh",
    title: "Политика конфиденциальности",
    description: "Политика в отношении обработки персональных данных СКХГ «Реверанс».",
  },
  {
    path: "/soglasie-na-obrabotku-personalnyh-dannyh-pri-ispolzovanii-sayta",
    title: "Согласие на обработку персональных данных",
    description: "Согласие на обработку персональных данных при использовании сайта СКХГ «Реверанс».",
  },
];
