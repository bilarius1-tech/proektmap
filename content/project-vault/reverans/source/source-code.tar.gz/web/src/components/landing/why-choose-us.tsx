import type { WhyData } from "@/lib/cms-defaults";

export function WhyChooseUs({
  data,
  brandName = "Реверанс",
  enabled = true,
}: {
  data: WhyData;
  brandName?: string;
  enabled?: boolean;
}) {
  if (!enabled) return null;
  return (
    <section className="section" id="why">
      <div className="container">
        <div className="section-header">
          <span className="section-kicker">{brandName}</span>
          <h2>{data.title}</h2>
          <p>{data.subtitle}</p>
        </div>
        <div className="why-grid">
          {data.items.map((item, i) => {
            const n = Number.parseInt(String(item.num).replace(/\D/g, ""), 10);
            const displayNum = Number.isFinite(n) && n > 0 ? String(n) : String(i + 1);
            return (
              <article key={`${item.num}-${item.title}`} className={`why-card animate-in animate-delay-${i % 3}`}>
                <div className="why-num">{displayNum}</div>
                <h3>{item.title}</h3>
                <p>{item.text}</p>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
