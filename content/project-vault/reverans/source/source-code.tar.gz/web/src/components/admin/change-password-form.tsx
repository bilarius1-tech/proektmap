"use client";

import { useRef, useState, useTransition } from "react";
import { changeAdminPassword } from "@/app/admin/actions";

export function ChangePasswordForm() {
  const formRef = useRef<HTMLFormElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [pending, startTransition] = useTransition();

  return (
    <form
      ref={formRef}
      className="admin-form"
      onSubmit={(e) => {
        e.preventDefault();
        setError(null);
        setSuccess(false);
        const formData = new FormData(e.currentTarget);
        startTransition(async () => {
          const result = await changeAdminPassword(formData);
          if (result.ok) {
            setSuccess(true);
            formRef.current?.reset();
          } else {
            setError(result.error);
          }
        });
      }}
    >
      <label>
        Текущий пароль
        <input type="password" name="currentPassword" autoComplete="current-password" required />
      </label>
      <label>
        Новый пароль
        <input
          type="password"
          name="newPassword"
          autoComplete="new-password"
          minLength={8}
          required
        />
      </label>
      <label>
        Повторите новый пароль
        <input
          type="password"
          name="confirmPassword"
          autoComplete="new-password"
          minLength={8}
          required
        />
      </label>
      {error ? <p className="admin-error">{error}</p> : null}
      {success ? <p className="admin-success">Пароль обновлён</p> : null}
      <button type="submit" disabled={pending}>
        {pending ? "Сохраняем…" : "Сменить пароль"}
      </button>
    </form>
  );
}
