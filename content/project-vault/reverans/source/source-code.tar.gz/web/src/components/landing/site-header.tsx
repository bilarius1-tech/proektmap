"use client";

import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

const LINKS = [
  { href: "/", label: "Главная" },
  { href: "/about", label: "О нас" },
  { href: "/prices", label: "Цены" },
  { href: "/gallery", label: "Галерея" },
  { href: "/#services", label: "Услуги" },
  { href: "/contacts", label: "Контакты" },
] as const;

export function SiteHeader({
  brandName,
  tagline,
  logoUrl,
}: {
  brandName: string;
  tagline: string;
  logoUrl: string;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`header${scrolled ? " is-scrolled" : ""}`}>
      <div className="container">
        <Link href="/" className="logo-mark" onClick={() => setOpen(false)}>
          <Image src={logoUrl} alt={brandName} width={52} height={52} priority />
          <span className="logo-mark-text">
            <span className="logo-mark-name">{brandName}</span>
            <span className="logo-mark-sub">{tagline}</span>
          </span>
        </Link>
        <nav className={`nav${open ? " open" : ""}`} aria-label="Основная навигация">
          {LINKS.map((link) => {
            const active =
              link.href === "/"
                ? pathname === "/"
                : link.href.startsWith("/#")
                  ? false
                  : pathname === link.href || pathname.startsWith(`${link.href}/`);
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`nav-link${active ? " active" : ""}`}
                onClick={() => setOpen(false)}
              >
                {link.label}
              </Link>
            );
          })}
          <Link href="/cabinet" className="nav-cta" onClick={() => setOpen(false)}>
            Личный кабинет
          </Link>
        </nav>
        <button
          type="button"
          className="mobile-menu-btn"
          aria-expanded={open}
          aria-label={open ? "Закрыть меню" : "Открыть меню"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? "✕" : "☰"}
        </button>
      </div>
    </header>
  );
}
