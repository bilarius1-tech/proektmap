import Link from "next/link";
import { RibbonLine } from "@/components/landing/ribbon-line";
import type { HeroData } from "@/lib/cms-defaults";

export function Hero({ data, enabled = true }: { data: HeroData; enabled?: boolean }) {
  if (!enabled) return null;
  const titleLines = data.title.split("\n").filter(Boolean);

  return (
    <section className="hero">
      {data.showRibbon ? <RibbonLine className="ribbon-hero" /> : null}
      <div className="container">
        <div className="hero-content animate-in">
          <span className="hero-eyebrow">{data.eyebrow}</span>
          <h1>
            {titleLines.map((line) => (
              <span key={line}>
                {line}
                <br />
              </span>
            ))}
          </h1>
          <p className="hero-lead">{data.lead}</p>
          <div className="hero-brand brand-script">{data.brand}</div>
          <div className="hero-buttons">
            <Link href={data.btn1Href} className="btn btn-primary">
              {data.btn1Text}
            </Link>
            <Link href={data.btn2Href} className="btn btn-secondary">
              {data.btn2Text}
            </Link>
          </div>
          {data.linkText ? (
            <div className="hero-extra">
              <Link href={data.linkHref} className="btn-link">
                {data.linkText}
              </Link>
            </div>
          ) : null}
        </div>
        <div className="hero-visual animate-in animate-delay-2">
          {data.showRibbon ? (
            <svg className="hero-ribbon-svg" viewBox="0 0 520 560" fill="none" aria-hidden>
              <path
                d="M40 420 C120 280, 200 220, 280 200 C380 175, 440 120, 480 40"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
              />
              <path
                d="M20 480 C110 330, 210 260, 300 240 C400 215, 460 150, 500 80"
                stroke="currentColor"
                strokeWidth="1.2"
                strokeLinecap="round"
                opacity="0.5"
              />
            </svg>
          ) : null}
          <div className="hero-visual-frame">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={data.imageUrl} alt={data.imageAlt} width={640} height={800} />
          </div>
        </div>
      </div>
    </section>
  );
}
