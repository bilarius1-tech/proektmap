"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

type NavItem = { href: string; label: string; exact?: boolean };

const STUDIO: readonly NavItem[] = [
  { href: "/admin", label: "Дэшборд", exact: true },
  { href: "/admin/groups", label: "Группы" },
  { href: "/admin/children", label: "Дети" },
  { href: "/admin/coaches", label: "Педагоги" },
  { href: "/admin/payments", label: "Платежи" },
  { href: "/admin/trainings", label: "Инд. тренировки" },
  { href: "/admin/documents", label: "Документы" },
];

const SITE: readonly NavItem[] = [
  { href: "/admin/site", label: "Обзор сайта", exact: true },
  { href: "/admin/site/content", label: "Тексты и блоки" },
  { href: "/admin/site/gallery", label: "Галерея" },
  { href: "/admin/site/legal", label: "Политика и cookies" },
  { href: "/admin/site/seo", label: "SEO" },
  { href: "/admin/site/settings", label: "Контакты и Метрика" },
];

const SYSTEM: readonly NavItem[] = [{ href: "/admin/settings", label: "Пароль входа" }];

const MOBILE_TABS = [
  { href: "/admin/children", label: "Дети" },
  { href: "/admin/payments", label: "Платежи" },
  { href: "/admin/groups", label: "Группы" },
] as const;

const STUDIO_MORE: readonly NavItem[] = [
  { href: "/admin", label: "Дэшборд", exact: true },
  { href: "/admin/documents", label: "Документы" },
  { href: "/admin/trainings", label: "Инд. тренировки" },
  { href: "/admin/coaches", label: "Педагоги" },
];

function isActive(pathname: string, item: NavItem) {
  if (item.exact) return pathname === item.href;
  return pathname === item.href || pathname.startsWith(`${item.href}/`);
}

function isTabActive(pathname: string, href: string) {
  return pathname === href || pathname.startsWith(`${href}/`);
}

function NavLinks({
  items,
  pathname,
  onNavigate,
}: {
  items: readonly NavItem[];
  pathname: string;
  onNavigate?: () => void;
}) {
  return (
    <nav className="admin-nav">
      {items.map((item) => (
        <Link
          key={item.href}
          href={item.href}
          className={`admin-nav-link${isActive(pathname, item) ? " is-active" : ""}`}
          onClick={onNavigate}
        >
          {item.label}
        </Link>
      ))}
    </nav>
  );
}

function AccordionGroup({
  title,
  hint,
  items,
  pathname,
  defaultOpen,
  onNavigate,
}: {
  title: string;
  hint: string;
  items: readonly NavItem[];
  pathname: string;
  defaultOpen: boolean;
  onNavigate?: () => void;
}) {
  const [open, setOpen] = useState(defaultOpen);

  useEffect(() => {
    setOpen(defaultOpen);
  }, [defaultOpen]);

  return (
    <div className={`admin-nav-group admin-accordion${open ? " is-open" : ""}`}>
      <button
        type="button"
        className="admin-accordion-trigger"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        <span className="admin-nav-group-title">{title}</span>
        <span className="admin-accordion-chevron" aria-hidden>
          {open ? "▾" : "▸"}
        </span>
      </button>
      <div className="admin-nav-group-hint">{hint}</div>
      {open ? <NavLinks items={items} pathname={pathname} onNavigate={onNavigate} /> : null}
    </div>
  );
}

function FlatGroup({
  title,
  hint,
  items,
  pathname,
  onNavigate,
}: {
  title: string;
  hint: string;
  items: readonly NavItem[];
  pathname: string;
  onNavigate?: () => void;
}) {
  return (
    <div className="admin-nav-group">
      <div className="admin-nav-group-title">{title}</div>
      <div className="admin-nav-group-hint">{hint}</div>
      <NavLinks items={items} pathname={pathname} onNavigate={onNavigate} />
    </div>
  );
}

export function AdminNav({ email }: { email: string }) {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);

  const siteOpen = pathname.startsWith("/admin/site");
  const systemOpen = pathname === "/admin/settings" || pathname.startsWith("/admin/settings/");
  const menuTabActive =
    menuOpen ||
    pathname === "/admin" ||
    pathname.startsWith("/admin/coaches") ||
    pathname.startsWith("/admin/documents") ||
    pathname.startsWith("/admin/trainings") ||
    siteOpen ||
    systemOpen;

  useEffect(() => {
    setMenuOpen(false);
  }, [pathname]);

  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setMenuOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.body.classList.add("admin-sheet-open");
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.classList.remove("admin-sheet-open");
    };
  }, [menuOpen]);

  const closeMenu = () => setMenuOpen(false);

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="admin-aside admin-aside-desktop">
        <div className="admin-brand">Реверанс</div>
        <div className="admin-muted">Админ-панель</div>

        <FlatGroup
          title="Студия"
          hint="Дети, группы, оплаты, документы"
          items={STUDIO}
          pathname={pathname}
        />
        <AccordionGroup
          title="Сайт"
          hint="Тексты шаблона, фото, SEO, Метрика"
          items={SITE}
          pathname={pathname}
          defaultOpen={siteOpen}
        />
        <AccordionGroup
          title="Система"
          hint="Безопасность входа"
          items={SYSTEM}
          pathname={pathname}
          defaultOpen={systemOpen}
        />

        <div className="admin-muted" style={{ marginTop: 28 }}>
          {email}
        </div>
        <Link href="/api/auth/signout" className="admin-logout">
          Выйти
        </Link>
        <Link href="/" className="admin-site-link" target="_blank">
          Открыть сайт ↗
        </Link>
      </aside>

      {/* Mobile sticky header */}
      <header className="admin-mobile-header">
        <div className="admin-mobile-header-brand">
          <span className="admin-brand">Реверанс</span>
          <span className="admin-mobile-header-sub">Админ</span>
        </div>
        <Link href="/api/auth/signout" className="admin-mobile-logout">
          Выйти
        </Link>
      </header>

      {/* Mobile bottom tabs */}
      <nav className="admin-bottom-tabs" aria-label="Основные разделы">
        {MOBILE_TABS.map((tab) => (
          <Link
            key={tab.href}
            href={tab.href}
            className={`admin-bottom-tab${isTabActive(pathname, tab.href) && !menuOpen ? " is-active" : ""}`}
          >
            {tab.label}
          </Link>
        ))}
        <button
          type="button"
          className={`admin-bottom-tab admin-bottom-tab-btn${menuTabActive ? " is-active" : ""}`}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((v) => !v)}
        >
          Меню
        </button>
      </nav>

      {/* Mobile menu sheet */}
      {menuOpen ? (
        <div className="admin-sheet-root">
          <button type="button" className="admin-sheet-backdrop" aria-label="Закрыть меню" onClick={closeMenu} />
          <div className="admin-sheet" role="dialog" aria-modal="true" aria-label="Меню админки">
            <div className="admin-sheet-handle" />
            <div className="admin-sheet-head">
              <strong>Меню</strong>
              <button type="button" className="admin-sheet-close" onClick={closeMenu}>
                Закрыть
              </button>
            </div>
            <p className="admin-muted admin-sheet-email">{email}</p>

            <FlatGroup
              title="Студия"
              hint="Остальные разделы"
              items={STUDIO_MORE}
              pathname={pathname}
              onNavigate={closeMenu}
            />
            <AccordionGroup
              title="Сайт"
              hint="Тексты, фото, SEO, Метрика"
              items={SITE}
              pathname={pathname}
              defaultOpen={siteOpen}
              onNavigate={closeMenu}
            />
            <AccordionGroup
              title="Система"
              hint="Безопасность входа"
              items={SYSTEM}
              pathname={pathname}
              defaultOpen={systemOpen}
              onNavigate={closeMenu}
            />

            <Link href="/" className="admin-site-link" target="_blank" onClick={closeMenu}>
              Открыть сайт ↗
            </Link>
          </div>
        </div>
      ) : null}
    </>
  );
}
