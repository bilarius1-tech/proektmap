"use client";

import { useEffect, useId, useState, type ReactNode } from "react";
import { IconPlus, IconPencil } from "@/components/icons/doc-icons";

export function AdminModal({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  const titleId = useId();

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", onKey);
    document.body.classList.add("admin-sheet-open");
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.classList.remove("admin-sheet-open");
    };
  }, [onClose]);

  return (
    <div className="admin-modal-root">
      <button type="button" className="admin-modal-backdrop" aria-label="Закрыть" onClick={onClose} />
      <div className="admin-modal-panel" role="dialog" aria-modal="true" aria-labelledby={titleId}>
        <div className="admin-modal-bar">
          <strong id={titleId}>{title}</strong>
          <button type="button" className="admin-btn admin-btn-ghost" onClick={onClose}>
            Закрыть
          </button>
        </div>
        <div className="admin-modal-body">{children}</div>
      </div>
    </div>
  );
}

export function AdminModalForm({
  title,
  triggerLabel,
  triggerVariant = "primary",
  icon = "plus",
  children,
}: {
  title: string;
  triggerLabel: string;
  triggerVariant?: "primary" | "ghost";
  icon?: "plus" | "pencil" | "none";
  children: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const Icon = icon === "pencil" ? IconPencil : icon === "plus" ? IconPlus : null;

  return (
    <>
      <button
        type="button"
        className={`admin-btn${triggerVariant === "ghost" ? " admin-btn-ghost" : ""}${Icon ? " admin-btn-icon" : ""}`}
        onClick={() => setOpen(true)}
      >
        {Icon ? <Icon className="admin-btn-svg" /> : null}
        {triggerLabel}
      </button>
      {open ? (
        <AdminModal title={title} onClose={() => setOpen(false)}>
          {children}
        </AdminModal>
      ) : null}
    </>
  );
}
