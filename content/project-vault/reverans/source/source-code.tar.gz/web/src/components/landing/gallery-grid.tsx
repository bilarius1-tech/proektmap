"use client";

import { useCallback, useEffect, useState } from "react";

export type LightboxPhoto = {
  id: string;
  src: string;
  thumbSrc?: string;
  alt: string;
  caption?: string;
};

export function GalleryGrid({
  photos,
  className = "gallery-page-grid",
  itemClassName = "gallery-page-item",
}: {
  photos: LightboxPhoto[];
  className?: string;
  itemClassName?: string;
}) {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const close = useCallback(() => setOpenIndex(null), []);
  const prev = useCallback(() => {
    setOpenIndex((i) => (i === null ? i : (i + photos.length - 1) % photos.length));
  }, [photos.length]);
  const next = useCallback(() => {
    setOpenIndex((i) => (i === null ? i : (i + 1) % photos.length));
  }, [photos.length]);

  useEffect(() => {
    if (openIndex === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") close();
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [openIndex, close, prev, next]);

  if (photos.length === 0) return null;

  const current = openIndex !== null ? photos[openIndex] : null;

  return (
    <>
      <div className={className}>
        {photos.map((photo, index) => (
          <button
            key={photo.id}
            type="button"
            className={`${itemClassName} gallery-open-btn`}
            onClick={() => setOpenIndex(index)}
            aria-label={photo.alt || "Открыть фото"}
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={photo.thumbSrc || photo.src} alt={photo.alt} />
            {photo.caption ? <span className="gallery-cap">{photo.caption}</span> : null}
          </button>
        ))}
      </div>

      {current ? (
        <div className="lightbox" role="dialog" aria-modal="true" onClick={close}>
          <div className="lightbox-inner" onClick={(e) => e.stopPropagation()}>
            <button type="button" className="lightbox-close" onClick={close} aria-label="Закрыть">
              ✕
            </button>
            {photos.length > 1 ? (
              <>
                <button
                  type="button"
                  className="lightbox-nav lightbox-prev"
                  onClick={prev}
                  aria-label="Назад"
                >
                  ‹
                </button>
                <button
                  type="button"
                  className="lightbox-nav lightbox-next"
                  onClick={next}
                  aria-label="Вперёд"
                >
                  ›
                </button>
              </>
            ) : null}
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={current.src} alt={current.alt} className="lightbox-img" />
            {current.caption ? <p className="lightbox-caption">{current.caption}</p> : null}
          </div>
        </div>
      ) : null}
    </>
  );
}
