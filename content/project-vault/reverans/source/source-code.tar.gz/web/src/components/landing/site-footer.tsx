import Image from "next/image";
import Link from "next/link";
import { InstallAppBanner } from "@/components/landing/install-app-banner";
import { getSection, getSiteSettings } from "@/lib/cms";
import type { InstallAppData } from "@/lib/cms-defaults";

export async function SiteFooter() {
  const [settings, installApp] = await Promise.all([
    getSiteSettings(),
    getSection<InstallAppData>("home.installApp"),
  ]);
  const logo = settings.logoUrl || "/brand/logo.png";
  const year = new Date().getFullYear();

  return (
    <>
      <InstallAppBanner data={installApp.data} enabled={installApp.enabled} />
      <footer className="footer">
        <div className="container">
          <div className="footer-grid">
            <div className="footer-brand">
              <Link href="/" className="logo-mark">
                <Image src={logo} alt={settings.brandName} width={48} height={48} />
                <span className="logo-mark-text">
                  <span className="logo-mark-name">{settings.brandName}</span>
                </span>
              </Link>
              <p>{settings.footerAbout}</p>
            </div>
            <div>
              <h4 className="footer-title">Навигация</h4>
              <ul className="footer-links">
                <li>
                  <Link href="/">Главная</Link>
                </li>
                <li>
                  <Link href="/about">О нас</Link>
                </li>
                <li>
                  <Link href="/prices">Цены</Link>
                </li>
                <li>
                  <Link href="/gallery">Галерея</Link>
                </li>
                <li>
                  <Link href="/contacts">Контакты</Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="footer-title">Услуги</h4>
              <ul className="footer-links">
                <li>
                  <Link href="/#services">Групповые занятия</Link>
                </li>
                <li>
                  <Link href="/#services">Индивидуальные тренировки</Link>
                </li>
                <li>
                  <Link href="/#services">Подготовка к соревнованиям</Link>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="footer-title">Контакты</h4>
              <div className="footer-contact-item">
                {settings.city}, {settings.address}
              </div>
              <div className="footer-contact-item">
                <a href={settings.phoneHref}>{settings.phoneDisplay}</a>
              </div>
              {settings.telegramHref ? (
                <div className="footer-contact-item">
                  <a href={settings.telegramHref} target="_blank" rel="noopener noreferrer">
                    Telegram {settings.telegram}
                  </a>
                </div>
              ) : null}
            </div>
          </div>
          <div className="footer-bottom">
            <p>
              {settings.copyrightText ||
                `© ${year} СКХГ «${settings.brandNameRu}». Все права защищены.`}
            </p>
            <div className="footer-legal-links">
              <Link href="/politika-v-otnoshenii-obrabotki-personalnyh-dannyh">
                Политика конфиденциальности
              </Link>
              <Link href="/soglasie-na-obrabotku-personalnyh-dannyh-pri-ispolzovanii-sayta">
                Согласие на обработку ПДн
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}
