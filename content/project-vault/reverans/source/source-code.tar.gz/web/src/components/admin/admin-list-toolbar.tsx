import Link from "next/link";
import type { ReactNode } from "react";
import { IconSearch } from "@/components/icons/doc-icons";

export function AdminListToolbar({
  action,
  searchPlaceholder = "Поиск…",
  q = "",
  filters,
  trailing,
}: {
  action: string;
  searchPlaceholder?: string;
  q?: string;
  filters?: ReactNode;
  trailing?: ReactNode;
}) {
  return (
    <form className="admin-toolbar" method="get" action={action}>
      <label className="admin-toolbar-search">
        <IconSearch className="admin-toolbar-search-svg" />
        <input
          type="search"
          name="q"
          defaultValue={q}
          placeholder={searchPlaceholder}
          aria-label="Поиск"
        />
      </label>
      {filters}
      <button type="submit" className="admin-btn admin-btn-ghost">
        Найти
      </button>
      {trailing}
    </form>
  );
}

export function AdminPagination({
  basePath,
  page,
  totalPages,
  q,
  extraParams,
}: {
  basePath: string;
  page: number;
  totalPages: number;
  q?: string;
  extraParams?: Record<string, string | undefined>;
}) {
  if (totalPages <= 1) return null;

  function href(p: number) {
    const sp = new URLSearchParams();
    if (q) sp.set("q", q);
    if (extraParams) {
      for (const [k, v] of Object.entries(extraParams)) {
        if (v) sp.set(k, v);
      }
    }
    if (p > 1) sp.set("page", String(p));
    const qs = sp.toString();
    return qs ? `${basePath}?${qs}` : basePath;
  }

  return (
    <nav className="admin-pagination" aria-label="Страницы">
      {page > 1 ? (
        <Link href={href(page - 1)} className="admin-btn admin-btn-ghost">
          ← Назад
        </Link>
      ) : (
        <span className="admin-btn admin-btn-ghost" style={{ opacity: 0.4 }}>
          ← Назад
        </span>
      )}
      <span className="admin-pagination-info">
        {page} / {totalPages}
      </span>
      {page < totalPages ? (
        <Link href={href(page + 1)} className="admin-btn admin-btn-ghost">
          Вперёд →
        </Link>
      ) : (
        <span className="admin-btn admin-btn-ghost" style={{ opacity: 0.4 }}>
          Вперёд →
        </span>
      )}
    </nav>
  );
}
