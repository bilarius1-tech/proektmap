"use client";

import { useRouter } from "next/navigation";
import { useRef, useState } from "react";

/** Compress image in browser before upload (phone-friendly). PDF passes through. */
async function compressImage(file: File, maxEdge = 1800, quality = 0.72): Promise<Blob> {
  if (file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")) {
    return file;
  }
  if (!file.type.startsWith("image/")) {
    return file;
  }

  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
  const w = Math.max(1, Math.round(bitmap.width * scale));
  const h = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return file;
  ctx.drawImage(bitmap, 0, 0, w, h);
  bitmap.close();

  const blob = await new Promise<Blob | null>((resolve) =>
    canvas.toBlob((b) => resolve(b), "image/jpeg", quality),
  );
  return blob || file;
}

export function MedicalUpload({
  documentId,
  hasFile,
  signed,
}: {
  documentId: string;
  hasFile: boolean;
  signed: boolean;
}) {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);

  if (signed) {
    return (
      <p className="cab-ok" style={{ marginBottom: 0 }}>
        Меддопуск подтверждён администратором.
        {hasFile ? (
          <>
            {" "}
            <a href={`/api/documents/${documentId}/file`} target="_blank" rel="noopener noreferrer">
              Открыть скан
            </a>
          </>
        ) : null}
      </p>
    );
  }

  async function onFile(file: File | null) {
    if (!file) return;
    setLoading(true);
    setError(null);
    setOk(null);
    try {
      const compressed = await compressImage(file);
      const fd = new FormData();
      fd.set("documentId", documentId);
      const name =
        file.type === "application/pdf" || file.name.toLowerCase().endsWith(".pdf")
          ? file.name
          : file.name.replace(/\.\w+$/, "") + ".jpg";
      fd.set("file", compressed, name);
      const res = await fetch("/api/cabinet/medical-upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Не удалось загрузить");
        setLoading(false);
        return;
      }
      setOk(data.message || "Отправлено");
      setLoading(false);
      router.refresh();
    } catch {
      setError("Ошибка сети или обработки фото");
      setLoading(false);
    }
  }

  return (
    <div className="cab-medical-upload">
      {error ? <div className="cab-error">{error}</div> : null}
      {ok ? <div className="cab-ok">{ok}</div> : null}
      {hasFile ? (
        <p className="cab-child-meta" style={{ marginBottom: 10 }}>
          Скан у администратора на проверке.{" "}
          <a href={`/api/documents/${documentId}/file`} target="_blank" rel="noopener noreferrer">
            Посмотреть
          </a>
          {" · "}можно заменить фото ниже. Оплату ждать не нужно.
        </p>
      ) : (
        <p className="cab-warn" style={{ marginBottom: 10 }}>
          Сфотографируйте справку или выберите файл с телефона / компьютера (фото или PDF).
        </p>
      )}
      <input
        ref={inputRef}
        type="file"
        accept="image/*,application/pdf"
        capture="environment"
        className="cab-file-input"
        disabled={loading}
        onChange={(e) => void onFile(e.target.files?.[0] || null)}
      />
      <div className="cab-actions">
        <button
          type="button"
          className="cab-btn"
          disabled={loading}
          onClick={() => inputRef.current?.click()}
        >
          {loading ? "Сжимаем и отправляем…" : hasFile ? "Заменить скан" : "Прикрепить скан"}
        </button>
      </div>
    </div>
  );
}
