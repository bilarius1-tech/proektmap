import type { ContactItem, ContactsData, SiteSettingsView } from "@/lib/cms-defaults";
import { ContactIcon } from "@/components/icons/contact-icons";

function resolveContact(item: ContactItem, settings: SiteSettingsView) {
  switch (item.source) {
    case "phone":
      return {
        href: settings.phoneHref,
        value: settings.phoneDisplay,
        external: false,
        lines: null as string[] | null,
      };
    case "telegram":
      if (!settings.telegramHref) return null;
      return {
        href: settings.telegramHref,
        value: settings.telegram || "Telegram",
        external: true,
        lines: null,
      };
    case "whatsapp":
      if (!settings.whatsappHref) return null;
      return {
        href: settings.whatsappHref,
        value: "Написать",
        external: true,
        lines: null,
      };
    case "email":
      if (!settings.email) return null;
      return {
        href: `mailto:${settings.email}`,
        value: settings.email,
        external: false,
        lines: null,
      };
    case "address":
      return {
        href: null,
        value: null,
        external: false,
        lines: [settings.city, settings.address],
      };
    default:
      return null;
  }
}

export function ContactsBlock({
  data,
  settings,
  enabled = true,
}: {
  data: ContactsData;
  settings: SiteSettingsView;
  enabled?: boolean;
}) {
  if (!enabled) return null;
  const items = (data.items || []).filter((i) => i.enabled !== false);

  return (
    <section className="section section-alt" id="contacts">
      <div className="container">
        <div className="section-header">
          <h2>{data.title}</h2>
          <p>{data.subtitle || `${settings.brandName} — ${settings.tagline}`}</p>
        </div>
        <div className="contacts-row">
          {items.map((item) => {
            const resolved = resolveContact(item, settings);
            if (!resolved) return null;
            const inner = (
              <>
                <div className="contact-chip-icon" aria-hidden>
                  <ContactIcon name={item.icon || item.source} />
                </div>
                <div className="contact-chip-label">{item.label}</div>
                <div className="contact-chip-value">
                  {resolved.lines
                    ? resolved.lines.map((line) => (
                        <span key={line}>
                          {line}
                          <br />
                        </span>
                      ))
                    : resolved.value}
                </div>
              </>
            );
            if (resolved.href) {
              return (
                <a
                  key={`${item.source}-${item.label}`}
                  className="contact-chip"
                  href={resolved.href}
                  target={resolved.external ? "_blank" : undefined}
                  rel={resolved.external ? "noopener noreferrer" : undefined}
                >
                  {inner}
                </a>
              );
            }
            return (
              <div key={`${item.source}-${item.label}`} className="contact-chip">
                {inner}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

export { resolveContact };
