import {
  IconCircleAlert,
  IconCircleCheck,
  IconClock,
  IconHeartPulse,
  IconFilePen,
  IconShieldCheck,
} from "@/components/icons/doc-icons";
import { documentStatusLabel, documentStatusTone, paymentStatusLabel } from "@/lib/documents";
import type { DocumentStatus, DocumentType } from "@prisma/client";

export function PaymentStatusBadge({ status }: { status: string }) {
  const label = paymentStatusLabel(status);
  const tone =
    status === "paid" ? "ok" : status === "failed" ? "bad" : "wait";
  const Icon =
    status === "paid" ? IconCircleCheck : status === "failed" ? IconCircleAlert : IconClock;
  return (
    <span className={`admin-status admin-status-${tone}`}>
      <Icon className="admin-status-svg" />
      {label}
    </span>
  );
}

export function DocumentStatusBadge({
  type,
  status,
  hasFile,
}: {
  type: DocumentType;
  status: DocumentStatus;
  hasFile?: boolean;
}) {
  const tone = documentStatusTone(type, status, hasFile);
  const label = documentStatusLabel(type, status, hasFile);
  const map = {
    ok: "ok",
    wait: "wait",
    need: "need",
    review: "review",
    expired: "bad",
  } as const;
  const Icon =
    type === "medical_clearance"
      ? IconHeartPulse
      : type === "consent"
        ? IconShieldCheck
        : IconFilePen;
  return (
    <span className={`admin-status admin-status-${map[tone]}`}>
      <Icon className="admin-status-svg" />
      {label}
    </span>
  );
}
