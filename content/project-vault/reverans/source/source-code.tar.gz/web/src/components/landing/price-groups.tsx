import Link from "next/link";
import type { PriceGroup } from "@/lib/cms-defaults";

function IconCalendar() {
  return (
    <span className="price-plan-icon" aria-hidden>
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2">
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M3 10h18M8 3v4M16 3v4" />
      </svg>
    </span>
  );
}

function IconRub() {
  return (
    <span className="price-plan-icon" aria-hidden>
      <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="2">
        <path d="M7 6h7.5a4 4 0 0 1 0 8H7V6z" />
        <path d="M7 14h8M7 18h6" />
      </svg>
    </span>
  );
}

export function PriceGroups({
  groups,
  compact = false,
}: {
  groups: PriceGroup[];
  compact?: boolean;
}) {
  if (!groups?.length) return null;

  return (
    <div className={`price-groups ${compact ? "price-groups-compact" : ""}`}>
      {groups.map((group) => (
        <article key={group.name} className="price-group">
          <header className="price-group-head">
            <h3>{group.name}</h3>
            {group.discipline ? <p>{group.discipline}</p> : null}
          </header>
          <div className="price-group-body">
            {group.plans.map((plan) => (
              <div key={`${group.name}-${plan.schedule}`} className="price-plan">
                <div className="price-plan-row">
                  <IconCalendar />
                  <span>{plan.schedule}</span>
                </div>
                <div className="price-plan-divider" />
                <div className="price-plan-row price-plan-row-price">
                  <IconRub />
                  <strong>{plan.price}</strong>
                </div>
              </div>
            ))}
            {group.ctaText ? (
              <Link href={group.ctaHref || "/contacts"} className="btn btn-primary price-group-cta">
                {group.ctaText}
              </Link>
            ) : null}
          </div>
        </article>
      ))}
    </div>
  );
}
