"use client";

import { useState, useTransition } from "react";
import { updatePageSeo } from "@/app/admin/site/actions";

type SeoRow = {
  path: string;
  title: string;
  description: string;
  h1: string | null;
  ogTitle: string | null;
  ogDescription: string | null;
  ogImageUrl: string | null;
};

function SeoCard({ row }: { row: SeoRow }) {
  const [title, setTitle] = useState(row.title);
  const [description, setDescription] = useState(row.description);
  const [msg, setMsg] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  const titleLen = title.length;
  const descLen = description.length;

  return (
    <form
      className="admin-form"
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        startTransition(async () => {
          await updatePageSeo(fd);
          setMsg("SEO сохранено");
        });
      }}
    >
      <h3 style={{ margin: 0 }}>{row.path}</h3>
      <input type="hidden" name="path" value={row.path} />
      <label>
        Title
        <input name="title" value={title} onChange={(e) => setTitle(e.target.value)} required />
      </label>
      <p className={titleLen > 70 ? "admin-error" : "admin-muted"}>
        Длина Title: {titleLen} {titleLen > 70 ? "— длинновато для сниппета" : "✓"}
      </p>
      <label>
        Description
        <textarea
          name="description"
          rows={3}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
      </label>
      <p className={descLen > 180 ? "admin-error" : "admin-muted"}>
        Длина Description: {descLen} {descLen > 160 && descLen <= 180 ? "— на грани" : descLen > 180 ? "— длинно" : "✓"}
      </p>
      <div className="admin-seo-preview">
        <div className="admin-seo-preview-url">reverans.online{row.path === "/" ? "" : row.path}</div>
        <div className="admin-seo-preview-title">{title || "Title"}</div>
        <div className="admin-seo-preview-desc">{description || "Description"}</div>
      </div>
      <label>
        H1 (опционально)
        <input name="h1" defaultValue={row.h1 || ""} />
      </label>
      <label>
        OG Title
        <input name="ogTitle" defaultValue={row.ogTitle || ""} />
      </label>
      <label>
        OG Description
        <input name="ogDescription" defaultValue={row.ogDescription || ""} />
      </label>
      <label>
        OG Image URL
        <input name="ogImageUrl" defaultValue={row.ogImageUrl || ""} />
      </label>
      {msg ? <p className="admin-success">{msg}</p> : null}
      <button type="submit" disabled={pending}>
        {pending ? "…" : "Сохранить SEO"}
      </button>
    </form>
  );
}

export function SeoAdmin({ rows }: { rows: SeoRow[] }) {
  return (
    <div className="admin-seo-list">
      {rows.map((row) => (
        <SeoCard key={row.path} row={row} />
      ))}
    </div>
  );
}
