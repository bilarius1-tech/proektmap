import Link from "next/link";
import { RibbonLine } from "@/components/landing/ribbon-line";
import type { AboutData } from "@/lib/cms-defaults";

export function AboutClub({ data, enabled = true }: { data: AboutData; enabled?: boolean }) {
  if (!enabled) return null;
  return (
    <section className="section" id="about">
      <RibbonLine className="ribbon-about" />
      <div className="container">
        <div className="about-split">
          <div className="about-copy">
            <span className="section-kicker">{data.kicker}</span>
            <h2>{data.title}</h2>
            {data.paragraphs.map((p) => (
              <p key={p.slice(0, 24)}>{p}</p>
            ))}
            <p style={{ marginTop: 24 }}>
              <Link href={data.btnHref} className="btn btn-teal">
                {data.btnText}
              </Link>
            </p>
          </div>
          <div className="about-media">
            <div className="about-media-frame">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={data.imageUrl} alt={data.imageAlt} width={800} height={640} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
