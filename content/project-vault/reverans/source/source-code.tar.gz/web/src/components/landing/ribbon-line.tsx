export function RibbonLine({ className = "" }: { className?: string }) {
  return (
    <svg
      className={`ribbon-line ${className}`.trim()}
      viewBox="0 0 600 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden
    >
      <path
        d="M10 150 C120 40, 220 40, 300 90 C380 140, 460 160, 590 70"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
      />
      <path
        d="M40 170 C150 70, 250 55, 330 105 C410 155, 490 175, 580 100"
        stroke="currentColor"
        strokeWidth="1"
        strokeLinecap="round"
        opacity="0.45"
      />
    </svg>
  );
}
