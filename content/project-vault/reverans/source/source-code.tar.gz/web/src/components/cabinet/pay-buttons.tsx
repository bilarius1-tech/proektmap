"use client";

import { useState } from "react";

export function PayButtons({
  paymentId,
  trainingId,
  batchId,
  acquiring,
  label,
}: {
  paymentId?: string;
  trainingId?: string;
  batchId?: string;
  acquiring: boolean;
  label: string;
}) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function pay() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paymentId, trainingId, batchId }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Не удалось начать оплату");
        setLoading(false);
        return;
      }
      if (data.paymentUrl) {
        window.location.href = data.paymentUrl;
        return;
      }
      setError("Нет ссылки на оплату");
      setLoading(false);
    } catch {
      setError("Ошибка сети");
      setLoading(false);
    }
  }

  return (
    <div>
      {error ? <div className="cab-error">{error}</div> : null}
      <button type="button" className="cab-btn" disabled={loading || !acquiring} onClick={pay}>
        {loading ? "Переход…" : acquiring ? label : "Оплата через ТБанк скоро"}
      </button>
    </div>
  );
}
