import Link from "next/link";
import type { ProgramsData } from "@/lib/cms-defaults";

export function Programs({ data, enabled = true }: { data: ProgramsData; enabled?: boolean }) {
  if (!enabled) return null;
  return (
    <section className="section section-alt" id="programs">
      <div className="container">
        <div className="section-header">
          <h2>{data.title}</h2>
          <p>{data.subtitle}</p>
        </div>
        <div className="programs-grid">
          {data.items.map((program) => (
            <article key={program.title} className="program-card">
              <span className="program-age">{program.age}</span>
              <h3>{program.title}</h3>
              <p>{program.text}</p>
              <Link href={program.btnHref} className="btn btn-secondary">
                {program.btnText}
              </Link>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
