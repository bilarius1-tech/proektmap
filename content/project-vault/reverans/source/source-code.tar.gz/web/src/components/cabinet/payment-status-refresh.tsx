"use client";

import { useRouter } from "next/navigation";
import { useEffect } from "react";

/** After returning from T-Bank, poll until webhook marks the payment paid. */
export function PaymentStatusRefresh({ paid }: { paid: boolean }) {
  const router = useRouter();

  useEffect(() => {
    if (paid) return;
    const tick = setInterval(() => router.refresh(), 2500);
    const stop = setTimeout(() => clearInterval(tick), 25000);
    return () => {
      clearInterval(tick);
      clearTimeout(stop);
    };
  }, [paid, router]);

  return null;
}
