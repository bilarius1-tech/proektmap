/** Inline contact icons (no npm icon packs). Paths inspired by Lucide (ISC). */

export const CONTACT_ICON_OPTIONS = [
  { id: "phone", label: "Телефон" },
  { id: "telegram", label: "Telegram" },
  { id: "whatsapp", label: "WhatsApp" },
  { id: "address", label: "Адрес / пин" },
  { id: "email", label: "Email" },
  { id: "clock", label: "Часы" },
] as const;

export type ContactIconId = (typeof CONTACT_ICON_OPTIONS)[number]["id"];

export function ContactIcon({
  name,
  className,
}: {
  name: string;
  className?: string;
}) {
  const common = {
    className,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.75,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true as const,
  };

  switch (name) {
    case "telegram":
      return (
        <svg {...common}>
          <path d="M14.5 9.5 10 13l5.5 5.5L22 4 2 11.5l5 1.5L9 20l2.5-4" />
        </svg>
      );
    case "whatsapp":
      return (
        <svg {...common}>
          <path d="M3 21 4.5 16A8.5 8.5 0 1 1 8 19.5L3 21Z" />
          <path d="M8.5 10.5c.5 2 2 3.5 4 4l1.2-.6c.3-.1.6 0 .8.2l1.2 1.5c.2.3.2.6 0 .9-1.2 1.1-3.1.9-5.2-.6-2.1-1.5-3.4-3.5-3.2-5.1.1-.3.3-.5.6-.6l1.7-.4c.3 0 .5.1.6.4l.7 1.6c.1.3.1.6-.1.8l-.6.7Z" />
        </svg>
      );
    case "address":
      return (
        <svg {...common}>
          <path d="M12 22s7-5.3 7-12a7 7 0 1 0-14 0c0 6.7 7 12 7 12Z" />
          <circle cx="12" cy="10" r="2.5" />
        </svg>
      );
    case "email":
      return (
        <svg {...common}>
          <rect x="3" y="5" width="18" height="14" rx="2" />
          <path d="m3 7 9 7 9-7" />
        </svg>
      );
    case "clock":
      return (
        <svg {...common}>
          <circle cx="12" cy="12" r="9" />
          <path d="M12 7v5l3 2" />
        </svg>
      );
    case "phone":
    default:
      return (
        <svg {...common}>
          <path d="M22 16.9v2.2a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.2 3.2 2 2 0 0 1 4.2 1h2.2a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L7.3 8.7a16 16 0 0 0 6 6l1.3-1.2a2 2 0 0 1 2.1-.4c.8.3 1.7.5 2.6.6a2 2 0 0 1 1.7 2.1Z" />
        </svg>
      );
  }
}
