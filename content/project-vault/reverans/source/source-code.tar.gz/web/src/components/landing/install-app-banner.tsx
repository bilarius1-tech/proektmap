"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import type { InstallAppData } from "@/lib/cms-defaults";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

type Platform = "ios" | "android" | "other";

function AppleGlyph() {
  return (
    <svg className="store-badge-glyph" viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="currentColor"
        d="M8.5 2.5h7a2 2 0 0 1 2 2v15a2 2 0 0 1-2 2h-7a2 2 0 0 1-2-2v-15a2 2 0 0 1 2-2zm0 1.5a.5.5 0 0 0-.5.5v15c0 .3.2.5.5.5h7c.3 0 .5-.2.5-.5v-15a.5.5 0 0 0-.5-.5h-7zm2.2 1h2.6a.5.5 0 0 1 0 1h-2.6a.5.5 0 0 1 0-1zm1.3 14.2a.9.9 0 1 1 0 1.8.9.9 0 0 1 0-1.8z"
      />
    </svg>
  );
}

function AndroidGlyph() {
  return (
    <svg className="store-badge-glyph" viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill="currentColor"
        d="M17.6 9.5 19.2 6.7a.5.5 0 0 0-.9-.5l-1.6 2.7A9.4 9.4 0 0 0 12 8.1c-1.7 0-3.3.5-4.7 1.3L5.7 6.7a.5.5 0 1 0-.9.5l1.6 2.8A8.6 8.6 0 0 0 3.5 15v.8c0 .9.7 1.6 1.6 1.6h1.1V15c0-.7.5-1.2 1.2-1.2s1.2.5 1.2 1.2v2.4h5.8V15c0-.7.5-1.2 1.2-1.2s1.2.5 1.2 1.2v2.4h1.1c.9 0 1.6-.7 1.6-1.6V15a8.6 8.6 0 0 0-2.9-5.5zM9.2 13.1a.8.8 0 1 1 0-1.6.8.8 0 0 1 0 1.6zm5.6 0a.8.8 0 1 1 0-1.6.8.8 0 0 1 0 1.6z"
      />
    </svg>
  );
}

export function InstallAppBanner({
  data,
  enabled = true,
}: {
  data: InstallAppData;
  enabled?: boolean;
}) {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [platform, setPlatform] = useState<Platform>("other");
  const [focus, setFocus] = useState<Platform | null>(null);

  useEffect(() => {
    const ua = navigator.userAgent || "";
    const isIOS =
      /iPad|iPhone|iPod/.test(ua) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    const isAndroid = /Android/i.test(ua);
    const detected: Platform = isIOS ? "ios" : isAndroid ? "android" : "other";
    setPlatform(detected);
    setFocus(detected === "other" ? null : detected);

    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      ("standalone" in navigator && Boolean((navigator as { standalone?: boolean }).standalone));
    if (standalone) setInstalled(true);

    function onBeforeInstall(e: Event) {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    }
    function onInstalled() {
      setInstalled(true);
    }
    window.addEventListener("beforeinstallprompt", onBeforeInstall);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstall);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  async function installAndroid() {
    setFocus("android");
    if (!deferred) return;
    await deferred.prompt();
    await deferred.userChoice;
    setDeferred(null);
  }

  if (!enabled) return null;

  const active = focus || platform;
  const imageSrc = data.imageUrl || "/brand/pwa/promo.webp";

  if (installed) {
    return (
      <section className="install-app" aria-label="Приложение на телефоне">
        <div className="container">
          <p className="install-app-done">
            {data.badgeTitle || "Реверанс"} уже на экране телефона — открывайте как обычное приложение.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section className="install-app" id="install-app" aria-label="Добавить на экран телефона">
      <div className="container install-app-inner">
        <div className="install-app-media">
          <Image
            src={imageSrc}
            alt={data.imageAlt || data.title}
            width={960}
            height={720}
            className="install-app-photo"
            sizes="(max-width: 768px) 100vw, 420px"
            unoptimized={imageSrc.startsWith("/uploads/")}
          />
          <div className="install-app-badge">
            <Image src="/brand/pwa/icon-192.png" alt="" width={56} height={56} />
            <span>
              {data.badgeTitle}
              <small>{data.badgeSubtitle}</small>
            </span>
          </div>
        </div>

        <div className="install-app-copy">
          <p className="install-app-eyebrow">{data.eyebrow}</p>
          <h2 className="install-app-title">{data.title}</h2>
          <p className="install-app-lead">{data.lead}</p>

          <div className="store-badges" role="group" aria-label="Добавить на телефон">
            <button
              type="button"
              className={`store-badge store-badge-outline${active === "ios" ? " is-active" : ""}`}
              onClick={() => setFocus("ios")}
            >
              <AppleGlyph />
              <span className="store-badge-text">
                <span className="store-badge-top">{data.iosTop}</span>
                <span className="store-badge-name">{data.iosName}</span>
              </span>
            </button>

            <button
              type="button"
              className={`store-badge store-badge-solid${active === "android" ? " is-active" : ""}`}
              onClick={() => void installAndroid()}
            >
              <AndroidGlyph />
              <span className="store-badge-text">
                <span className="store-badge-top">{data.androidTop}</span>
                <span className="store-badge-name">{data.androidName}</span>
              </span>
            </button>
          </div>

          <ol className="install-app-steps">
            {active === "ios" ? (
              <>
                <li>
                  Откройте сайт в <strong>Safari</strong>
                </li>
                <li>
                  Нажмите <strong>«Поделиться»</strong> (квадрат со стрелкой внизу)
                </li>
                <li>
                  Выберите <strong>«На экран „Домой“»</strong> → Добавить
                </li>
              </>
            ) : active === "android" ? (
              <>
                <li>
                  Откройте сайт в <strong>Chrome</strong>
                </li>
                <li>
                  Меню <strong>⋮</strong> → <strong>«Установить приложение»</strong> или «На главный экран»
                </li>
                <li>Подтвердите — появится иконка с логотипом «Реверанс»</li>
              </>
            ) : (
              <>
                <li>
                  Нажмите кнопку <strong>{data.iosName}</strong> или <strong>{data.androidName}</strong>{" "}
                  выше
                </li>
                <li>Следуйте короткой инструкции для вашего телефона</li>
                <li>Иконка — логотип клуба, установка из магазина не нужна</li>
              </>
            )}
          </ol>
        </div>
      </div>
    </section>
  );
}
