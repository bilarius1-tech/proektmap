"use client";

import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import LinkExt from "@tiptap/extension-link";
import { useEffect, useState, useTransition } from "react";
import { updateSection } from "@/app/admin/site/actions";
import type { CookieBannerData } from "@/lib/cms-defaults";

export function LegalDocEditor({
  sectionKey,
  label,
  initialTitle,
  initialUpdatedAt,
  initialHtml,
}: {
  sectionKey: string;
  label: string;
  initialTitle: string;
  initialUpdatedAt: string;
  initialHtml: string;
}) {
  const [title, setTitle] = useState(initialTitle);
  const [updatedAt, setUpdatedAt] = useState(initialUpdatedAt);
  const [html, setHtml] = useState(initialHtml);
  const [msg, setMsg] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: { levels: [3, 4] },
        codeBlock: false,
        code: false,
        link: false,
      }),
      LinkExt.configure({ openOnClick: false }),
    ],
    content: initialHtml,
    immediatelyRender: false,
    onUpdate: ({ editor: ed }) => setHtml(ed.getHTML()),
    editorProps: {
      attributes: { class: "admin-tiptap-editor admin-tiptap-legal" },
    },
  });

  useEffect(() => {
    if (!editor || editor.isFocused) return;
    if (html !== editor.getHTML()) {
      // keep external sync minimal
    }
  }, [html, editor]);

  return (
    <form
      className="admin-form"
      style={{ maxWidth: 800 }}
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData();
        fd.set("key", sectionKey);
        fd.set("enabled", "true");
        fd.set(
          "dataJson",
          JSON.stringify({
            title,
            updatedAt,
            bodyHtml: editor?.getHTML() || html,
          }),
        );
        startTransition(async () => {
          await updateSection(fd);
          setMsg("Сохранено на сайте");
        });
      }}
    >
      <h2 style={{ margin: 0 }}>{label}</h2>
      <label>
        Заголовок
        <input value={title} onChange={(e) => setTitle(e.target.value)} required />
      </label>
      <label>
        Дата редакции
        <input value={updatedAt} onChange={(e) => setUpdatedAt(e.target.value)} />
      </label>
      <div className="admin-field">
        <span>Текст документа</span>
        <div className="admin-tiptap">
          <div className="admin-tiptap-toolbar">
            <button type="button" onClick={() => editor?.chain().focus().toggleBold().run()}>
              Ж
            </button>
            <button type="button" onClick={() => editor?.chain().focus().toggleItalic().run()}>
              К
            </button>
            <button type="button" onClick={() => editor?.chain().focus().toggleHeading({ level: 3 }).run()}>
              H3
            </button>
            <button type="button" onClick={() => editor?.chain().focus().toggleBulletList().run()}>
              Список
            </button>
          </div>
          <EditorContent editor={editor} />
        </div>
      </div>
      {msg ? <p className="admin-success">{msg}</p> : null}
      <button type="submit" disabled={pending}>
        {pending ? "…" : "Сохранить"}
      </button>
    </form>
  );
}

export function CookieBannerEditor({
  initial,
}: {
  initial: CookieBannerData & { enabled?: boolean };
}) {
  const [data, setData] = useState(initial);
  const [msg, setMsg] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  return (
    <form
      className="admin-form"
      style={{ maxWidth: 720 }}
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData();
        fd.set("key", "legal.cookieBanner");
        fd.set("enabled", "true");
        fd.set("dataJson", JSON.stringify(data));
        startTransition(async () => {
          await updateSection(fd);
          setMsg("Баннер сохранён");
        });
      }}
    >
      <h2 style={{ margin: 0 }}>Текст баннера cookie</h2>
      <label>
        Текст
        <textarea
          rows={4}
          value={data.text}
          onChange={(e) => setData({ ...data, text: e.target.value })}
        />
      </label>
      <label>
        Кнопка «Принять»
        <input
          value={data.acceptLabel}
          onChange={(e) => setData({ ...data, acceptLabel: e.target.value })}
        />
      </label>
      <label>
        Кнопка «Отклонить»
        <input
          value={data.declineLabel}
          onChange={(e) => setData({ ...data, declineLabel: e.target.value })}
        />
      </label>
      <label>
        Подпись ссылки на Политику
        <input
          value={data.privacyLinkLabel}
          onChange={(e) => setData({ ...data, privacyLinkLabel: e.target.value })}
        />
      </label>
      <label>
        URL Политики
        <input
          value={data.privacyPath}
          onChange={(e) => setData({ ...data, privacyPath: e.target.value })}
        />
      </label>
      <label>
        Подпись ссылки на Согласие
        <input
          value={data.consentLinkLabel}
          onChange={(e) => setData({ ...data, consentLinkLabel: e.target.value })}
        />
      </label>
      <label>
        URL Согласия
        <input
          value={data.consentPath}
          onChange={(e) => setData({ ...data, consentPath: e.target.value })}
        />
      </label>
      {msg ? <p className="admin-success">{msg}</p> : null}
      <button type="submit" disabled={pending}>
        {pending ? "…" : "Сохранить баннер"}
      </button>
    </form>
  );
}
