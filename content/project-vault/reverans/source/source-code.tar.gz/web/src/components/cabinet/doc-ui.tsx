import type { DocumentStatus, DocumentType } from "@prisma/client";
import {
  IconCircleCheck,
  IconClock,
  IconFilePen,
  IconHeartPulse,
  IconShieldCheck,
  IconUpload,
} from "@/components/icons/doc-icons";
import {
  DOC_HINTS,
  DOC_LABELS,
  documentStatusLabel,
  documentStatusTone,
  type DocTone,
} from "@/lib/documents";

const TONE_CLASS: Record<DocTone, string> = {
  ok: "cab-badge-ok",
  wait: "cab-badge-wait",
  need: "cab-badge-need",
  review: "cab-badge-review",
  expired: "cab-badge-bad",
};

export function DocTypeIcon({ type, className }: { type: DocumentType; className?: string }) {
  switch (type) {
    case "contract":
      return <IconFilePen className={className} />;
    case "consent":
      return <IconShieldCheck className={className} />;
    case "medical_clearance":
      return <IconHeartPulse className={className} />;
    default:
      return <IconFilePen className={className} />;
  }
}

function StatusIcon({ tone, className }: { tone: DocTone; className?: string }) {
  if (tone === "ok") return <IconCircleCheck className={className} />;
  if (tone === "need") return <IconUpload className={className} />;
  return <IconClock className={className} />;
}

export function DocStatusBadge({
  type,
  status,
  hasFile,
}: {
  type: DocumentType;
  status: DocumentStatus;
  hasFile?: boolean;
}) {
  const tone = documentStatusTone(type, status, hasFile);
  return (
    <span className={`cab-badge cab-badge-icon ${TONE_CLASS[tone]}`}>
      <StatusIcon tone={tone} className="cab-badge-svg" />
      {documentStatusLabel(type, status, hasFile)}
    </span>
  );
}

export function DocTypeChip({ type }: { type: DocumentType }) {
  return (
    <span className={`cab-doc-chip cab-doc-chip-${type}`}>
      <DocTypeIcon type={type} className="cab-doc-chip-svg" />
      {DOC_LABELS[type]}
    </span>
  );
}

export function docCardClass(type: DocumentType) {
  return `cab-doc-card cab-doc-card-${type}`;
}

export function DocCardHeader({
  type,
  status,
  hasFile,
}: {
  type: DocumentType;
  status: DocumentStatus;
  hasFile?: boolean;
}) {
  return (
    <div className="cab-doc-card-head">
      <div className={`cab-doc-icon cab-doc-icon-${type}`}>
        <DocTypeIcon type={type} className="cab-doc-icon-svg" />
      </div>
      <div className="cab-doc-card-titles">
        <h2>{DOC_LABELS[type]}</h2>
        <p>{DOC_HINTS[type]}</p>
      </div>
      <DocStatusBadge type={type} status={status} hasFile={hasFile} />
    </div>
  );
}
