"use client";

import { useState } from "react";

export function MedicalPreview({
  documentId,
  fileName,
  hasThumb,
  isPdf,
}: {
  documentId: string;
  fileName: string | null;
  hasThumb: boolean;
  isPdf: boolean;
}) {
  const [open, setOpen] = useState(false);
  const fileUrl = `/api/documents/${documentId}/file`;
  const thumbUrl = `/api/documents/${documentId}/file?thumb=1`;

  return (
    <>
      <button type="button" className="admin-scan-thumb" onClick={() => setOpen(true)}>
        {hasThumb && !isPdf ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={thumbUrl} alt={fileName || "Скан"} />
        ) : (
          <span className="admin-scan-pdf">{isPdf ? "PDF" : "Скан"}</span>
        )}
        <span>Открыть</span>
      </button>

      {open ? (
        <div className="admin-lightbox" role="dialog" aria-modal="true" onClick={() => setOpen(false)}>
          <div className="admin-lightbox-panel" onClick={(e) => e.stopPropagation()}>
            <div className="admin-lightbox-bar">
              <strong>{fileName || "Медсправка"}</strong>
              <button type="button" className="admin-btn admin-btn-ghost" onClick={() => setOpen(false)}>
                Закрыть
              </button>
            </div>
            {isPdf ? (
              <iframe title="PDF" src={fileUrl} className="admin-lightbox-frame" />
            ) : (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={fileUrl} alt={fileName || "Скан"} className="admin-lightbox-img" />
            )}
            <p className="admin-muted" style={{ marginTop: 8 }}>
              <a href={fileUrl} target="_blank" rel="noopener noreferrer">
                Открыть в новой вкладке
              </a>
            </p>
          </div>
        </div>
      ) : null}
    </>
  );
}
