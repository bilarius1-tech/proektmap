import Link from "next/link";
import { PriceGroups } from "@/components/landing/price-groups";
import type { PagePricesData, PricingData } from "@/lib/cms-defaults";

export function Pricing({
  data,
  groups,
  enabled = true,
}: {
  data: PricingData;
  groups?: PagePricesData["groups"];
  enabled?: boolean;
}) {
  if (!enabled) return null;

  return (
    <section className="section section-alt" id="prices">
      <div className="container">
        <div className="section-header">
          <h2>{data.title}</h2>
          {data.subtitle ? <p>{data.subtitle}</p> : null}
        </div>
        {groups?.length ? <PriceGroups groups={groups} compact /> : null}
        <p style={{ marginTop: 28, textAlign: "center" }}>
          <Link href={data.btnHref || "/prices"} className="btn btn-secondary">
            {data.btnText || "Все тарифы"}
          </Link>
        </p>
      </div>
    </section>
  );
}
