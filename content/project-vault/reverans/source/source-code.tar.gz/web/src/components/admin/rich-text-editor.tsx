"use client";

import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Link from "@tiptap/extension-link";
import { useEffect } from "react";

export function RichTextEditor({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (html: string) => void;
  placeholder?: string;
}) {
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        heading: false,
        codeBlock: false,
        code: false,
        blockquote: false,
        horizontalRule: false,
        // StarterKit 3.x already ships Link — disable to avoid duplicate name warning
        link: false,
      }),
      Link.configure({ openOnClick: false, HTMLAttributes: { rel: "noopener noreferrer" } }),
    ],
    content: value || "",
    immediatelyRender: false,
    onUpdate: ({ editor: ed }) => onChange(ed.getHTML()),
    editorProps: {
      attributes: {
        class: "admin-tiptap-editor",
        "data-placeholder": placeholder || "",
      },
    },
  });

  useEffect(() => {
    if (!editor) return;
    const current = editor.getHTML();
    if (value !== current && value !== editor.getText()) {
      // only sync external reset
      if (!editor.isFocused) {
        editor.commands.setContent(value || "", { emitUpdate: false });
      }
    }
  }, [value, editor]);

  if (!editor) return null;

  return (
    <div className="admin-tiptap">
      <div className="admin-tiptap-toolbar">
        <button type="button" onClick={() => editor.chain().focus().toggleBold().run()}>
          Ж
        </button>
        <button type="button" onClick={() => editor.chain().focus().toggleItalic().run()}>
          К
        </button>
        <button type="button" onClick={() => editor.chain().focus().toggleBulletList().run()}>
          Список
        </button>
        <button
          type="button"
          onClick={() => {
            const url = window.prompt("Ссылка");
            if (!url) return;
            editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
          }}
        >
          Ссылка
        </button>
      </div>
      <EditorContent editor={editor} />
    </div>
  );
}
