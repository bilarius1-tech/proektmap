"use client";

import { useState, useTransition } from "react";
import { updateSiteSettings } from "@/app/admin/site/actions";
import type { SiteSettingsView } from "@/lib/cms-defaults";

export function SiteSettingsForm({ initial }: { initial: SiteSettingsView }) {
  const [msg, setMsg] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  return (
    <form
      className="admin-form"
      style={{ maxWidth: 640 }}
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        startTransition(async () => {
          await updateSiteSettings(fd);
          setMsg("Настройки сохранены");
        });
      }}
    >
      <h2 style={{ margin: 0 }}>Бренд и контакты</h2>
      <p className="admin-muted">Телефон и соцсети подставляются в header, footer и контакты.</p>

      <label>
        Название бренда
        <input name="brandName" defaultValue={initial.brandName} required />
      </label>
      <label>
        Название (рус.)
        <input name="brandNameRu" defaultValue={initial.brandNameRu} required />
      </label>
      <label>
        Подзаголовок
        <input name="tagline" defaultValue={initial.tagline} />
      </label>
      <label>
        Город
        <input name="city" defaultValue={initial.city} />
      </label>
      <label>
        Адрес
        <input name="address" defaultValue={initial.address} />
      </label>
      <label>
        Телефон (отображение)
        <input name="phoneDisplay" defaultValue={initial.phoneDisplay} />
      </label>
      <label>
        Телефон (ссылка tel:)
        <input name="phoneHref" defaultValue={initial.phoneHref} />
      </label>
      <label>
        Email
        <input name="email" defaultValue={initial.email || ""} />
      </label>
      <label>
        Telegram (@)
        <input name="telegram" defaultValue={initial.telegram || ""} />
      </label>
      <label>
        Telegram URL
        <input name="telegramHref" defaultValue={initial.telegramHref || ""} />
      </label>
      <label>
        WhatsApp URL
        <input name="whatsappHref" defaultValue={initial.whatsappHref || ""} />
      </label>
      <label>
        Instagram URL
        <input name="instagramHref" defaultValue={initial.instagramHref || ""} />
      </label>
      <label>
        VK URL
        <input name="vkHref" defaultValue={initial.vkHref || ""} />
      </label>
      <label>
        YouTube URL
        <input name="youtubeHref" defaultValue={initial.youtubeHref || ""} />
      </label>
      <label>
        URL логотипа
        <input name="logoUrl" defaultValue={initial.logoUrl || ""} />
      </label>
      <label>
        Текст в footer
        <textarea name="footerAbout" rows={3} defaultValue={initial.footerAbout || ""} />
      </label>
      <label>
        Copyright (пусто = авто)
        <input name="copyrightText" defaultValue={initial.copyrightText || ""} />
      </label>

      <h2>Аналитика и Вебмастер</h2>
      <p className="admin-muted">
        Яндекс.Метрика подключается на сайте только после нажатия «Принять» в cookie-баннере.
      </p>
      <label>
        Яндекс Метрика — номер счётчика
        <input name="yandexMetrikaId" defaultValue={initial.yandexMetrikaId || ""} />
      </label>
      <label className="admin-check">
        <input type="hidden" name="yandexMetrikaOn" value="false" />
        <input type="checkbox" name="yandexMetrikaOn" value="true" defaultChecked={initial.yandexMetrikaOn} />
        Включить Метрику
      </label>
      <label className="admin-check">
        <input type="hidden" name="yandexWebvisor" value="false" />
        <input type="checkbox" name="yandexWebvisor" value="true" defaultChecked={initial.yandexWebvisor} />
        Вебвизор
      </label>
      <label>
        Яндекс Вебмастер — verification content
        <input
          name="yandexVerification"
          defaultValue={initial.yandexVerification || ""}
          placeholder="только значение content=…"
        />
      </label>
      <label>
        Google Analytics ID (G-…)
        <input name="googleAnalyticsId" defaultValue={initial.googleAnalyticsId || ""} />
      </label>

      {msg ? <p className="admin-success">{msg}</p> : null}
      <button type="submit" disabled={pending}>
        {pending ? "…" : "Сохранить"}
      </button>
    </form>
  );
}
