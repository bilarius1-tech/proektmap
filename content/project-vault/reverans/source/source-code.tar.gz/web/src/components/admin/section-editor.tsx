"use client";

import { useMemo, useState, useTransition } from "react";
import { updateSection } from "@/app/admin/site/actions";
import { RichTextEditor } from "@/components/admin/rich-text-editor";
import { CONTACT_ICON_OPTIONS } from "@/components/icons/contact-icons";

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="admin-field">
      <span>{label}</span>
      {children}
    </label>
  );
}

export function SectionEditor({
  sectionKey,
  label,
  initialEnabled,
  initialData,
}: {
  sectionKey: string;
  label: string;
  initialEnabled: boolean;
  initialData: Record<string, unknown>;
}) {
  const [enabled, setEnabled] = useState(initialEnabled);
  const [data, setData] = useState(initialData);
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  const set = (key: string, value: unknown) => setData((d) => ({ ...d, [key]: value }));

  const items = useMemo(() => {
    if (Array.isArray(data.groups)) return null;
    if (Array.isArray(data.items)) return data.items as Record<string, string>[];
    if (Array.isArray(data.cards)) return data.cards as Record<string, string>[];
    return null;
  }, [data]);

  const groups = Array.isArray(data.groups)
    ? (data.groups as {
        name: string;
        discipline: string;
        ctaText: string;
        ctaHref: string;
        plans: { schedule: string; price: string }[];
      }[])
    : null;

  const paragraphs = Array.isArray(data.paragraphs) ? (data.paragraphs as string[]) : null;
  const bullets = Array.isArray(data.bullets) ? (data.bullets as string[]) : null;

  return (
    <form
      className="admin-form"
      style={{ maxWidth: 720 }}
      onSubmit={(e) => {
        e.preventDefault();
        setMsg(null);
        setErr(null);
        const fd = new FormData();
        fd.set("key", sectionKey);
        fd.set("enabled", enabled ? "true" : "false");
        fd.set("dataJson", JSON.stringify(data));
        startTransition(async () => {
          try {
            await updateSection(fd);
            setMsg("Сохранено — изменения на сайте");
          } catch (error) {
            setErr(error instanceof Error ? error.message : "Ошибка сохранения");
          }
        });
      }}
    >
      <h2 style={{ margin: 0 }}>{label}</h2>
      <label className="admin-check">
        <input type="checkbox" checked={enabled} onChange={(e) => setEnabled(e.target.checked)} />
        Показывать блок на сайте
      </label>

      {"eyebrow" in data ? (
        <Field label="Eyebrow">
          <input value={String(data.eyebrow || "")} onChange={(e) => set("eyebrow", e.target.value)} />
        </Field>
      ) : null}
      {"kicker" in data ? (
        <Field label="Надзаголовок">
          <input value={String(data.kicker || "")} onChange={(e) => set("kicker", e.target.value)} />
        </Field>
      ) : null}
      {"title" in data ? (
        <Field label="Заголовок (Enter = новая строка)">
          <textarea
            rows={3}
            value={String(data.title || "")}
            onChange={(e) => set("title", e.target.value)}
          />
        </Field>
      ) : null}
      {"heading" in data ? (
        <Field label="Подзаголовок блока">
          <input value={String(data.heading || "")} onChange={(e) => set("heading", e.target.value)} />
        </Field>
      ) : null}
      {"brand" in data ? (
        <Field label="Бренд (script)">
          <input value={String(data.brand || "")} onChange={(e) => set("brand", e.target.value)} />
        </Field>
      ) : null}
      {"subtitle" in data ? (
        <Field label="Подзаголовок">
          <textarea
            rows={2}
            value={String(data.subtitle || "")}
            onChange={(e) => set("subtitle", e.target.value)}
          />
        </Field>
      ) : null}
      {"lead" in data ? (
        <Field label="Лид / описание">
          <RichTextEditor
            value={`<p>${String(data.lead || "").replace(/\n/g, "</p><p>")}</p>`}
            onChange={(html) => {
              const text = html
                .replace(/<\/p>/gi, "\n")
                .replace(/<br\s*\/?>/gi, "\n")
                .replace(/<[^>]+>/g, "")
                .replace(/&nbsp;/g, " ")
                .trim();
              set("lead", text);
            }}
          />
        </Field>
      ) : null}
      {"note" in data ? (
        <Field label="Заметка">
          <input value={String(data.note || "")} onChange={(e) => set("note", e.target.value)} />
        </Field>
      ) : null}
      {"noteMuted" in data ? (
        <Field label="Подпись">
          <input
            value={String(data.noteMuted || "")}
            onChange={(e) => set("noteMuted", e.target.value)}
          />
        </Field>
      ) : null}

      {paragraphs ? (
        <Field label="Абзацы (каждый с новой строки)">
          <textarea
            rows={5}
            value={paragraphs.join("\n\n")}
            onChange={(e) =>
              set(
                "paragraphs",
                e.target.value
                  .split(/\n\s*\n/)
                  .map((s) => s.trim())
                  .filter(Boolean),
              )
            }
          />
        </Field>
      ) : null}

      {bullets ? (
        <Field label="Пункты списка (по строке)">
          <textarea
            rows={4}
            value={bullets.join("\n")}
            onChange={(e) =>
              set(
                "bullets",
                e.target.value
                  .split("\n")
                  .map((s) => s.trim())
                  .filter(Boolean),
              )
            }
          />
        </Field>
      ) : null}

      {"btn1Text" in data ? (
        <>
          <Field label="Кнопка 1 — текст">
            <input
              value={String(data.btn1Text || "")}
              onChange={(e) => set("btn1Text", e.target.value)}
            />
          </Field>
          <Field label="Кнопка 1 — ссылка">
            <input
              value={String(data.btn1Href || "")}
              onChange={(e) => set("btn1Href", e.target.value)}
            />
          </Field>
          <Field label="Кнопка 2 — текст">
            <input
              value={String(data.btn2Text || "")}
              onChange={(e) => set("btn2Text", e.target.value)}
            />
          </Field>
          <Field label="Кнопка 2 — ссылка">
            <input
              value={String(data.btn2Href || "")}
              onChange={(e) => set("btn2Href", e.target.value)}
            />
          </Field>
        </>
      ) : null}

      {"btnText" in data ? (
        <>
          <Field label="Кнопка — текст">
            <input value={String(data.btnText || "")} onChange={(e) => set("btnText", e.target.value)} />
          </Field>
          <Field label="Кнопка — ссылка">
            <input value={String(data.btnHref || "")} onChange={(e) => set("btnHref", e.target.value)} />
          </Field>
        </>
      ) : null}

      {"linkText" in data ? (
        <>
          <Field label="Доп. ссылка — текст">
            <input
              value={String(data.linkText || "")}
              onChange={(e) => set("linkText", e.target.value)}
            />
          </Field>
          <Field label="Доп. ссылка — URL">
            <input
              value={String(data.linkHref || "")}
              onChange={(e) => set("linkHref", e.target.value)}
            />
          </Field>
        </>
      ) : null}

      {"imageUrl" in data && sectionKey !== "page.prices" ? (
        <>
          <div className="admin-image-slot">
            <span className="admin-field-label">Изображение блока</span>
            {data.imageUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={String(data.imageUrl)}
                alt={String(data.imageAlt || "")}
                className="admin-image-preview"
              />
            ) : (
              <div className="admin-image-empty">Нет фото</div>
            )}
            <label className="admin-upload-drop" style={{ minHeight: 64 }}>
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp,image/gif"
                disabled={pending}
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  e.target.value = "";
                  if (!file) return;
                  setMsg(null);
                  setErr(null);
                  try {
                    const fd = new FormData();
                    fd.set("file", file);
                    fd.set("preserveAlpha", "true");
                    fd.set("alt", String(data.imageAlt || file.name));
                    const res = await fetch("/api/admin/upload", { method: "POST", body: fd });
                    const json = await res.json();
                    if (!res.ok) throw new Error(json.error || "Ошибка загрузки");
                    set("imageUrl", json.media.url);
                    if (!data.imageAlt) set("imageAlt", file.name.replace(/\.[^.]+$/, ""));
                    setMsg("✓ Фото загружено — нажмите «Сохранить на сайт»");
                  } catch (error) {
                    setErr(error instanceof Error ? error.message : "Ошибка загрузки");
                  }
                }}
              />
              <span>Загрузить PNG / JPG (прозрачность PNG сохранится)</span>
            </label>
            <Field label="URL изображения">
              <input
                value={String(data.imageUrl || "")}
                onChange={(e) => set("imageUrl", e.target.value)}
              />
            </Field>
            <Field label="ALT изображения">
              <input
                value={String(data.imageAlt || "")}
                onChange={(e) => set("imageAlt", e.target.value)}
              />
            </Field>
          </div>
        </>
      ) : null}

      {"limit" in data ? (
        <Field label="Сколько фото на главной">
          <input
            type="number"
            min={1}
            max={24}
            value={Number(data.limit || 6)}
            onChange={(e) => set("limit", Number(e.target.value) || 6)}
          />
        </Field>
      ) : null}

      {"showPhone" in data ? (
        <label className="admin-check">
          <input
            type="checkbox"
            checked={Boolean(data.showPhone)}
            onChange={(e) => set("showPhone", e.target.checked)}
          />
          Показывать телефон
        </label>
      ) : null}

      {"showRibbon" in data ? (
        <label className="admin-check">
          <input
            type="checkbox"
            checked={Boolean(data.showRibbon)}
            onChange={(e) => set("showRibbon", e.target.checked)}
          />
          Декоративная лента
        </label>
      ) : null}

      {"badgeTitle" in data ? (
        <>
          <Field label="Бейдж на фото — название">
            <input
              value={String(data.badgeTitle || "")}
              onChange={(e) => set("badgeTitle", e.target.value)}
            />
          </Field>
          <Field label="Бейдж на фото — подпись">
            <input
              value={String(data.badgeSubtitle || "")}
              onChange={(e) => set("badgeSubtitle", e.target.value)}
            />
          </Field>
          <Field label="Кнопка iPhone — верхняя строка">
            <input value={String(data.iosTop || "")} onChange={(e) => set("iosTop", e.target.value)} />
          </Field>
          <Field label="Кнопка iPhone — название">
            <input value={String(data.iosName || "")} onChange={(e) => set("iosName", e.target.value)} />
          </Field>
          <Field label="Кнопка Android — верхняя строка">
            <input
              value={String(data.androidTop || "")}
              onChange={(e) => set("androidTop", e.target.value)}
            />
          </Field>
          <Field label="Кнопка Android — название">
            <input
              value={String(data.androidName || "")}
              onChange={(e) => set("androidName", e.target.value)}
            />
          </Field>
        </>
      ) : null}

      {groups ? (
        <div className="admin-items">
          <h3>Группы и тарифы</h3>
          <p className="admin-muted" style={{ marginTop: 0 }}>
            Эти плашки показываются на странице «Цены» и на главной. Картинку загружать не нужно.
          </p>
          {groups.map((group, gi) => (
            <div key={gi} className="admin-item-card">
              <Field label="Название группы">
                <input
                  value={group.name || ""}
                  onChange={(e) => {
                    const next = groups.map((g, i) =>
                      i === gi ? { ...g, name: e.target.value } : g,
                    );
                    set("groups", next);
                  }}
                />
              </Field>
              <Field label="Подзаголовок (дисциплина)">
                <input
                  value={group.discipline || ""}
                  onChange={(e) => {
                    const next = groups.map((g, i) =>
                      i === gi ? { ...g, discipline: e.target.value } : g,
                    );
                    set("groups", next);
                  }}
                />
              </Field>
              <Field label="Текст кнопки">
                <input
                  value={group.ctaText || ""}
                  onChange={(e) => {
                    const next = groups.map((g, i) =>
                      i === gi ? { ...g, ctaText: e.target.value } : g,
                    );
                    set("groups", next);
                  }}
                />
              </Field>
              <Field label="Ссылка кнопки">
                <input
                  value={group.ctaHref || ""}
                  onChange={(e) => {
                    const next = groups.map((g, i) =>
                      i === gi ? { ...g, ctaHref: e.target.value } : g,
                    );
                    set("groups", next);
                  }}
                />
              </Field>
              <div className="admin-muted" style={{ fontWeight: 700, marginBottom: 6 }}>
                Тарифы
              </div>
              {(group.plans || []).map((plan, pi) => (
                <div
                  key={pi}
                  style={{
                    display: "grid",
                    gap: 8,
                    marginBottom: 10,
                    padding: 10,
                    border: "1px solid #e0d8cf",
                    borderRadius: 10,
                    background: "#fff",
                  }}
                >
                  <Field label={`Расписание ${pi + 1}`}>
                    <input
                      value={plan.schedule || ""}
                      onChange={(e) => {
                        const plans = (group.plans || []).map((p, j) =>
                          j === pi ? { ...p, schedule: e.target.value } : p,
                        );
                        const next = groups.map((g, i) => (i === gi ? { ...g, plans } : g));
                        set("groups", next);
                      }}
                    />
                  </Field>
                  <Field label="Цена">
                    <input
                      value={plan.price || ""}
                      onChange={(e) => {
                        const plans = (group.plans || []).map((p, j) =>
                          j === pi ? { ...p, price: e.target.value } : p,
                        );
                        const next = groups.map((g, i) => (i === gi ? { ...g, plans } : g));
                        set("groups", next);
                      }}
                    />
                  </Field>
                  <button
                    type="button"
                    className="admin-btn admin-btn-ghost"
                    onClick={() => {
                      const plans = (group.plans || []).filter((_, j) => j !== pi);
                      const next = groups.map((g, i) => (i === gi ? { ...g, plans } : g));
                      set("groups", next);
                    }}
                  >
                    Удалить тариф
                  </button>
                </div>
              ))}
              <button
                type="button"
                className="admin-btn admin-btn-ghost"
                onClick={() => {
                  const plans = [
                    ...(group.plans || []),
                    { schedule: "2 раза в неделю", price: "0 ₽/месяц" },
                  ];
                  const next = groups.map((g, i) => (i === gi ? { ...g, plans } : g));
                  set("groups", next);
                }}
              >
                + Тариф в группу
              </button>
            </div>
          ))}
          <button
            type="button"
            className="admin-btn admin-btn-ghost"
            onClick={() => {
              set("groups", [
                ...groups,
                {
                  name: "Новая группа",
                  discipline: "Художественная гимнастика",
                  plans: [{ schedule: "2 раза в неделю", price: "0 ₽/месяц" }],
                  ctaText: "Запишитесь на пробное занятие!",
                  ctaHref: "/contacts",
                },
              ]);
            }}
          >
            + Группа
          </button>
        </div>
      ) : null}

      {items ? (
        <div className="admin-items">
          <h3>Карточки / пункты</h3>
          {items.map((item, idx) => (
            <div key={idx} className="admin-item-card">
              {Object.keys(item).map((k) => {
                const labelMap: Record<string, string> = {
                  label: "Название",
                  icon: "Иконка",
                  source: "Данные из настроек сайта",
                  enabled: "Показывать",
                  num: "Номер",
                  title: "Заголовок",
                  text: "Текст",
                  age: "Возраст",
                  btnText: "Кнопка",
                  btnHref: "Ссылка кнопки",
                  linkText: "Ссылка — текст",
                  linkHref: "Ссылка — URL",
                };
                const updateItem = (value: unknown) => {
                  const next = items.map((it, i) => (i === idx ? { ...it, [k]: value } : it));
                  if (Array.isArray(data.items)) set("items", next);
                  else set("cards", next);
                };

                if (k === "icon") {
                  return (
                    <Field key={k} label={labelMap[k] || k}>
                      <select value={String(item[k] || "phone")} onChange={(e) => updateItem(e.target.value)}>
                        {CONTACT_ICON_OPTIONS.map((opt) => (
                          <option key={opt.id} value={opt.id}>
                            {opt.label}
                          </option>
                        ))}
                      </select>
                    </Field>
                  );
                }
                if (k === "source") {
                  return (
                    <Field key={k} label={labelMap[k] || k}>
                      <select value={String(item[k] || "phone")} onChange={(e) => updateItem(e.target.value)}>
                        <option value="phone">Телефон (из настроек)</option>
                        <option value="telegram">Telegram (из настроек)</option>
                        <option value="whatsapp">WhatsApp (из настроек)</option>
                        <option value="address">Адрес (из настроек)</option>
                        <option value="email">Email (из настроек)</option>
                      </select>
                    </Field>
                  );
                }
                if (k === "enabled") {
                  const on = String(item[k] ?? "true") !== "false";
                  return (
                    <label key={k} className="admin-check">
                      <input
                        type="checkbox"
                        checked={on}
                        onChange={(e) => updateItem(e.target.checked)}
                      />
                      {labelMap[k] || k}
                    </label>
                  );
                }
                return (
                  <Field key={k} label={labelMap[k] || k}>
                    <textarea
                      rows={k === "text" ? 3 : 1}
                      value={String(item[k] ?? "")}
                      onChange={(e) => updateItem(e.target.value)}
                    />
                  </Field>
                );
              })}
            </div>
          ))}
        </div>
      ) : null}

      {msg ? <p className="admin-success">{msg}</p> : null}
      {err ? <p className="admin-error">{err}</p> : null}
      <button type="submit" disabled={pending}>
        {pending ? "Сохраняем…" : "Сохранить на сайт"}
      </button>
    </form>
  );
}
