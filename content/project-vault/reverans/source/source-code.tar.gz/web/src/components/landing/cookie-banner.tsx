"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { CookieBannerData } from "@/lib/cms-defaults";

const STORAGE_KEY = "cookie_consent_yandex_metrika";

function loadYandexMetrika(counterId: string, webvisor: boolean) {
  if (typeof window === "undefined") return;
  if (document.getElementById("yandex-metrika-script")) return;

  type YmFn = ((...args: unknown[]) => void) & { a?: unknown[]; l?: number };
  const w = window as Window & { ym?: YmFn };

  w.ym =
    w.ym ||
    (function (...args: unknown[]) {
      (w.ym!.a = w.ym!.a || []).push(args);
    } as YmFn);
  w.ym.l = Date.now();

  const s = document.createElement("script");
  s.async = true;
  s.src = "https://mc.yandex.ru/metrika/tag.js";
  s.id = "yandex-metrika-script";
  document.head.appendChild(s);

  w.ym(counterId, "init", {
    clickmap: true,
    trackLinks: true,
    accurateTrackBounce: true,
    webvisor: Boolean(webvisor),
    trackHash: false,
  });
}

function loadGoogleAnalytics(id: string) {
  if (document.getElementById("ga-script")) return;
  const s = document.createElement("script");
  s.async = true;
  s.src = `https://www.googletagmanager.com/gtag/js?id=${id}`;
  s.id = "ga-script";
  document.head.appendChild(s);
  const inline = document.createElement("script");
  inline.id = "ga-inline";
  inline.text = `
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', ${JSON.stringify(id)});
`;
  document.head.appendChild(inline);
}

export function CookieBanner({
  data,
  metrikaId,
  metrikaEnabled,
  webvisor,
  googleAnalyticsId,
}: {
  data: CookieBannerData;
  metrikaId: string | null;
  metrikaEnabled: boolean;
  webvisor: boolean;
  googleAnalyticsId: string | null;
}) {
  const [visible, setVisible] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(STORAGE_KEY);
    if (consent === "accepted") {
      if (metrikaEnabled && metrikaId) loadYandexMetrika(metrikaId, webvisor);
      if (googleAnalyticsId) loadGoogleAnalytics(googleAnalyticsId);
      setVisible(false);
    } else if (consent === "declined") {
      setVisible(false);
    } else {
      setVisible(true);
    }
    setReady(true);
  }, [metrikaEnabled, metrikaId, webvisor, googleAnalyticsId]);

  function accept() {
    localStorage.setItem(STORAGE_KEY, "accepted");
    setVisible(false);
    if (metrikaEnabled && metrikaId) loadYandexMetrika(metrikaId, webvisor);
    if (googleAnalyticsId) loadGoogleAnalytics(googleAnalyticsId);
  }

  function decline() {
    localStorage.setItem(STORAGE_KEY, "declined");
    setVisible(false);
  }

  if (!ready || !visible) return null;

  return (
    <div
      className="cookie-banner"
      role="dialog"
      aria-modal="true"
      aria-label="Согласие на использование файлов cookie и Яндекс.Метрики"
    >
      <div className="cookie-banner-inner">
        <div className="cookie-banner-text">
          <p>{data.text}</p>
          <p className="cookie-banner-links">
            <Link href={data.privacyPath} target="_blank" rel="noopener noreferrer">
              {data.privacyLinkLabel}
            </Link>
            <span aria-hidden> · </span>
            <Link href={data.consentPath} target="_blank" rel="noopener noreferrer">
              {data.consentLinkLabel}
            </Link>
          </p>
        </div>
        <div className="cookie-banner-actions">
          <button type="button" className="cookie-btn cookie-btn-decline" onClick={decline}>
            {data.declineLabel}
          </button>
          <button type="button" className="cookie-btn cookie-btn-accept" onClick={accept}>
            {data.acceptLabel}
          </button>
        </div>
      </div>
    </div>
  );
}
