import Link from "next/link";
import type { FinalCtaData, SiteSettingsView } from "@/lib/cms-defaults";

export function FinalCta({
  data,
  settings,
  enabled = true,
}: {
  data: FinalCtaData;
  settings: SiteSettingsView;
  enabled?: boolean;
}) {
  if (!enabled) return null;
  const titleLines = data.title.split("\n").filter(Boolean);

  return (
    <section className="final-cta">
      <div className="container">
        <div className="final-cta-inner">
          <h2>
            {titleLines.map((line) => (
              <span key={line}>
                {line}
                <br />
              </span>
            ))}
          </h2>
          <p>{data.subtitle}</p>
          <Link href={data.btnHref} className="btn">
            {data.btnText}
          </Link>
          {data.showPhone ? (
            <a className="final-cta-phone" href={settings.phoneHref}>
              {settings.phoneDisplay}
            </a>
          ) : null}
        </div>
      </div>
    </section>
  );
}
