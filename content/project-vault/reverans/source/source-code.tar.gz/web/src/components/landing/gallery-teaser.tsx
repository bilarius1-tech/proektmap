import Link from "next/link";
import { GalleryGrid } from "@/components/landing/gallery-grid";
import type { GalleryTeaserData } from "@/lib/cms-defaults";

type Photo = {
  id: string;
  alt: string;
  caption: string;
  media: { url: string; thumbUrl?: string | null };
};

export function GalleryTeaser({
  data,
  photos,
  enabled = true,
}: {
  data: GalleryTeaserData;
  photos: Photo[];
  enabled?: boolean;
}) {
  if (!enabled) return null;

  const items = photos.map((p) => ({
    id: p.id,
    src: p.media.url,
    thumbSrc: p.media.thumbUrl || p.media.url,
    alt: p.alt || p.caption || "Фото клуба",
    caption: p.caption || undefined,
  }));

  return (
    <section className="section section-alt" id="gallery">
      <div className="container">
        <div className="section-header">
          <h2>{data.title}</h2>
          <p>{data.subtitle}</p>
        </div>
        {photos.length === 0 ? (
          <div className="pricing-note">
            <p>Скоро здесь появятся фотографии клуба</p>
            <p className="muted">Загрузите их в админке → Сайт → Галерея</p>
          </div>
        ) : (
          <GalleryGrid
            photos={items}
            className="gallery-teaser-grid"
            itemClassName="gallery-teaser-item"
          />
        )}
        <p style={{ textAlign: "center", marginTop: 32 }}>
          <Link href={data.btnHref} className="btn btn-primary">
            {data.btnText}
          </Link>
        </p>
      </div>
    </section>
  );
}
