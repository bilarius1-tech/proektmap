"use client";

import { useState } from "react";
import { createIndividualTrainingPackage } from "@/app/admin/actions";

type Option = { id: string; label: string };

export function AdminTrainingPackageForm({
  childrenOptions,
  coaches,
}: {
  childrenOptions: Option[];
  coaches: Option[];
}) {
  const [count, setCount] = useState(4);

  return (
    <form className="admin-form" action={createIndividualTrainingPackage}>
      <p className="admin-muted" style={{ marginTop: 0 }}>
        Несколько дат — одна общая сумма. В кабинете родителя будет одна кнопка оплаты.
      </p>
      <label>
        Ребёнок
        <select name="childId" required defaultValue="">
          <option value="" disabled>
            Выберите
          </option>
          {childrenOptions.map((c) => (
            <option key={c.id} value={c.id}>
              {c.label}
            </option>
          ))}
        </select>
      </label>
      <label>
        Педагог
        <select name="coachId" required defaultValue="">
          <option value="" disabled>
            Выберите
          </option>
          {coaches.map((c) => (
            <option key={c.id} value={c.id}>
              {c.label}
            </option>
          ))}
        </select>
      </label>
      <label>
        Число занятий
        <select
          value={count}
          onChange={(e) => setCount(Number(e.target.value))}
          aria-label="Число занятий"
        >
          {[2, 3, 4, 5, 6, 8, 10].map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </select>
      </label>
      <label>
        Сумма пакета, ₽
        <input name="packagePrice" type="number" step="0.01" required defaultValue={7000} />
      </label>
      {Array.from({ length: count }, (_, i) => (
        <fieldset key={i} className="admin-fieldset">
          <legend>Занятие {i + 1}</legend>
          <label>
            Дата
            <input name="sessionDate" type="date" required />
          </label>
          <label>
            Время
            <input name="sessionTime" placeholder="16:00" required defaultValue="16:00" />
          </label>
        </fieldset>
      ))}
      <button type="submit">Создать пакет</button>
    </form>
  );
}
