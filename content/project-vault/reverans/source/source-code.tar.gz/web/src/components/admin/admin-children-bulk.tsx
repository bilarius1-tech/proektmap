"use client";

import { useEffect, useMemo, useState, useTransition, type FormEvent } from "react";
import { assignChildrenPrice, ensureChildrenInviteCodes, linkChildrenToParent } from "@/app/admin/actions";
import { AdminModal } from "@/components/admin/admin-modal";
import { isPendingParentEmail, normalizePhone } from "@/lib/parent-identity-shared";

type ParentOption = {
  id: string;
  name: string;
  email: string;
  phone: string | null;
  childrenCount: number;
};

type ChildOption = {
  id: string;
  fullName: string;
  pricePerMonth: number;
};

function selectedChildIds() {
  return Array.from(
    document.querySelectorAll<HTMLInputElement>("input.admin-child-check:checked"),
  ).map((el) => el.value);
}

export function AdminChildrenBulkBar({
  parents,
  childrenOptions,
}: {
  parents: ParentOption[];
  childrenOptions: ChildOption[];
}) {
  const [count, setCount] = useState(0);
  const [linkOpen, setLinkOpen] = useState(false);
  const [priceOpen, setPriceOpen] = useState(false);
  const [ids, setIds] = useState<string[]>([]);
  const [parentEmail, setParentEmail] = useState("");
  const [parentPhone, setParentPhone] = useState("");
  const [priceMode, setPriceMode] = useState<"each" | "total" | "per">("each");
  const [linkPriceMode, setLinkPriceMode] = useState<"keep" | "each" | "total">("keep");
  const [pending, startTransition] = useTransition();

  const selectedKids = useMemo(
    () => childrenOptions.filter((c) => ids.includes(c.id)),
    [childrenOptions, ids],
  );

  const emailKey = parentEmail.trim().toLowerCase();
  const phoneKey = normalizePhone(parentPhone);
  const matchedParent =
    parents.find((p) => emailKey && p.email.toLowerCase() === emailKey) ||
    parents.find((p) => phoneKey && normalizePhone(p.phone) === phoneKey);

  useEffect(() => {
    function refresh() {
      setCount(selectedChildIds().length);
    }
    refresh();
    document.addEventListener("change", refresh);
    return () => document.removeEventListener("change", refresh);
  }, []);

  function openLink() {
    setIds(selectedChildIds());
    setParentEmail("");
    setParentPhone("");
    setLinkOpen(true);
  }

  function openPrice() {
    setIds(selectedChildIds());
    setPriceOpen(true);
  }

  function issueCodes() {
    const next = selectedChildIds();
    if (!next.length) return;
    const fd = new FormData();
    for (const id of next) fd.append("childIds", id);
    startTransition(async () => {
      await ensureChildrenInviteCodes(fd);
    });
  }

  function onTogglePage(e: FormEvent<HTMLInputElement>) {
    const on = e.currentTarget.checked;
    document.querySelectorAll<HTMLInputElement>("input.admin-child-check").forEach((el) => {
      el.checked = on;
    });
    setCount(selectedChildIds().length);
  }

  return (
    <div className="admin-bulk-bar">
      <label className="admin-check">
        <input type="checkbox" onChange={onTogglePage} />
        Выбрать всех на странице
      </label>
      <span className="admin-muted">Выбрано: {count}</span>
      <button type="button" className="admin-btn admin-btn-ghost" disabled={!count} onClick={openLink}>
        Привязать к родителю
      </button>
      <button type="button" className="admin-btn admin-btn-ghost" disabled={!count} onClick={openPrice}>
        Суммы
      </button>
      <button
        type="button"
        className="admin-btn admin-btn-ghost"
        disabled={!count || pending}
        onClick={issueCodes}
      >
        {pending ? "Выдаём…" : "Выдать коды"}
      </button>

      {linkOpen ? (
        <AdminModal title="Привязать к родителю" onClose={() => setLinkOpen(false)}>
          <form className="admin-form" action={linkChildrenToParent}>
            {ids.map((id) => (
              <input key={id} type="hidden" name="childIds" value={id} />
            ))}
            <p className="admin-muted" style={{ marginTop: 0 }}>
              Детей: {ids.length}. Коды сохраняются — их можно отправить родителю для регистрации.
              Почту можно не указывать: достаточно телефона.
            </p>
            <label>
              ФИО родителя
              <input
                name="parentName"
                required
                placeholder="Иванова Мария"
                defaultValue={matchedParent?.name || ""}
              />
            </label>
            <label>
              Телефон {!parentEmail.trim() ? "(обязателен без почты)" : ""}
              <input
                name="parentPhone"
                type="tel"
                placeholder="+7…"
                required={!parentEmail.trim()}
                value={parentPhone}
                onChange={(e) => setParentPhone(e.target.value)}
              />
            </label>
            <label>
              Email родителя (необязательно)
              <input
                name="parentEmail"
                type="email"
                list="admin-parent-emails"
                placeholder="можно позже"
                value={parentEmail}
                onChange={(e) => setParentEmail(e.target.value)}
              />
            </label>
            <datalist id="admin-parent-emails">
              {parents
                .filter((p) => !isPendingParentEmail(p.email))
                .map((p) => (
                  <option key={p.id} value={p.email}>
                    {p.name}
                    {p.phone ? ` · ${p.phone}` : ""} · детей: {p.childrenCount}
                  </option>
                ))}
            </datalist>
            {matchedParent ? (
              <p className="admin-muted" style={{ margin: 0 }}>
                Найден: {matchedParent.name}
                {matchedParent.childrenCount > 0
                  ? ` · уже ${matchedParent.childrenCount} дет.`
                  : ""}
                {isPendingParentEmail(matchedParent.email) ? " · почты ещё нет" : ""}
              </p>
            ) : null}

            <fieldset className="admin-fieldset">
              <legend>Цены после объединения</legend>
              <label className="admin-check">
                <input
                  type="radio"
                  name="priceMode"
                  value="keep"
                  checked={linkPriceMode === "keep"}
                  onChange={() => setLinkPriceMode("keep")}
                />
                Оставить текущие цены
              </label>
              <label className="admin-check">
                <input
                  type="radio"
                  name="priceMode"
                  value="each"
                  checked={linkPriceMode === "each"}
                  onChange={() => setLinkPriceMode("each")}
                />
                Одинаковая цена на каждого
              </label>
              <label className="admin-check">
                <input
                  type="radio"
                  name="priceMode"
                  value="total"
                  checked={linkPriceMode === "total"}
                  onChange={() => setLinkPriceMode("total")}
                />
                Общая сумма семьи (разделить поровну)
              </label>
              {linkPriceMode !== "keep" ? (
                <label>
                  {linkPriceMode === "total" ? "Общая сумма, ₽" : "Цена на каждого, ₽"}
                  <input name="priceValue" type="number" step="0.01" min={0} required defaultValue={3500} />
                </label>
              ) : null}
            </fieldset>

            <button type="submit">Привязать</button>
          </form>
        </AdminModal>
      ) : null}

      {priceOpen ? (
        <AdminModal title="Назначить суммы" onClose={() => setPriceOpen(false)}>
          <form className="admin-form" action={assignChildrenPrice}>
            {ids.map((id) => (
              <input key={id} type="hidden" name="childIds" value={id} />
            ))}
            <p className="admin-muted" style={{ marginTop: 0 }}>
              Выбрано: {ids.length}
            </p>
            <fieldset className="admin-fieldset">
              <legend>Как назначить</legend>
              <label className="admin-check">
                <input
                  type="radio"
                  name="mode"
                  value="each"
                  checked={priceMode === "each"}
                  onChange={() => setPriceMode("each")}
                />
                Одинаковая на каждого
              </label>
              <label className="admin-check">
                <input
                  type="radio"
                  name="mode"
                  value="total"
                  checked={priceMode === "total"}
                  onChange={() => setPriceMode("total")}
                />
                Общая сумма (поровну)
              </label>
              <label className="admin-check">
                <input
                  type="radio"
                  name="mode"
                  value="per"
                  checked={priceMode === "per"}
                  onChange={() => setPriceMode("per")}
                />
                Порознь (своя сумма каждому)
              </label>
            </fieldset>

            {priceMode === "per" ? (
              selectedKids.map((c) => (
                <label key={c.id}>
                  {c.fullName}, ₽/мес
                  <input
                    name={`price_${c.id}`}
                    type="number"
                    step="0.01"
                    min={0}
                    required
                    defaultValue={c.pricePerMonth}
                  />
                </label>
              ))
            ) : (
              <label>
                {priceMode === "total" ? "Общая сумма семьи, ₽" : "Цена на каждого, ₽"}
                <input name="pricePerMonth" type="number" step="0.01" min={0} required defaultValue={3500} />
              </label>
            )}

            <button type="submit">Сохранить суммы</button>
          </form>
        </AdminModal>
      ) : null}
    </div>
  );
}
