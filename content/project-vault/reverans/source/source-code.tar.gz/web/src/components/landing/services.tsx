import Link from "next/link";
import type { ServicesData } from "@/lib/cms-defaults";

export function Services({ data, enabled = true }: { data: ServicesData; enabled?: boolean }) {
  if (!enabled) return null;
  return (
    <section className="section section-alt" id="services">
      <div className="container">
        <div className="section-header">
          <h2>{data.title}</h2>
          <p>{data.subtitle}</p>
        </div>
        <div className="services-grid">
          {data.items.map((service) => (
            <article key={service.title} className="service-card">
              <h3>{service.title}</h3>
              <p>{service.text}</p>
              <Link href={service.linkHref} className="btn-link">
                {service.linkText}
              </Link>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
