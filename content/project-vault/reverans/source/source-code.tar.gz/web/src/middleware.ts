import { getToken } from "next-auth/jwt";
import { NextRequest, NextResponse } from "next/server";

export async function middleware(req: NextRequest) {
  const token = await getToken({
    req,
    secret: process.env.NEXTAUTH_SECRET,
  });

  const path = req.nextUrl.pathname;
  const isAdminPath = path.startsWith("/admin");
  const isCabinetPath = path.startsWith("/cabinet");

  if (!isAdminPath && !isCabinetPath) {
    return NextResponse.next();
  }

  const loginBase = process.env.NEXTAUTH_URL || "https://reverans.online";

  if (isAdminPath) {
    if (!token || token.role !== "admin") {
      const login = new URL("/login", loginBase);
      login.searchParams.set("callbackUrl", path);
      return NextResponse.redirect(login);
    }
    return NextResponse.next();
  }

  // /cabinet — parent or coach
  if (!token || (token.role !== "parent" && token.role !== "coach")) {
    if (token?.role === "admin") {
      return NextResponse.redirect(new URL("/admin", loginBase));
    }
    const login = new URL("/login", loginBase);
    login.searchParams.set("callbackUrl", path);
    return NextResponse.redirect(login);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/admin/:path*", "/cabinet", "/cabinet/:path*"],
};
