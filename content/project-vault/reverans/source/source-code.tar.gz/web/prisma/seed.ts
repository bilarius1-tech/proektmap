import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";
import { DEFAULT_SEO, DEFAULT_SETTINGS, SECTION_DEFS } from "../src/lib/cms-defaults";

const prisma = new PrismaClient();

async function main() {
  const email = (process.env.ADMIN_EMAIL || "[ADMIN_EMAIL]").toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  if (!password) {
    throw new Error("ADMIN_PASSWORD is required for seed");
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const admin = await prisma.user.upsert({
    where: { email },
    update: {
      passwordHash,
      role: Role.admin,
      name: "Администратор",
    },
    create: {
      email,
      passwordHash,
      role: Role.admin,
      name: "[CLIENT]",
      phone: "+79996231301",
    },
  });

  await prisma.siteSettings.upsert({
    where: { id: "default" },
    create: { id: "default", ...DEFAULT_SETTINGS },
    update: {},
  });

  for (const section of SECTION_DEFS) {
    await prisma.siteSection.upsert({
      where: { key: section.key },
      create: {
        key: section.key,
        label: section.label,
        data: section.data,
        enabled: true,
      },
      update: {},
    });
  }

  for (const seo of DEFAULT_SEO) {
    await prisma.pageSeo.upsert({
      where: { path: seo.path },
      create: {
        path: seo.path,
        title: seo.title,
        description: seo.description,
        h1: seo.h1 ?? null,
      },
      update: {},
    });
  }

  console.log(`Admin ready: ${admin.email} (${admin.id})`);
  console.log(`CMS sections: ${SECTION_DEFS.length}, SEO pages: ${DEFAULT_SEO.length}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
