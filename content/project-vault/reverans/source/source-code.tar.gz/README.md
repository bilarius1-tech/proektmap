# Reverans — СКХГ «Реверанс»

Платформа студии художественной гимнастики · https://reverans.online

## Новый агент

**Начни здесь → [START_HERE.md](./START_HERE.md)**  
Затем: [docs/DEVLOG.md](./docs/DEVLOG.md) · [docs/AGENT_HANDOFF.md](./docs/AGENT_HANDOFF.md)

## ТЗ

| | |
|--|--|
| Локально | `tz/outputs/` |
| Публично | https://reverans.online/tz/outputs/ |

## Сейчас в проде

- Лендинг: `/` · `/about`  
- Админка: `/login` → `/admin`  
- Health: `/api/health`  
- Docs: `/tz/outputs/`

## Dev

```
Workspace: /root/projects/reverans
VPS:       deploy@159.194.228.226:/var/www/reverans
Git:       origin ztim2008/reverans (Cursor Origin)
```

Harness: `./harness/check-service.sh`  
Правила дня: `docs/DEVELOPMENT.md`
