const fs = require("fs");
const path = require("path");

/** Load KEY=VALUE from web/.env (no dotenv — so $ is not expanded). */
function loadEnvFile(filePath) {
  const out = {};
  if (!fs.existsSync(filePath)) return out;
  for (const line of fs.readFileSync(filePath, "utf8").split(/\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const i = trimmed.indexOf("=");
    if (i < 0) continue;
    const key = trimmed.slice(0, i).trim();
    let val = trimmed.slice(i + 1).trim();
    if (
      (val.startsWith('"') && val.endsWith('"')) ||
      (val.startsWith("'") && val.endsWith("'"))
    ) {
      val = val.slice(1, -1);
    }
    val = val.replace(/\\\$/g, "$").replace(/\\\\/g, "\\");
    out[key] = val;
  }
  return out;
}

function readSecretFile(filePath) {
  if (!fs.existsSync(filePath)) return "";
  return fs.readFileSync(filePath, "utf8").replace(/^\uFEFF/, "").trim();
}

const root = __dirname;
const webEnv = loadEnvFile(path.join(root, "web", ".env"));
const secretFile =
  webEnv.TBANK_SECRET_FILE || path.join(root, "secrets", "tbank_secret");
const tbankSecret = readSecretFile(secretFile) || webEnv.TBANK_SECRET_KEY || "";

module.exports = {
  apps: [
    {
      name: "reverans",
      cwd: "/var/www/reverans/web",
      script: "node_modules/next/dist/bin/next",
      args: "start -p 3050 -H 127.0.0.1",
      instances: 1,
      exec_mode: "fork",
      env: {
        NODE_ENV: "production",
        PORT: "3050",
        NEXTAUTH_URL: webEnv.NEXTAUTH_URL || "https://reverans.online",
        NEXT_PUBLIC_SITE_URL: webEnv.NEXT_PUBLIC_SITE_URL || "https://reverans.online",
        NODE_EXTRA_CA_CERTS:
          webEnv.NODE_EXTRA_CA_CERTS ||
          "/var/www/reverans/certs/russian-trusted-ca-bundle.pem",
        TBANK_TERMINAL_KEY: webEnv.TBANK_TERMINAL_KEY || "",
        // Prefer file; still inject for tools. App reads TBANK_SECRET_FILE first.
        TBANK_SECRET_FILE: secretFile,
        TBANK_SECRET_KEY: tbankSecret,
        TBANK_API_URL: webEnv.TBANK_API_URL || "https://securepay.tinkoff.ru/v2",
        ...(webEnv.TBANK_TAXATION ? { TBANK_TAXATION: webEnv.TBANK_TAXATION } : {}),
        ...(webEnv.TBANK_VAT ? { TBANK_VAT: webEnv.TBANK_VAT } : {}),
        ...(webEnv.NEXTAUTH_SECRET ? { NEXTAUTH_SECRET: webEnv.NEXTAUTH_SECRET } : {}),
        ...(webEnv.DATABASE_URL ? { DATABASE_URL: webEnv.DATABASE_URL } : {}),
      },
      max_memory_restart: "500M",
      time: true,
    },
  ],
};
