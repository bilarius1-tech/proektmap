# DEVLOG — Reverans (СКХГ «Реверанс»)

> Для агентов и людей. Обновлено: **2026-09-08** (закрытие дня).

**Новый агент:** [START_HERE.md](../START_HERE.md) · [AGENT_HANDOFF.md](./AGENT_HANDOFF.md) · дневник [DAILY_JOURNAL.md](./DAILY_JOURNAL.md)

## Сейчас (приоритет) — 2026-09-08 вечер

**Закрыто сегодня:** семейные цены / родитель без email / invite-коды / биллинг с октября / пакеты инд. / фильтры админки / плашки цен CMS / защита uploads + бэкапы.

**Контур на проде:**
- Родитель: код / телефон-claim → документы → оплата (с октября; с 20-го — фокус на следующий месяц)
- Админ: дети bulk (связь/цены/коды), пакеты тренировок, фильтр групп в платежах/документах
- Цены: HTML-плашки младшая/средняя/старшая из CMS
- Деплой только `./deploy/rsync-web.sh` (не трогает uploads); бэкапы `/var/www/reverans/backups/`

Секреты Т‑Банк: `/var/www/reverans/secrets/tbank_secret` + `TBANK_SECRET_FILE`.

### Осталось / бэклог
1. Перезалить фото галереи (стёрты старым `rsync --delete`; из бэкапа не восстановить)  
2. Онлайн‑касса / чеки (когда касса в Т‑Бизнесе)  
3. Общая оплата нескольких детей одной суммой  
4. Кабинет педагога  
5. Excel‑импорт детей (идея)

Текст клиентке: [CLIENT_FIRST_STEPS.md](./CLIENT_FIRST_STEPS.md) · QA родителя: [CLIENT_PARENT_QA.md](./CLIENT_PARENT_QA.md)

---

## 2026-09-08 — семейные цены, биллинг, пакеты, бэкапы ✅

### Сделано
- Связь детей с родителем (ФИО+телефон без email), claim при регистрации по телефону
- Invite-коды сохраняются после merge; bulk «Выдать коды»; takeover draft-родителя
- Цены: режимы keep/each/total/per-child; автоскидка «сестра» убрана (ручные цены Софьи)
- Биллинг: `FIRST_BILLABLE_MONTH=2026-10`, с 20-го — следующий месяц; чипы focus+next
- Пакеты инд. тренировок (`packageId`); одна сумма / одна кнопка оплаты
- Админ: фильтр групп в платежах и документах
- `/prices` + виджет на главной: плашки групп из CMS; TipTap toolbar contrast fix
- Deploy: `deploy/rsync-web.sh` exclude uploads/storage + backup before sync
- Бэкапы: `backup-prod.sh` / `backup-workspace.sh`; nightly cron на VPS; каталог вне `web/`

### Harness
`pass=30 warn=0 fail=0`

### Осталось
- [ ] Перезалить галерею
- [ ] Онлайн‑касса / педагог / общая оплата нескольких детей

### Коммит / push
- `255c273` → `origin/main`
- Remote: https://origin.cursor.com/ztim2008/reverans.git

---

## 2026-09-07 (поздно) — бюджет + фильтр групп ✅

### Сделано
- `Child.isBudget`: админ галочка; ЛК без оплаты абонемента; документы/группа как у всех
- Фильтр детей по группе (все / без группы / конкретная)

### Harness
`pass=30 warn=0 fail=0`

### Коммит / push
- `fee42b6` → `origin/main`

---

## 2026-09-07 (вечер) — админ UX + зачисление ✅

### Сделано
- Админка: status badges, AdminModal, toolbar, mobile cards, search/pagination (платежи/дети/тренировки)
- Меню mobile: Документы и инд. тренировки выше
- Зачисление без черновика: `Child.userId` nullable + `inviteCode`; цена из группы
- ЛК: «Привязать ребёнка» по коду + дата рождения → группа и сумма сразу

### Harness
`pass=30 warn=0 fail=0`

### Коммит / push
- `562326d` → `origin/main`
- Remote: https://origin.cursor.com/ztim2008/reverans.git

---

## 2026-09-07 — контур оплаты + UX документов ✅

### Сделано
- Боевой эквайринг Т‑Банк Init/webhook; секрет из файла (обход обрезания `$` в Next dotenv)
- DEMO E2E: тестовая карта → «Оплачено»; затем боевой терминал на VPS
- Медсправка: upload/compress, админ preview confirm/reject, private `storage/medical/`
- Документы ЛК: русские статусы, Lucide‑иконки локально, цветные карточки
- Лендинг: контрастные карточки цен `#41a0a5`, why‑choose цифры в круге 1/2/3
- CMS: contacts + installApp; TipTap link fix
- Админ‑дэшборд/платежи: без сырых `pending` / `medical_clearance` в UI

### Harness
`pass=30 warn=0 fail=0`

### Коммит / push
- `69219cc` → `origin/main`
- Remote: https://origin.cursor.com/ztim2008/reverans.git

---

## 2026-09-05 — закрытие дня ✅

### Сделано
- Лендинг + CMS, ЛК родителя, acquiring-ready (ждали ключи)

### Harness
`pass=29 warn=0 fail=0`

### Коммит / push
- Tag: `day-2026-09-05`

---

## Шаблон закрытия дня

```markdown
## YYYY-MM-DD — краткий заголовок

### Сделано
- …

### Harness
`pass=… warn=… fail=…`

### Осталось
- [ ] …

### Коммит / push
- hash · pushed yes/no · remote URL
```
