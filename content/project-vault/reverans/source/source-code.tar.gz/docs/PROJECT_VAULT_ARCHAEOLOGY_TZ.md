# Project Vault — бриф археологии (Реверанс)

> **Роль этого файла:** instance brief для агента, работающего у источника (Reverans).  
> **Полный канон (TEMPLATE + PASS 1–7 + manifest + import):**  
> `/var/www/www-root/data/www/proektmap.ru/docs/PROJECT-VAULT-TZ.md`  
> Публичный outline: `/var/www/www-root/data/www/proektmap.ru/docs/PROJECT-VAULT.md`

**Не реализовывать** продукт Reverans «заодно». Задача агента по этому брифу — археология → Package → импорт капсулы в ProektMap `/project-vault` (см. PASS в каноне).

---

## Куда смотреть

| Хост | Что |
|------|-----|
| **Источник (reverans)** | Workspace `/root/projects/reverans` · prod `/var/www/reverans/web` · SSH `deploy@159.194.228.226` · https://reverans.online |
| **Назначение (nordic / ProektMap)** | `/var/www/www-root/data/www/proektmap.ru` · https://proektmap.ru · раздел `/project-vault` |

Если агент сидит только в workspace Reverans: читать/паковать отсюда; для PASS 6 нужен доступ к дереву ProektMap на nordic (или передать package + поручить import-агенту на ProektMap).

---

## INSTANCE: Reverans (вставить в TEMPLATE из канона)

```text
## Instance — Reverans (pilot)
- PROJECT_SLUG: reverans
- PROJECT_NAME: Реверанс (СКХГ «Реверанс»)
- PROJECT_TAGLINE: Платформа студии художественной гимнастики: лендинг, ЛК родителя, админка, договоры, ТБанк
- SOURCE_URL: https://reverans.online
- SOURCE_PATHS:
  - workspace/git: /root/projects/reverans
  - production: /var/www/reverans (web: /var/www/reverans/web)
- SSH_HOST: 159.194.228.226
- SSH_USER: deploy
- PROD_APP_PATH: /var/www/reverans/web
- WORKSPACE_PATH: /root/projects/reverans
- PM2_PROCESS: reverans
- DB_NAME_HINT: reverans_db
- PACKAGE_OUTPUT_DIR: /var/www/www-root/data/www/proektmap.ru/content/project-vault/reverans
- PROEKTMAP_CAPSULE_SLUG: reverans
- DNA_VERSION: 1.0.0
- DERIVED_FROM: null
```

---

## DNA hotspots (собрать в первую очередь)

1. `START_HERE.md`, `AGENTS.md`  
2. `docs/PHILOSOPHY.md`, `docs/DEVELOPMENT.md`, `docs/DEVLOG.md`, `docs/AGENT_HANDOFF.md`  
3. `.cursor/rules/` — `00-start-here`, `development`, `harness`, `day-close`, `dev-graph`, `reverans-product`  
4. `harness/` — health scripts; в package **без** секретов из config  
5. `tz/outputs/` — продуктовое ТЗ (без ключей)  
6. `web/` — Prisma schema, паттерн Next.js + PM2 deploy  

---

## Жёсткие правила

- Client Boundary: **нет** PII детей/родителей, **нет** значений `.env`, **нет** private SSL keys  
- DB: schema-only dump предпочтителен  
- Vault ≠ `/ai-workshop`, ≠ паспорт `/resheniya`  
- Arsenal — только candidates, без авто-публикации  
- Полные PASS 1–7 и дерево архива — только в каноне ProektMap  

---

## Как стартовать агента

1. Открыть канон: `PROJECT-VAULT-TZ.md` на ProektMap.  
2. Скопировать **TEMPLATE: Agent Mission Prompt**.  
3. Вставить INSTANCE выше.  
4. Выполнить PASS 1→7.  
5. DoD пилота: капсула на https://proektmap.ru/project-vault/reverans  

Для **проекта #2** этот файл не копировать как есть: взять TEMPLATE из канона и заполнить новый INSTANCE.
